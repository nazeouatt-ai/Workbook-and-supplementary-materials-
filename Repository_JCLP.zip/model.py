"""Revised model (v2): food-only scope; te Wierik et al. (2025) and Willett et al. (2019) control variables only."""
import numpy as np, json
from data import *

rng = np.random.default_rng(20261020)
idx = {y: i for i, y in enumerate(YEARS)}; i00 = {y: i for i, y in enumerate(Y00)}
BASE = [2021, 2022, 2023]
def m(series): return float(np.mean([series[idx[y]] for y in BASE]))
def m00(series): return float(np.mean([series[i00[y]] for y in BASE]))
popB0 = np.mean([WDI_POP['BFA'][y] for y in BASE]); popW0 = np.mean([WDI_POP['WLD'][y] for y in BASE]); share0 = popB0 / popW0
DES0 = np.mean([FBS_DES['BFA'][y] for y in BASE])
R = {'base': {'popB0': popB0, 'popW0': popW0, 'share0': share0, 'DES0': DES0}}

# ---------------- cotton (non-food) shares ----------------
cot_area = np.mean(list(COTTON_AREA.values())) / 1e3                    # kha -> Mha? (ha/1e3 = kha)
crop_kha = m(RL['BFA_cropland'])
f_area = (np.mean(list(COTTON_AREA.values())) / 1e3) / crop_kha        # share of cropland
f_N = IFA_COTTON['N_cotton'] / IFA_COTTON['N_total']; f_P = IFA_COTTON['P2O5_cotton'] / IFA_COTTON['P2O5_total']
cot_clim = (f_N * m00(GT00['synth_fert']) + f_area * (m00(GT00['crop_residues']) + m00(GT00['burning_residues']) + m00(GT00['onfarm_energy'])
            + m00(GT00['luc']))) / 1e3       # Mt; pesticide manufacture added below with the pesticide share
R['cotton'] = {'area_Mha': np.mean(list(COTTON_AREA.values())) / 1e6, 'f_area': f_area, 'f_N': f_N, 'f_P': f_P, 'climate_Mt': cot_clim}
# cotton share of pesticide use, bottom-up from the SOFITEX 2022/23 input tender scaled to the national cotton area
def cotton_pest_kt(ai):
    sof = (sum(SOFITEX['insect_doses'][k] * ai[k] for k in ['T1', 'T2', 'T3']) + SOFITEX['herb_pre_gran_ha'] * ai['herb_pre_gran']
           + SOFITEX['herb_pre_liq_ha'] * ai['herb_pre_liq'] + SOFITEX['herb_post_L'] * ai['herb_post_per_L']) / 1e6   # kt
    return sof * COTTON_AREA[2022] / SOFITEX['cotton_area_ha']
ai_mode = {k: v[1] for k, v in AI_PER_DOSE.items()}
cot_pest = cotton_pest_kt(ai_mode); pest_all = m(RP['BFA']) / 1e3
c_pest = cot_pest / (RP['BFA'][idx[2022]] / 1e3)
cot_insect = sum(SOFITEX['insect_doses'][k] * ai_mode[k] for k in ['T1', 'T2', 'T3']) / 1e6 * COTTON_AREA[2022] / SOFITEX['cotton_area_ha']
# cotton share of the cropland N balance: mineral N (IFA share) + area share of manure, deposition and seed - N removed in seed cotton
seed_cotton = np.mean(list(COTTON_QCL['seed_cotton'].values())) / 1e3      # kt
N_in_tmp = m(ESB['BFA_N_inputs']) / 1e3; Nmin_tmp = m00(ESB00['N_mineral']) / 1e3; Nbnf_tmp = m00(ESB00['N_bnf']) / 1e3
def cotton_Nbal(nrem): return f_N * Nmin_tmp + f_area * (N_in_tmp - Nmin_tmp - Nbnf_tmp) - nrem * seed_cotton
cot_Nbal = cotton_Nbal(N_REMOVAL_SEED_COTTON[1])
lint = np.mean(list(COTTON_QCL['lint'].values())); cseed = np.mean(list(COTTON_QCL['cottonseed'].values()))
R['cotton'].update({'pest_kt': cot_pest, 'pest_share_2022': c_pest, 'pest_insect_kt': cot_insect, 'N_balance_kt': cot_Nbal, 'seed_cotton_kt': seed_cotton,
                    'lint_kt': lint / 1e3, 'cottonseed_kt': cseed / 1e3, 'cottonseed_mass_share': cseed / (cseed + lint),
                    'cottonseed_oil_kcal': float(np.mean(list(FBS_COTTONSEED_OIL_KCAL.values()))),
                    'insect_share_nat': cot_insect / (np.mean([RP_CAT['insecticides'][y] for y in [2022]]) / 1e3)})

# ---------------- live-animal exports (official) ----------------
exp_frac = {k: np.sum(LIVE_EXPORT[k]) / (np.sum(LIVE_EXPORT[k]) + np.sum(SLAUGHTER[k])) for k in LIVE_EXPORT}
R['live_export_frac'] = exp_frac

# ---------------- national (food-only) and world pressures ----------------
P, W = {}, {}
clim_all = m(GT['BFA_agrifood']) / 1e3
clim_parts = {k: m(GT['BFA_' + k]) / 1e3 for k in ['farmgate', 'luc', 'prepost']}
cot_clim += c_pest * m00(GT00['pest_manuf']) / 1e3; R['cotton']['climate_Mt'] = cot_clim
P['climate'] = clim_all - cot_clim; W['climate'] = m(GT['WLD_agrifood']) / 1e3
P['cropland'] = (crop_kha - np.mean(list(COTTON_AREA.values())) / 1e3) / 1e3; W['cropland'] = m(RL['WLD_cropland']) / 1e3
ag_wd_B = WDI['BFA_water_withdrawal_km3'] * WDI['BFA_ag_share_withdrawal_pct'] / 100
ag_wd_W = WDI['WLD_water_withdrawal_km3'] * WDI['WLD_ag_share_withdrawal_pct'] / 100
cons_frac = 1200 / ag_wd_W
P['bluewater'] = ag_wd_B * cons_frac; W['bluewater'] = FSB['bluewater']['current_global_tw']
N_in = m(ESB['BFA_N_inputs']) / 1e3; N_out = np.mean(ESB_N_outputs_BFA_2021_2023) / 1e3
Ncrop_all = N_in - N_out; Ncrop = Ncrop_all - cot_Nbal; Ncrop_W = m(ESB['WLD_N_surplus']) / 1e3
Npast_vol = m(EMN['BFA_pasture_vol']) / 1e6; Npast_leach = m(EMN['BFA_pasture_leach']) / 1e6
Npast_W = (m(EMN['WLD_pasture_vol']) + m(EMN['WLD_pasture_leach'])) / 1e6
# agricultural N surplus (te Wierik/EAT-Lancet control variable, cropland + grassland): cropland balance + losses of manure N deposited on pasture
P['N_surplus'] = Ncrop + Npast_vol + Npast_leach; W['N_surplus'] = Ncrop_W + Npast_W          # kt
Nmin = m00(ESB00['N_mineral']) / 1e3; Nbnf = m00(ESB00['N_bnf']) / 1e3
P['N_application'] = Nmin * (1 - f_N) + Nbnf; W['N_application'] = (np.mean(ESB_WLD['N_mineral']) + np.mean(ESB_WLD['N_bnf'])) / 1e3
Pmin = m00(ESB00['P_mineral']) / 1e3
P['P_application'] = Pmin * (1 - f_P); W['P_application'] = np.mean(ESB_WLD['P_mineral']) / 1e3
P['pesticides'] = m(RP['BFA']) / 1e3 * (1 - c_pest); W['pesticides'] = m(RP['WLD']) / 1e3
P['agland'] = (m(RL['BFA_agri']) - np.mean(list(COTTON_AREA.values())) / 1e3) / 1e3; W['agland'] = m(RL['WLD_agri']) / 1e3
N_crop_in_food = N_in - Nmin * f_N
N_past_dep = m(EMN['BFA_pasture_dep']) / 1e6
P['N_inputs'] = N_crop_in_food + N_past_dep; W['N_inputs'] = (np.mean(ESB_WLD_N_inputs) + np.mean(EMN_WLD_pasture_dep) / 1e3) / 1e3
n2o_to_N = 28 / 44 / GWP_N2O_AR5
cot_n2o = (f_N * m00(GT00['synth_fert']) + f_area * m00(GT00['crop_residues'])) * n2o_to_N
P['N2O'] = np.mean(GT_N2O['BFA']) * n2o_to_N - cot_n2o; W['N2O'] = np.mean(GT_N2O['WLD']) * n2o_to_N
D = ['climate', 'agland', 'bluewater', 'N_surplus', 'P_application', 'N2O', 'pesticides']
SENS_ONLY = ['cropland', 'N_application', 'N_inputs']

N_scope = (W['N_surplus'] / 1e3) / FSB['N_surplus']['current_global_tw']   # FAOSTAT cropland surplus / te Wierik agricultural surplus
N_in_scope = (W['N_inputs'] / 1e3) / FSB['N_inputs']['current_global_tw']
n2o_scope = (W['N2O'] / 1e3) / FSB['N2O']['current_global_tw'][1]
FSB['N2O']['tri'] = tuple(1.8 * (W['N2O'] / 1e3) / c / n2o_scope for c in FSB['N2O']['current_global_tw'][::-1])
scale = {'climate': 1e3, 'cropland': 100, 'agland': 100, 'bluewater': 1, 'N_surplus': 1e3 * N_scope, 'N_inputs': 1e3 * N_in_scope,
         'N_application': 1e3, 'P_application': 1e3, 'N2O': 1e3 * n2o_scope, 'pesticides': 1e3}
DA = D + SENS_ONLY
B = {d: FSB[d]['central'] * scale[d] for d in DA}
R.update({'pressure': P, 'world_pressure': W, 'global_boundary_natunits': B, 'global_ratio': {d: W[d] / B[d] for d in DA},
          'N_inputs_parts': {'cropland_food': N_crop_in_food, 'pasture_dep': N_past_dep, 'scope': N_in_scope}, 'N2O_parts': {'cotton_kt': cot_n2o, 'scope': n2o_scope, 'tri': FSB['N2O']['tri']},
          'climate_parts': clim_parts, 'climate_incl_cotton': clim_all, 'N_scope_scale': N_scope,
          'N_parts': {'inputs': N_in, 'outputs': N_out, 'mineral': Nmin, 'bnf': Nbnf}, 'P_parts': {'mineral_all': Pmin},
          'water_parts': {'ag_withdrawal_B': ag_wd_B, 'ag_withdrawal_W': ag_wd_W, 'cons_frac': cons_frac}})

# ---------------- sharing principles ----------------
inc_ratio = WDI['WLD_gdppc_2024'] / WDI['BFA_gdppc_2024']
def share(p, d, pb, pw):
    s = pb / pw
    return {'EPC': s, 'AP': s * inc_ratio, 'GF': P[d] / W[d], 'RE': s * RE_MULT if d == 'climate' else np.nan}[p]
PR = ['EPC', 'AP', 'GF', 'RE']
R['ASR_base'] = {d: {p: P[d] / (share(p, d, popB0, popW0) * B[d]) for p in PR} for d in DA}
R['SOS_base'] = {d: {p: share(p, d, popB0, popW0) * B[d] for p in PR} for d in DA}
R['inc_ratio'] = inc_ratio; R['RE_mult'] = RE_MULT
R['percap'] = {d: {'pressure': P[d] / popB0, 'EPC_boundary': B[d] / popW0} for d in D}

# ---------------- land conversion (te Wierik: halt conversion) ----------------
R['land_conversion'] = {'forest_2000': RL_2000['BFA_forest'], 'forest_2023': RL['BFA_forest'][idx[2023]],
                        'forest_loss_kha_yr': (RL_2000['BFA_forest'] - RL['BFA_forest'][idx[2023]]) / 23,
                        'cropland_2000': RL_2000['BFA_cropland'], 'cropland_2023': RL['BFA_cropland'][idx[2023]],
                        'cropland_gain_kha_yr': (RL['BFA_cropland'][idx[2023]] - RL_2000['BFA_cropland']) / 23,
                        'forest_change_pct': (RL['BFA_forest'][idx[2023]] / RL_2000['BFA_forest'] - 1) * 100,
                        'luc_share_climate': clim_parts['luc'] / clim_all}

# ---------------- dynamics ----------------
MS = [2025, 2050, 2075, 2100]
def des_path(t, scen): return DES0 if scen == 'const' else DES0 + (3000 - DES0) * min(max((t - 2022) / 28, 0), 1)
traj = {s: {d: {t: {'EPC': P[d] / popB0 * UN_POP['WLD'][t] * des_path(t, s) / DES0 / B[d],
                    'fixed_alloc': P[d] / popB0 * UN_POP['BFA'][t] * des_path(t, s) / DES0 / (share0 * B[d])} for t in MS} for d in D} for s in ['const', 'adequate']}
R['traj'] = traj
req = {}
for s in ['const', 'adequate']:
    req[s] = {}
    for d in D:
        req[s][d] = {}
        for t in [2035, 2050]:
            pw = np.interp(t, [2025, 2050], [UN_POP['WLD'][2025], UN_POP['WLD'][2050]])
            asr = P[d] / popB0 * pw * des_path(t, s) / DES0 / B[d]
            req[s][d][t] = {'asr_no_change': asr, 'required_intensity_rate_pct': ((1 / asr) ** (1 / (t - 2022)) - 1) * 100 if asr > 1 else 0.0}
R['required'] = req
# climate excluding land-use change (te Wierik FSB assumes zero LUC CO2): required decline of farm-gate + supply-chain intensity
nonluc = P['climate'] - clim_parts['luc'] * (1 - f_area)
R['required_nonLUC'] = {}
for s_ in ['const', 'adequate']:
    R['required_nonLUC'][s_] = {}
    for t in [2035, 2050]:
        pw = np.interp(t, [2025, 2050], [UN_POP['WLD'][2025], UN_POP['WLD'][2050]])
        asr = nonluc / popB0 * pw * des_path(t, s_) / DES0 / B['climate']
        R['required_nonLUC'][s_][t] = {'asr_no_change': asr, 'required_intensity_rate_pct': ((1 / asr) ** (1 / (t - 2022)) - 1) * 100}
R['nonLUC_pressure'] = nonluc

# ---------------- observed intensity trends (pressure per kcal), 2000-2023 ----------------
def des_year(y):
    if y < 2010: return FBSH_DES[y]
    ks = sorted(FBS_DES['BFA']); return float(np.interp(y, ks, [FBS_DES['BFA'][k] for k in ks]))
kcal = np.array([WDI_POP['BFA'][y] * des_year(y) * 365 for y in Y00])
AG00 = [14582.4, 14603.6, 14606.3, 14660.6, 14736.5, 14850, 14963.3, 15047.4, 15165.9, 15281, 15435, 15613.7, 15711.4, 15966.7, 16109.8, 16278, 16398.8, 16538.7, 16705.7, 16761.8, 16882.8, 16975.9, 17119.7, 17129]
hist = {'climate_nonLUC': (np.array(GT00['farmgate']) + np.array(GT00['prepost'])) / 1e3,
        'agland': np.array(AG00) / 1e3, 'cropland': np.array(RL00_cropland) / 1e3,
        'pesticides': np.array(RP00) / 1e3}
yrs = np.array(Y00, float)
def trend(v, mask):
    x = yrs[mask]; yv = np.log(v[mask]); b, a = np.polyfit(x, yv, 1); res = yv - (a + b * x)
    se = np.sqrt(np.sum(res ** 2) / (len(x) - 2) / np.sum((x - x.mean()) ** 2))
    return {'rate_pct': (np.exp(b) - 1) * 100, 'se_pct': se * 100}
windows = {'2000_2023': yrs >= 2000, '2010_2023': yrs >= 2010, '2000_2019': yrs <= 2019}
TR = {}
for k, v in hist.items():
    TR[k] = {}
    for w, msk in windows.items():
        TR[k][w] = {'intensity': trend(v / kcal, msk), 'absolute': trend(v, msk)}
TR['kcal'] = {w: trend(kcal, msk) for w, msk in windows.items()}
# N2O (agrifood, FAOSTAT GT) only available for 2010 and 2013-2023 in this extraction; FAOSTAT revised livestock numbers in 2020
yy_ = np.array(YEARS, float); kc_ = np.array([WDI_POP['BFA'][y] * des_year(y) * 365 for y in YEARS]); vN2O = np.array(GT['BFA_agrifood_N2O'])
def trend2(v, msk):
    x = yy_[msk]; yv = np.log(v[msk]); b, a = np.polyfit(x, yv, 1); res = yv - (a + b * x)
    return {'rate_pct': (np.exp(b) - 1) * 100, 'se_pct': np.sqrt(np.sum(res ** 2) / (len(x) - 2) / np.sum((x - x.mean()) ** 2)) * 100}
vNs = np.array(ESB['BFA_N_surplus']) / 1e3 - cot_Nbal + (np.array(EMN['BFA_pasture_vol']) + np.array(EMN['BFA_pasture_leach'])) / 1e6
TR['N_surplus'] = {w: {'intensity': trend2(vNs / kc_, msk), 'absolute': trend2(vNs, msk)} for w, msk in {'2010_2023': yy_ >= 2010, '2010_2019': yy_ <= 2019}.items()}
TR['N2O'] = {w: {'intensity': trend2(vN2O / kc_, msk), 'absolute': trend2(vN2O, msk)} for w, msk in {'2010_2023': yy_ >= 2010, '2010_2019': yy_ <= 2019}.items()}
R['trend'] = TR

# ---------------- climate pathways (food-only, cotton removed proportionally) ----------------
fc = P['climate'] / clim_all
base22 = GT['BFA_agrifood'][idx[2022]] / 1e3 * fc; b19 = GT['BFA_agrifood'][idx[2019]] / 1e3 * fc
years = np.arange(2022, 2051)
bau = base22 * (1 + NDC['bau_growth']) ** (years - 2022)
def ir(points): xs = sorted(points); return np.interp(years, xs, [points[x] for x in xs])
ndc = bau * (1 - ir({2022: 0.0, 2030: NDC['red_2030'], 2035: NDC['red_2035'], 2050: NDC['red_2050']}))
def ipcc(cat): return b19 * (1 - ir({2019: 0.0, **IPCC[cat]}))
popB_t = np.interp(years, [2022, 2025, 2050], [popB0, UN_POP['BFA'][2025], UN_POP['BFA'][2050]])
popW_t = np.interp(years, [2022, 2025, 2050], [popW0, UN_POP['WLD'][2025], UN_POP['WLD'][2050]])
bnd = popB_t / popW_t * B['climate']
paths = {'year': years.tolist(), 'BAU': bau.tolist(), 'NDC': ndc.tolist(), 'boundary_EPC': bnd.tolist(),
         **{k: ipcc(k).tolist() for k in ['C1', 'C3', 'C1_lo', 'C1_hi', 'C3_lo', 'C3_hi']}}
R['climate_paths'] = paths
def at(a, y): return float(np.array(a)[years == y][0])
first = {k: (int(years[np.array(paths[k]) / bnd <= 1][0]) if np.any(np.array(paths[k]) / bnd <= 1) else None) for k in ['NDC', 'C1', 'C3', 'C1_hi', 'C3_hi']}
R['climate_summary'] = {'base22': base22, 'b19': b19, 'first_year_within': first,
    **{f'{k}_{y}_{u}': (at(paths[k], y) / at(bnd, y) if u == 'ratio' else at(paths[k], y)) for k in ['BAU', 'NDC', 'C1', 'C3'] for y in [2030, 2050] for u in ['ratio', 'Mt']},
    'NDC_uncond_2030_ratio': at(bau, 2030) * (1 - NDC['uncond_2030']) / at(bnd, 2030), 'boundary_2030': at(bnd, 2030), 'boundary_2050': at(bnd, 2050),
    'required_cut_below_BAU_2050_pct': (1 - at(bnd, 2050) / at(bau, 2050)) * 100,
    'cum_excess_NDC': float(np.sum(np.clip(ndc - bnd, 0, None))), 'cum_excess_C1': float(np.sum(np.clip(ipcc('C1') - bnd, 0, None))),
    'cum_excess_BAU': float(np.sum(np.clip(bau - bnd, 0, None)))}
# sensitivity: agrifood reductions at 50% and 150% of the economy-wide NDC percentages (capped at 100%)
for fct in [0.5, 1.5]:
    nd = bau * (1 - np.clip(fct * ir({2022: 0.0, 2030: NDC['red_2030'], 2035: NDC['red_2035'], 2050: NDC['red_2050']}), 0, 1))
    R['climate_summary'][f'NDC_x{fct}_2030_ratio'] = at(nd, 2030) / at(bnd, 2030); R['climate_summary'][f'NDC_x{fct}_2050_ratio'] = at(nd, 2050) / at(bnd, 2050)
    R['climate_summary'][f'NDC_x{fct}_first_within'] = int(years[nd / bnd <= 1][0]) if np.any(nd / bnd <= 1) else None

# ---------------- Monte Carlo per principle ----------------
N = 20000
def tri(a, c, b, n): return np.full(n, c) if a == b == c else rng.triangular(a, c, b, n)
def ln(mean, cv, n): s = np.sqrt(np.log(1 + cv ** 2)); return rng.lognormal(np.log(mean) - s ** 2 / 2, s, n)
cot_draw = tri(0.5, 1.0, 1.5, N) * cot_clim
# cotton share of pesticide use: active ingredient per dose (triangular) x tender quantities (+-15%), scaled to the national cotton area
ai_draw = {k: tri(*v, N) for k, v in AI_PER_DOSE.items()}
c_pest_draw = np.clip(cotton_pest_kt(ai_draw) * rng.uniform(0.85, 1.15, N) / (RP['BFA'][idx[2022]] / 1e3), 0, 0.95)
cot_Nbal_draw = cotton_Nbal(tri(*N_REMOVAL_SEED_COTTON, N))
R['cotton']['pest_share_p05_p95'] = [float(np.percentile(c_pest_draw, 5)), float(np.percentile(c_pest_draw, 95))]
press = {'climate': ln(clim_parts['farmgate'], 0.30, N) + ln(clim_parts['luc'], 0.50, N) + ln(clim_parts['prepost'], 0.30, N) - cot_draw,
         'cropland': tri(6.0 - R['cotton']['area_Mha'], P['cropland'], P['cropland'] * 1.10, N),
         'bluewater': ag_wd_B * ln(1, 0.25, N) * tri(0.30, cons_frac, 1.0, N),
         'N_surplus': ln(N_in, 0.15, N) - ln(N_out, 0.10, N) - cot_Nbal_draw + ln(Npast_vol, 0.30, N) + Npast_leach * tri(0.0, 1.0, 1.0, N),
         'N_application': ln(Nmin * (1 - f_N), 0.15, N) + ln(Nbnf, 0.30, N),
         'P_application': ln(P['P_application'], 0.15, N),
         'pesticides': ln(m(RP['BFA']) / 1e3, 0.30, N) * (1 - c_pest_draw),
         'agland': tri(P['agland'] * 0.85, P['agland'], P['agland'] * 1.05, N),
         'N_inputs': ln(N_crop_in_food, 0.15, N) + ln(N_past_dep, 0.25, N),
         'N2O': ln(P['N2O'], 0.40, N)}
bdraw = {d: tri(*FSB[d]['tri'], N) * scale[d] for d in D}
MC = {}
for d in D:
    MC[d] = {}
    for p in PR:
        s = share(p, d, popB0, popW0)
        if np.isnan(s): continue
        if p == 'GF':
            asr = W[d] / bdraw[d]; vb, vp = np.var(np.log(asr)), 0.0
        else:
            asr = press[d] / (s * bdraw[d])
            ok = press[d] > 0
            vb = np.var(np.log(P[d] / (s * bdraw[d]))); vp = np.var(np.log(press[d][ok] / (s * B[d])))
        MC[d][p] = {'median': float(np.median(asr)), 'p05': float(np.percentile(asr, 5)), 'p95': float(np.percentile(asr, 95)),
                    'P_exceed': float(np.mean(asr > 1)), 'var_share_boundary': float(vb / (vb + vp)), 'var_share_pressure': float(vp / (vb + vp))}
R['MC'] = MC
R['MC_settings'] = {'N': N, 'notes': 'Variance shares are conditional on the assumed sampling distributions.'}

# ---------------- exploratory and sensitivity indicators ----------------
kP = TW_P['agri'] / (m(ESB['WLD_P_inputs']) / 1e6)
P_inputs_food = m(ESB['BFA_P_inputs']) / 1e3 - Pmin * f_P
P_ww = TW_P['wastewater'] * 1e9 / popW0 * (WDI['BFA_urban_pct_2022'] / WDI['WLD_urban_pct_2022']) * popB0 / 1e6
P_del = kP * P_inputs_food + P_ww
crit = WDI['BFA_internal_renewable_km3'] * P_CRIT_CONC / (1 - P_RIVER_RETENTION) * 0.74
past_loss = (m(EMN['BFA_pasture_vol']) + m(EMN['BFA_pasture_leach'])) / 1e6
past_loss_W = (m(EMN['WLD_pasture_vol']) + m(EMN['WLD_pasture_leach'])) / 1e9
N_agri = P['N_surplus']; N_agri_W = W['N_surplus'] / 1e3
B_agri = 57 * N_agri_W / 119 * 1e3
imp_add = FS['BFA']['cereal_import_dep_pct_2021_2023'] / 100 * CEREAL_SHARE_DES_2021_2023 / DES0
S = {
    'climate_incl_cotton': clim_all / (share0 * B['climate']),
    'climate_no_luc': (P['climate'] - clim_parts['luc'] * (1 - f_area)) / (share0 * B['climate']),
    'climate_farmgate_only': (clim_parts['farmgate'] - (f_N * m00(GT00['synth_fert']) + f_area * (m00(GT00['crop_residues']) + m00(GT00['burning_residues']) + m00(GT00['onfarm_energy']))) / 1e3) / (share0 * B['climate']),
    'climate_import_adjusted': P['climate'] * (1 + imp_add) / (share0 * B['climate']),
    'cropland_sentinel': (6.0 - R['cotton']['area_Mha']) / (share0 * B['cropland']),
    'cropland_incl_cotton': crop_kha / 1e3 / (share0 * B['cropland']),
    'bluewater_willett2500': P['bluewater'] / (share0 * 2500),
    'bluewater_withdrawal': ag_wd_B / (share0 * B['bluewater']),
    'N_surplus_cropland_only': Ncrop / (share0 * 57e3 * (Ncrop_W / 1e3) / 119),
    'N_surplus_no_pasture_leaching': (P['N_surplus'] - Npast_leach) / (share0 * B['N_surplus']),
    'N_surplus_strict43': P['N_surplus'] / (share0 * 43e3 * N_scope),
    'N_application_incl_cotton': (Nmin + Nbnf) / (share0 * B['N_application']),
    'P_application_incl_cotton': Pmin / (share0 * B['P_application']),
    'P_delivery_tW': P_del / (share0 * 4.6e3),
    'P_delivery_local_critical': P_del / crit,
    'pesticides_strict02': P['pesticides'] / (share0 * 200),
    'agland_incl_cotton': m(RL['BFA_agri']) / 1e3 / (share0 * B['agland']),
    'agland_restoration_39_5': P['agland'] / (share0 * 39.5 * 100),
    'cropland_willett13': R['ASR_base']['cropland']['EPC'],
    'N_application_willett90': R['ASR_base']['N_application']['EPC'],
    'N_inputs_EAT134': R['ASR_base']['N_inputs']['EPC'],
    'N_inputs_cropland_only': N_crop_in_food / (share0 * B['N_inputs'] * (np.mean(ESB_WLD_N_inputs) / 1e3) / W['N_inputs']),
    'N_inputs_140': P['N_inputs'] / (share0 * 140e3 * N_in_scope),
    'N2O_incl_cotton': np.mean(GT_N2O['BFA']) * n2o_to_N / (share0 * B['N2O']),
    'pesticides_breakeven_cotton_share': 1 - R['SOS_base']['pesticides']['EPC'] / (m(RP['BFA']) / 1e3),
    'pesticides_incl_cotton': m(RP['BFA']) / 1e3 / R['SOS_base']['pesticides']['EPC'],
    'pesticides_diversion30': m(RP['BFA']) / 1e3 * (1 - (cot_pest - 0.3 * cot_insect) / (RP['BFA'][idx[2022]] / 1e3)) / R['SOS_base']['pesticides']['EPC'],
    'pesticides_cotton_share_low': m(RP['BFA']) / 1e3 * (1 - R['cotton']['pest_share_p05_p95'][0]) / R['SOS_base']['pesticides']['EPC'],
    'N_surplus_incl_cotton': (P['N_surplus'] + cot_Nbal) / (share0 * B['N_surplus']),
    # co-product view: cottonseed (oil for food, cake for feed) carries its mass share of cotton's pressures
    'coproduct_climate': (P['climate'] + R['cotton']['cottonseed_mass_share'] * cot_clim) / (share0 * B['climate']),
    'coproduct_agland': (P['agland'] + R['cotton']['cottonseed_mass_share'] * R['cotton']['area_Mha']) / (share0 * B['agland']),
    'coproduct_N_surplus': (P['N_surplus'] + R['cotton']['cottonseed_mass_share'] * cot_Nbal) / (share0 * B['N_surplus']),
    'coproduct_pesticides': (P['pesticides'] + R['cotton']['cottonseed_mass_share'] * c_pest * m(RP['BFA']) / 1e3) / R['SOS_base']['pesticides']['EPC'],
    'coproduct_P_application': (P['P_application'] + R['cotton']['cottonseed_mass_share'] * f_P * Pmin) / (share0 * B['P_application']),
    'coproduct_N2O': (P['N2O'] + R['cotton']['cottonseed_mass_share'] * cot_n2o) / (share0 * B['N2O']),
    'livestock_export_adjusted_climate': (P['climate'] - clim_parts['farmgate'] * 0.87 * max(exp_frac.values())) / (share0 * B['climate']),
}
R['sens'] = S
R['exploratory'] = {'P_delivery_kt': P_del, 'P_delivery_agri_kt': kP * P_inputs_food, 'P_ww_kt': P_ww, 'kP': kP, 'P_local_boundary_kt': crit,
                    'P_balance_kt': m(ESB['BFA_P_surplus']) / 1e3, 'pasture_N_loss_kt': past_loss, 'N_agri_kt': N_agri, 'N_agri_W_Tg': N_agri_W,
                    'N_inputs_percap_kg': P['N_inputs'] * 1e6 / popB0, 'N_inputs_W_percap_kg': W['N_inputs'] * 1e6 / popW0,
                    'pasture_leach_kt': m(EMN['BFA_pasture_leach']) / 1e6, 'pasture_vol_kt': m(EMN['BFA_pasture_vol']) / 1e6, 'import_add_frac': imp_add}

def conv(o):
    if isinstance(o, dict): return {str(k): conv(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [conv(v) for v in o]
    if isinstance(o, (np.floating, np.integer)): return float(o)
    return o
json.dump(conv(R), open('results.json', 'w'), indent=1)

if __name__ == '__main__':
    print('share0 %.5f DES0 %.0f cotton %s exp %s' % (share0, DES0, R['cotton'], exp_frac))
    for d in D:
        a = R['ASR_base'][d]; mc = MC[d]['EPC']
        print(f"{d:14s} P={P[d]:9.3f} W={W[d]:11.1f} B={B[d]:9.1f} glob={W[d]/B[d]:.2f} SOS={R['SOS_base'][d]['EPC']:.3f} | EPC {a['EPC']:.3f} [{mc['p05']:.2f}-{mc['p95']:.2f}] P>1={mc['P_exceed']:.3f} vb={mc['var_share_boundary']:.2f} | AP {a['AP']:.3g} GF {a['GF']:.3g} RE {a['RE']:.3g}")
    print('traj', {d: [round(traj['const'][d][t]['EPC'], 2) for t in MS] + [round(traj['adequate'][d][2050]['EPC'], 2), round(traj['const'][d][2100]['fixed_alloc'], 2)] for d in D})
    print('trend', json.dumps(conv(TR)))
    print('req', {d: [round(req['const'][d][2035]['required_intensity_rate_pct'], 2), round(req['const'][d][2050]['required_intensity_rate_pct'], 2), round(req['adequate'][d][2050]['required_intensity_rate_pct'], 2)] for d in D})
    print('climate', json.dumps(conv(R['climate_summary'])))
    print('land', R['land_conversion']); print('sens', json.dumps(conv(S))); print('expl', json.dumps(conv(R['exploratory'])))
    print('MC all', {d: {p: (round(v['median'], 3), round(v['P_exceed'], 3)) for p, v in MC[d].items()} for d in D})
