import json, numpy as np, matplotlib
matplotlib.use('Agg')
matplotlib.rcParams['pdf.fonttype'] = 42  # embed TrueType fonts in PDF
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Wedge, Circle, Patch, FancyArrowPatch, Rectangle
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap
from data import *

R = json.load(open('results.json'))
# ---------- academic palette ----------
NAVY, TEAL, GOLD, BRICK, SAGE, PLUM, SLATE = '#1B3A5C', '#2E7D8C', '#C9962B', '#A83C2A', '#5E8C4A', '#6B4E7A', '#5B6770'
INK, INK2, GRID, PAPER = '#1A1A1A', '#4A4F55', '#DADDE1', '#F7F6F2'
SAFE, RISK, HIGH, NQ = '#4F8F5B', '#E3A72F', '#B23A2E', '#C9CCD1'
plt.rcParams.update({'mathtext.fontset': 'custom', 'mathtext.rm': 'Liberation Sans', 'mathtext.it': 'Liberation Sans:italic', 'mathtext.bf': 'Liberation Sans:bold', 'mathtext.default': 'regular', 'font.family': 'Liberation Sans', 'font.size': 8, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2, 'axes.linewidth': 0.6,
                     'axes.titlesize': 8.5, 'hatch.linewidth': 0.5, 'axes.titleweight': 'bold', 'legend.frameon': False, 'savefig.dpi': 600})
D = ['climate', 'agland', 'bluewater', 'N_surplus', 'P_application', 'N2O', 'pesticides']
LAB = {'climate': 'Climate change\n(agrifood GHG)', 'agland': 'Land-system change\n(agricultural land)', 'bluewater': 'Freshwater change\n(blue water)',
       'N_surplus': 'Nitrogen\n(agricultural N surplus)', 'P_application': 'Phosphorus\n(mineral P fertilizer)', 'N2O': 'Stratospheric ozone\n(agrifood N₂O)',
       'pesticides': 'Novel entities\n(pesticides)'}
LAB1 = {k: v.split('\n')[0] for k, v in LAB.items()}
def save(fig, name):
    fig.savefig(f'fig/{name}.png', bbox_inches='tight', dpi=600, facecolor='white')
    fig.savefig(f'fig/{name}.tif', bbox_inches='tight', dpi=600, facecolor='white', pil_kwargs={'compression': 'tiff_lzw'})
    fig.savefig(f'fig/{name}.pdf', bbox_inches='tight', facecolor='white')  # vector version for submission
    plt.close(fig)
def panel(ax, s, x=-0.02, y=1.04):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=10, fontweight='bold', color=INK, va='bottom', ha='right')

# =====================================================================
# Fig. 1 — assessment framework (flowchart)
# =====================================================================
from matplotlib.patches import Ellipse, Polygon
fig, ax = plt.subplots(figsize=(9.3, 4.93)); ax.axis('off')
ax.set_xlim(0, 671); ax.set_ylim(356, 0); ax.set_aspect('equal')   # top-left origin, units ~ points of the layout
LW, FS = 0.9, 8
def box(x, y, w, h, txt, r=8):
    ax.add_patch(FancyBboxPatch((x + r, y + r), w - 2 * r, h - 2 * r, boxstyle=f'round,pad={r}', fc='white', ec=INK, lw=LW))
    ax.text(x + w / 2, y + h / 2, txt, ha='center', va='center', fontsize=FS, color=INK, linespacing=1.25)
def arrow(p0, p1, both=False):
    ax.annotate('', xy=p1, xytext=p0, arrowprops=dict(arrowstyle='<|-|>' if both else '-|>', color=INK, lw=LW, mutation_scale=9, shrinkA=0, shrinkB=0))
# planetary boundaries (diamond) and sharing principles (ellipse) feeding the FSB step
ax.add_patch(Polygon([(140, 4), (176, 40), (140, 76), (104, 40)], closed=True, joinstyle='round', fc='white', ec=INK, lw=LW))
ax.text(140, 40, 'PBs', ha='center', va='center', fontsize=FS, color=INK)
ax.add_patch(Ellipse((140, 291), 104, 100, fc='white', ec=INK, lw=LW))
ax.text(140, 291, 'Sharing Principles:\nEPC, RE, AP and\nGF', ha='center', va='center', fontsize=FS, color=INK, linespacing=1.25)
arrow((140, 76), (140, 241), both=True)
# main chain
box(2, 130, 120, 60, 'Defining FSB\nbiophysical Limits')
box(180, 130, 120, 60, 'Identify National\nprovisioning system\nLimits')
box(360, 130, 110, 60, 'Calculating the SOS')
box(540, 70, 128, 180, '1) Food Security\nAssessment\n2) Uncertainty and\nRobustness\n3) Trajectories and\npolicy benchmark (NDC\nand IPCC Scenarios)', r=14)
arrow((122, 160), (180, 160)); arrow((300, 160), (360, 160)); arrow((470, 160), (540, 160))
# projected pressure-to-boundary assessment
ax.add_patch(Ellipse((413, 302), 106, 104, fc='white', ec=INK, lw=LW))
ax.text(413, 302, 'Pressure to\nBoundary\nAssessment to 2100', ha='center', va='center', fontsize=FS, color=INK, linespacing=1.25)
arrow((413, 190), (413, 250))
save(fig, 'Fig1_framework')

# =====================================================================
# Fig. 2 — planetary-boundary wheel (Rockström/Richardson style)
# =====================================================================
WHEEL = [('Climate\nchange', 'climate'), ('Novel\nentities', 'pesticides'), ('Stratospheric\nozone', 'N2O'), ('Aerosol\nloading', None),
         ('Ocean\nacidification', None), ('Biogeochemical\nflows: N', 'N_surplus'), ('Biogeochemical\nflows: P', 'P_application'),
         ('Freshwater:\nblue water', 'bluewater'), ('Freshwater:\ngreen water', None), ('Land-system\nchange', 'agland'), ('Biosphere\nintegrity', None)]
def rad(x): return np.sqrt(max(x, 0))  # area-proportional radius; boundary at r = 1
RMAX = rad(4.6)
def wheel(ax, vals, unc, title):
    ax.set_xlim(-RMAX - 1.85, RMAX + 1.85); ax.set_ylim(-RMAX - 1.45, RMAX + 1.2); ax.set_aspect('equal'); ax.axis('off')
    for r0, r1, c, a in [(0, 1, SAFE, 0.16), (1, rad(2), RISK, 0.16), (rad(2), RMAX, HIGH, 0.10)]:
        ax.add_patch(Wedge((0, 0), r1, 0, 360, width=r1 - r0, fc=c, alpha=a, ec='none'))
    ax.add_patch(Circle((0, 0), 1, fc='none', ec=SAFE, lw=1.6)); ax.add_patch(Circle((0, 0), rad(2), fc='none', ec=RISK, lw=0.8, ls=(0, (3, 2))))
    n = len(WHEEL); dth = 360 / n
    for i, (lab, k) in enumerate(WHEEL):
        th0 = 90 - (i + 1) * dth + 1.2; th1 = 90 - i * dth - 1.2; mid = np.deg2rad((th0 + th1) / 2)
        if k is None:
            ax.add_patch(Wedge((0, 0), 0.9, th0, th1, fc=NQ, ec='white', lw=0.6, hatch='////', alpha=0.9)); vtxt = 'n.q.'
        else:
            v = vals[k]; r = min(rad(v), RMAX)
            for r0, r1, c in [(0, 1, SAFE), (1, rad(2), RISK), (rad(2), RMAX, HIGH)]:
                if r > r0: ax.add_patch(Wedge((0, 0), min(r, r1), th0, th1, width=min(r, r1) - r0, fc=c, ec='white', lw=0.6))
            if unc is not None:
                lo, hi = unc[k]; r_lo, r_hi = rad(lo), min(rad(hi), RMAX); mo = mid + np.deg2rad(dth * 0.28)
                ax.plot([r_lo * np.cos(mo), r_hi * np.cos(mo)], [r_lo * np.sin(mo), r_hi * np.sin(mo)], color=INK, lw=0.8, solid_capstyle='butt', alpha=0.85)
                for rr in (r_lo, r_hi): ax.plot([rr * np.cos(mo - 0.05), rr * np.cos(mo + 0.05)], [rr * np.sin(mo - 0.05), rr * np.sin(mo + 0.05)], color=INK, lw=0.8)
            vtxt = f'{v:.2f}'
        rl = RMAX + 0.62 + 0.30 * abs(np.sin(mid)) + 0.55 * abs(np.cos(mid))
        ax.text(rl * np.cos(mid), rl * np.sin(mid), lab, ha='center', va='center', fontsize=8, color=INK if k else SLATE, linespacing=1.05)
        rv = (RMAX + 0.12 if k else 0.62)
        ax.text(rv * np.cos(mid), rv * np.sin(mid), vtxt, ha='center', va='center', fontsize=8, fontweight='bold' if k else 'normal', color=INK if k else SLATE,
                bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.85))
    ax.text(0, -RMAX - 1.25, title, ha='center', va='top', fontsize=10, fontweight='bold', color=INK)
v0 = {d: R['ASR_base'][d]['EPC'] for d in D}; u0 = {d: (max(R['MC'][d]['EPC']['p05'], 0.0001), R['MC'][d]['EPC']['p95']) for d in D}
vt = {t: {d: R['traj']['adequate'][d][str(t)]['EPC'] for d in D} for t in (2050, 2075, 2100)}
ut = {t: {d: (u0[d][0] * vt[t][d] / v0[d], u0[d][1] * vt[t][d] / v0[d]) for d in D} for t in (2050, 2075, 2100)}
fig, axs = plt.subplots(2, 2, figsize=(7.4, 8.0)); axs = axs.ravel()
wheel(axs[0], v0, u0, 'a   2021–2023')
for k, t in enumerate((2050, 2075, 2100)): wheel(axs[k + 1], vt[t], ut[t], f'{"bcd"[k]}   {t}')
fig.legend(handles=[Patch(fc=SAFE, label='Within share (ASR ≤ 1)'), Patch(fc=RISK, label='Increasing risk (1–2)'), Patch(fc=HIGH, label='High risk (> 2)'),
                    Patch(fc=NQ, hatch='////', label='Not quantified nationally'), Line2D([], [], color=INK, lw=0.9, label='5th–95th percentile')],
           loc='lower center', ncol=3, fontsize=8, bbox_to_anchor=(0.5, 0.0), handlelength=1.4, columnspacing=1.2)
plt.subplots_adjust(wspace=0.02, hspace=0.04, bottom=0.07, top=0.995, left=0.0, right=1.0); save(fig, 'Fig2_status')

# =====================================================================
# Fig. 3 — climate: emissions by stage, sources, pathways
# =====================================================================
fig = plt.figure(figsize=(7.4, 5.4)); gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.15], width_ratios=[1.15, 1], hspace=0.55, wspace=0.55)
ax = fig.add_subplot(gs[0, 0]); yrs = np.array(YEARS)
parts = [(np.array(GT['BFA_farmgate']) / 1e3, 'Farm gate', NAVY), (np.array(GT['BFA_luc']) / 1e3, 'Land-use change', BRICK), (np.array(GT['BFA_prepost']) / 1e3, 'Pre- and post-production', GOLD)]
bottom = np.zeros(len(yrs))
for v, l, c in parts:
    ax.bar(yrs, v, bottom=bottom, color=c, width=0.72, edgecolor='white', lw=0.4, label=l); bottom += v
bnd = [WDI_POP['BFA'][y] / WDI_POP['WLD'][y] * 5000 for y in yrs]
ax.plot(yrs, bnd, color=SAFE, lw=1.6, marker='o', ms=2.5, label='EPC share of the 5 Gt boundary')
ax.set_ylabel('Mt CO₂eq yr$^{-1}$'); ax.set_ylim(0, 52); ax.set_xticks([2010, 2013, 2015, 2017, 2019, 2021, 2023]); ax.tick_params(axis='x', labelsize=8)
ax.grid(axis='y', color=GRID, lw=0.4); ax.set_axisbelow(True)
ax.legend(fontsize=8, loc='upper left', bbox_to_anchor=(0, -0.13), ncol=2, handlelength=1.2, columnspacing=1.0)
panel(ax, 'a')
ax = fig.add_subplot(gs[0, 1])
src = [('Net forest conversion', 17.15, BRICK), ('Enteric fermentation', 12.95, NAVY), ('Manure left on pasture', 6.16, NAVY), ('Agrifood waste disposal', 2.57, GOLD),
       ('Rice cultivation', 1.38, NAVY), ('Food retail', 1.16, GOLD)]
oth = 44.79 - sum(x[1] for x in src); src.append(('Other sources', oth, SLATE))
yy_ = np.arange(len(src))[::-1]
ax.barh(yy_, [x[1] for x in src], color=[x[2] for x in src], height=0.64, edgecolor='white')
for y_, (n_, v_, c_) in zip(yy_, src): ax.text(v_ + 0.4, y_, f'{v_:.1f}  ({v_ / 44.79 * 100:.0f}%)', va='center', fontsize=8, color=INK2)
ax.set_yticks(yy_); ax.set_yticklabels([x[0] for x in src], fontsize=8); ax.set_xlim(0, 24); ax.set_xlabel('Mt CO₂eq yr$^{-1}$')
ax.grid(axis='x', color=GRID, lw=0.4); ax.set_axisbelow(True); ax.tick_params(axis='y', length=0)
panel(ax, 'b', x=-0.55)
ax = fig.add_subplot(gs[1, :]); P_ = R['climate_paths']; yy = np.array(P_['year'])
ax.fill_between(yy, P_['boundary_EPC'], 0, color=SAFE, alpha=0.08, lw=0)
ax.fill_between(yy, P_['C3_hi'], P_['C3_lo'], color=PLUM, alpha=0.13, lw=0); ax.fill_between(yy, P_['C1_hi'], P_['C1_lo'], color=TEAL, alpha=0.15, lw=0)
ax.plot(yy, P_['BAU'], color=SLATE, lw=1.3, ls=(0, (4, 2))); ax.plot(yy, P_['NDC'], color=BRICK, lw=2.0)
ax.plot(yy, P_['C3'], color=PLUM, lw=1.3); ax.plot(yy, P_['C1'], color=TEAL, lw=1.3); ax.plot(yy, P_['boundary_EPC'], color=SAFE, lw=1.8)
cs = R['climate_summary']; ax.plot(2030, cs['NDC_uncond_2030_ratio'] * cs['boundary_2030'], 'D', ms=4.5, mfc='white', mec=BRICK, mew=1.2, zorder=5)
ax.annotate('NDC 3.0, unconditional', xy=(2030, cs['NDC_uncond_2030_ratio'] * cs['boundary_2030']), xytext=(2031.3, 46), fontsize=8, color=BRICK,
            arrowprops=dict(arrowstyle='-', color=BRICK, lw=0.6))
lab = [('BAU (NDC growth rate)', P_['BAU'][-1], SLATE), ('NDC 3.0, full', P_['NDC'][-1], BRICK), ('IPCC C3 median, 5–95%', P_['C3'][-1], PLUM),
       ('IPCC C1 median, 5–95%', P_['C1'][-1], TEAL), ('EPC boundary', P_['boundary_EPC'][-1], SAFE)]
ys_l = [v for _, v, _ in lab]; order = np.argsort(ys_l); pos = np.array(ys_l, float)
for k in range(1, len(order)):
    i, j = order[k], order[k - 1]
    if pos[i] - pos[j] < 5.2: pos[i] = pos[j] + 5.2
for (t, v, c), p in zip(lab, pos): ax.text(2050.6, p, t, color=c, fontsize=8, va='center', fontweight='bold' if c in (BRICK, SAFE) else 'normal')
fy = cs['first_year_within']
for k_, c_ in [('C1', TEAL), ('C3', PLUM)]:
    y0 = fy[k_]; i0 = list(yy).index(y0); ax.plot(y0, P_['boundary_EPC'][i0], 'o', ms=4, mfc='white', mec=c_, mew=1.2, zorder=6)
    ax.annotate(f'{k_} reaches share, {y0}', xy=(y0, P_['boundary_EPC'][i0]), xytext=(y0 - 6 if k_ == 'C1' else y0 - 4, 5 if k_ == 'C1' else 30), fontsize=8, color=c_,
                arrowprops=dict(arrowstyle='-', color=c_, lw=0.6))
ax.set_ylabel('Food-only agrifood emissions (Mt CO₂eq yr$^{-1}$)'); ax.set_ylim(0, 80); ax.set_xlim(2022, 2050); ax.grid(axis='y', color=GRID, lw=0.4); ax.set_axisbelow(True)
panel(ax, 'c')
save(fig, 'Fig3_climate')

# =====================================================================
# Fig. 4 — principles: annotated heat map
# =====================================================================
PR = ['EPC', 'AP', 'GF', 'RE']; PRL = ['Equal per capita\n(EPC)', 'Ability to pay\n(AP)', 'Grandfathering\n(GF)', 'Responsibility\n(RE)']
cmap = LinearSegmentedColormap.from_list('div', ['#1B3A5C', '#4F7CA8', '#A9C1D9', '#F4F2EE', '#E3B49A', '#C2654A', '#8E2A1E'])
norm = plt.Normalize(-1.5, 1.5)
fig, ax = plt.subplots(figsize=(6.2, 3.9))
M = np.full((len(D), 4), np.nan)
for i, d in enumerate(D):
    for j, p in enumerate(PR):
        v = R['ASR_base'][d].get(p)
        if v is not None and not (isinstance(v, float) and np.isnan(v)): M[i, j] = np.log10(v)
ax.imshow(np.ma.masked_invalid(np.clip(M, -1.5, 1.5)), cmap=cmap, norm=norm, aspect='auto')
for i, d in enumerate(D):
    for j, p in enumerate(PR):
        if np.isnan(M[i, j]):
            ax.add_patch(Rectangle((j - 0.5, i - 0.5), 1, 1, fc='#F3F3F1', ec='#D5D7DA', hatch='///', lw=0, zorder=2))
            ax.text(j, i, 'not applied', ha='center', va='center', fontsize=8, color=SLATE, zorder=3, bbox=dict(boxstyle='round,pad=0.2', fc='#F3F3F1', ec='none')); continue
        v = 10 ** M[i, j]; dark = abs(M[i, j]) > 0.85
        col = 'white' if dark else INK
        ax.text(j, i - 0.13, f'{v:.2f}' if v >= 0.1 else f'{v:.3f}', ha='center', va='center', fontsize=8, fontweight='bold', color=col, zorder=3)
        pe = R['MC'][d][p]['P_exceed']
        ax.text(j, i + 0.24, f'P(>1) = {pe:.2f}', ha='center', va='center', fontsize=8, color=col, zorder=3)
        if v > 1: ax.add_patch(Rectangle((j - 0.47, i - 0.47), 0.94, 0.94, fc='none', ec=INK, lw=1.0, zorder=4))
ax.set_xticks(range(4)); ax.set_xticklabels(PRL, fontsize=8); ax.xaxis.tick_top(); ax.xaxis.set_label_position('top')
ax.set_yticks(range(len(D))); ax.set_yticklabels([LAB[d] for d in D], fontsize=8)
ax.set_xticks(np.arange(-0.5, 4, 1), minor=True); ax.set_yticks(np.arange(-0.5, len(D), 1), minor=True)
ax.grid(which='minor', color='white', lw=2); ax.tick_params(which='both', length=0)
for sp in ax.spines.values(): sp.set_visible(False)
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm); cb = plt.colorbar(sm, ax=ax, fraction=0.04, pad=0.03)
cb.set_ticks(np.log10([0.03, 0.1, 0.3, 1, 3, 10, 30])); cb.set_ticklabels(['0.03', '0.1', '0.3', '1', '3', '10', '30'])
cb.set_label('Absolute sustainability ratio (log scale)', fontsize=8); cb.ax.tick_params(labelsize=8); cb.outline.set_visible(False)
cb.ax.axhline(0, color=INK, lw=0.8)
save(fig, 'Fig4_principles')

# =====================================================================
# Fig. 5 — required vs observed decoupling
# =====================================================================
rows5 = [('Climate change\n(farm gate + supply chain)', 'climate_nonLUC', R['required_nonLUC'], '2000_2023', '2010_2023'),
         ('Land-system change\n(agricultural land)', 'agland', {s_: R['required'][s_]['agland'] for s_ in ['const', 'adequate']}, '2000_2023', '2010_2023'),
         ('Nitrogen\n(agricultural N surplus)', 'N_surplus', {s_: R['required'][s_]['N_surplus'] for s_ in ['const', 'adequate']}, '2010_2019', '2010_2023'),
         ('Stratospheric ozone\n(agrifood N₂O)', 'N2O', {s_: R['required'][s_]['N2O'] for s_ in ['const', 'adequate']}, '2010_2019', '2010_2023'),
         ('Novel entities\n(pesticides)', 'pesticides', {s_: R['required'][s_]['pesticides'] for s_ in ['const', 'adequate']}, '2000_2023', '2010_2023')]
fig, ax = plt.subplots(figsize=(7.4, 3.5)); ys = np.arange(len(rows5))[::-1]
ax.axvspan(-11, 0, color=SAFE, alpha=0.05, lw=0); ax.axvspan(0, 10, color=HIGH, alpha=0.05, lw=0)
for y, (lab, k, rq, w1, w2) in zip(ys, rows5):
    o1 = R['trend'][k][w1]['intensity']; o2 = R['trend'][k][w2]['intensity']
    r1 = rq['const']['2050']['required_intensity_rate_pct']; r2 = rq['adequate']['2050']['required_intensity_rate_pct']; r35 = rq['const']['2035']['required_intensity_rate_pct']
    best = min(o1['rate_pct'], o2['rate_pct'])
    ax.annotate('', xy=(r2, y), xytext=(best, y), arrowprops=dict(arrowstyle='-|>', color=BRICK if best > r2 else SAFE, lw=1.4, mutation_scale=9))
    for o, mk, dy, fc in [(o1, 'o', 0.13, INK2), (o2, 's', -0.13, 'white')]:
        ax.errorbar(o['rate_pct'], y + dy, xerr=1.96 * o['se_pct'], fmt=mk, color=INK2, mfc=fc, ms=5.5, capsize=2, lw=0.9, zorder=4)
    ax.plot([r1, r2], [y, y], color=NAVY, lw=4, alpha=0.35, solid_capstyle='round', zorder=2); ax.plot(r2, y, 'v', color=NAVY, ms=6.5, zorder=5)
    ax.plot(r35, y, marker='|', color=PLUM, ms=11, mew=1.8, zorder=5)
    gap = r2 - best
    ax.text(1.015, y, f'{-gap:.1f} pp yr$^{{-1}}$' if gap < 0 else 'met', fontsize=8, va='center', ha='left', color=BRICK if gap < 0 else SAFE, fontweight='bold', transform=ax.get_yaxis_transform())
    ax.text(-10.8, y + 0.33, f'● {w1.replace("_", "–")}   □ {w2.replace("_", "–")}', fontsize=8, color=SLATE)
ax.axvline(0, color=INK, lw=0.7)
ax.text(1.015, len(rows5) - 0.45, 'Gap to\n2050', fontsize=8, color=INK2, fontweight='bold', transform=ax.get_yaxis_transform(), va='center')
ax.set_yticks(ys); ax.set_yticklabels([r[0] for r in rows5], fontsize=8); ax.set_xlim(-11, 10); ax.set_ylim(-0.6, len(rows5) - 0.25)
ax.set_xlabel('Annual change in pressure per kilocalorie supplied (% yr$^{-1}$)'); ax.grid(axis='x', color=GRID, lw=0.4); ax.set_axisbelow(True)
ax.legend(handles=[Line2D([], [], marker='o', color=INK2, ls='', label='Observed, long window (95% CI)'), Line2D([], [], marker='s', mfc='white', color=INK2, ls='', label='Observed, recent window'),
                   Line2D([], [], color=NAVY, lw=4, alpha=0.35, label='Required by 2050 (constant → adequate diet)'), Line2D([], [], marker='|', color=PLUM, ls='', ms=9, mew=1.8, label='Required by 2035'),
                   Line2D([], [], color=BRICK, lw=1.4, marker='>', ms=4, label='Gap to close')], fontsize=8, ncol=3, loc='upper left', bbox_to_anchor=(0, -0.16))
ax.text(-5.5, len(rows5) - 0.42, 'decoupling', fontsize=8, color=SAFE, ha='center', style='italic'); ax.text(5, len(rows5) - 0.42, 'recoupling', fontsize=8, color=HIGH, ha='center', style='italic')
save(fig, 'Fig5_decoupling')

# =====================================================================
# Fig. 7 — uncertainty & sensitivity (Fig. 6, the production-pathway scenarios, is drawn by fig_scen.py)
# =====================================================================
fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.7), gridspec_kw={'width_ratios': [1, 1.35]})
ax = axs[0]; ys = np.arange(len(D))[::-1]
for y, d in zip(ys, D):
    vb = R['MC'][d]['EPC']['var_share_boundary']; vp = R['MC'][d]['EPC']['var_share_pressure']
    ax.barh(y, vb * 100, color=NAVY, height=0.62, edgecolor='white', lw=0.8); ax.barh(y, vp * 100, left=vb * 100, color=GOLD, height=0.62, edgecolor='white', lw=0.8)
    if vb > 0.07: ax.text(vb * 50, y, f'{vb * 100:.0f}', ha='center', va='center', fontsize=8, color='white')
    ax.text(vb * 100 + vp * 50, y, f'{vp * 100:.0f}', ha='center', va='center', fontsize=8, color=INK)
ax.set_yticks(ys); ax.set_yticklabels([LAB1[d] for d in D], fontsize=8); ax.set_xlim(0, 100); ax.set_xlabel('Share of variance of log ASR (%), EPC')
ax.legend(handles=[Patch(color=NAVY, label='Global boundary value'), Patch(color=GOLD, label='National pressure data')], fontsize=8, loc='upper left', bbox_to_anchor=(0, -0.14))
panel(ax, 'a')
ax = axs[1]; S = R['sens']
rows = [('Climate: include cotton', 'climate', S['climate_incl_cotton']), ('Climate: exclude land-use change', 'climate', S['climate_no_luc']),
        ('Climate: add imported cereals', 'climate', S['climate_import_adjusted']), ('Land: restoration target (39.5 Mkm²)', 'agland', S['agland_restoration_39_5']),
        ('Land: Willett cropland (13 Mkm²)', 'agland', S['cropland_willett13']), ('Blue water: withdrawal = use', 'bluewater', S['bluewater_withdrawal']),
        ('N surplus: cropland only', 'N_surplus', S['N_surplus_cropland_only']), ('N surplus: no pasture leaching', 'N_surplus', S['N_surplus_no_pasture_leaching']),
        ('N surplus: strict 43 Tg boundary', 'N_surplus', S['N_surplus_strict43']), ('N: EAT–Lancet N inputs (134 Tg)', 'N_surplus', S['N_inputs_EAT134']),
        ('P: delivery vs local critical load', 'P_application', S['P_delivery_local_critical']), ('Pesticides: include cotton', 'pesticides', S['pesticides_incl_cotton']),
        ('Pesticides: low cotton share (5th pct)', 'pesticides', S['pesticides_cotton_share_low']), ('Pesticides: 0.2 Tg boundary', 'pesticides', S['pesticides_strict02'])]
ys = np.arange(len(rows))[::-1]
ax.axvspan(0.01, 1, color=SAFE, alpha=0.06, lw=0); ax.axvspan(1, 2, color=RISK, alpha=0.08, lw=0); ax.axvspan(2, 20, color=HIGH, alpha=0.06, lw=0)
for y, (l, d, v) in zip(ys, rows):
    c0 = R['ASR_base'][d]['EPC']
    ax.annotate('', xy=(v, y), xytext=(c0, y), arrowprops=dict(arrowstyle='-|>', color=SLATE, lw=0.8, mutation_scale=7))
    ax.plot(c0, y, 'o', mfc='white', mec=INK2, ms=5, zorder=3); ax.plot(v, y, 'o', color=HIGH if v > 2 else RISK if v > 1 else SAFE, ms=6, mec='white', zorder=4)
ax.axvline(1, color=SAFE, lw=1.2); ax.set_xscale('log'); ax.set_xlim(0.02, 10); ax.minorticks_off()
ax.set_xticks([0.03, 0.1, 0.3, 1, 2, 5]); ax.set_xticklabels(['0.03', '0.1', '0.3', '1', '2', '5'])
ax.set_yticks(ys); ax.set_yticklabels([r[0] for r in rows], fontsize=8); ax.set_xlabel('ASR, EPC (log scale)')
ax.legend(handles=[Line2D([], [], marker='o', mfc='white', mec=INK2, ls='', label='Central'), Line2D([], [], marker='o', color=SAFE, ls='', label='Alt. ≤ 1'),
                   Line2D([], [], marker='o', color=RISK, ls='', label='Alt. 1–2'), Line2D([], [], marker='o', color=HIGH, ls='', label='Alt. > 2')], fontsize=8, ncol=4, loc='upper left', bbox_to_anchor=(-0.4, -0.14))
panel(ax, 'b')
plt.tight_layout(); save(fig, 'Fig7_uncertainty')

# =====================================================================
# SI: pressure series
# =====================================================================
fig, axs = plt.subplots(2, 3, figsize=(7.4, 4.4)); yrs = np.array(YEARS)
series = [('Agrifood GHG (Mt CO₂eq)', np.array(GT['BFA_agrifood']) / 1e3, NAVY), ('Agricultural land (Mha)', np.array(RL['BFA_agri']) / 1e3, SAGE),
          ('Forest land (Mha)', np.array(RL['BFA_forest']) / 1e3, BRICK), ('Agricultural N surplus (kt N)', np.array(ESB['BFA_N_surplus']) / 1e3 + (np.array(EMN['BFA_pasture_vol']) + np.array(EMN['BFA_pasture_leach'])) / 1e6, TEAL),
          ('Cropland P balance (kt P)', np.array(ESB['BFA_P_surplus']) / 1e3, GOLD), ('Pesticide use (kt)', np.array(RP['BFA']) / 1e3, PLUM)]
for ax, (t, v, c) in zip(axs.flat, series):
    ax.fill_between(yrs, v, min(0, v.min()) if v.min() < 0 else v.min() * 0.9, color=c, alpha=0.12, lw=0); ax.plot(yrs, v, '-o', color=c, ms=3, lw=1.5)
    ax.set_title(t, fontsize=7.2, loc='left'); ax.grid(axis='y', color=GRID, lw=0.4); ax.set_xticks([2010, 2015, 2020]); ax.tick_params(labelsize=6.3)
    if v.min() < 0: ax.axhline(0, color=INK2, lw=0.5)
plt.tight_layout(); save(fig, 'FigS2_pressure_series')
print('ok')
