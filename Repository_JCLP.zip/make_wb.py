import json, numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter as L
from data import *
R = json.load(open('results.json')); NL = json.load(open('N_local.json'))
wb = Workbook()
BLUE = Font(color='0000FF'); BOLD = Font(bold=True); HDR = PatternFill('solid', fgColor='E8E6E1')
def hdr(ws, row, vals):
    for j, v in enumerate(vals, 1):
        c = ws.cell(row, j, v); c.font = BOLD; c.fill = HDR
def widths(ws, w):
    for j, x in enumerate(w, 1): ws.column_dimensions[L(j)].width = x

ws = wb.active; ws.title = 'README'
for i, t in enumerate([
    'Calculation workbook for "Can a fast-growing, food-insecure country feed itself within its fair share of the food-system boundaries? A dynamic assessment to 2100": food-system boundaries of te Wierik et al. (2025), EAT-Lancet Commission (2025) Table 2, and Willett et al. (2019)',
    'Blue font = official input (FAOSTAT and World Bank). Black = formula. Grey = headers. Base period: 2021- 2023 mean; food only.',
    'Sheets: Inputs_FAOSTAT, Inputs_Other, Boundaries, Pressures (formulas), ASR (shares, SOS, ASR by principle; formulas), Trajectories (formulas),',
    'Decoupling, ClimatePaths, MonteCarlo, Sensitivity modeling',
    'Scenario_inputs, Scenarios, Scenario_sensitivity: 30 diet x trade x cereal-yield production pathways to 2050 and 2100 (values from scen.py; main text Section 2.6 and Tables 3 and 6; Supplementary Section S8)',
    'FAOSTAT area codes: Burkina Faso 233, World 5000'], 1):
    ws.cell(i, 1, t)
ws.cell(1, 1).font = BOLD; widths(ws, [150])

ws = wb.create_sheet('Inputs_FAOSTAT')
hdr(ws, 1, ['Series', 'Unit', 'Domain / item / element'] + YEARS)
series = [('BFA agrifood GHG', 'kt CO2eq', 'GT 6518 / 723113', GT['BFA_agrifood']), ('BFA farm gate GHG', 'kt CO2eq', 'GT 6996', GT['BFA_farmgate']),
          ('BFA land-use change GHG', 'kt CO2eq', 'GT 6516', GT['BFA_luc']), ('BFA pre/post-production GHG', 'kt CO2eq', 'GT 6517', GT['BFA_prepost']),
          ('BFA agrifood N2O', 'kt CO2eq', 'GT 6518 / 724313', GT['BFA_agrifood_N2O']), ('World agrifood GHG', 'kt CO2eq', 'GT 6518', GT['WLD_agrifood']),
          ('BFA agricultural land', '1000 ha', 'RL 6610 / 5110', RL['BFA_agri']), ('World agricultural land', '1000 ha', 'RL 6610 / 5110', RL['WLD_agri']),
          ('BFA cropland', '1000 ha', 'RL 6620', RL['BFA_cropland']), ('BFA forest land', '1000 ha', 'RL 6646', RL['BFA_forest']), ('World cropland', '1000 ha', 'RL 6620', RL['WLD_cropland']),
          ('BFA cropland N inputs', 't N', 'ESB 5079 / 7275', ESB['BFA_N_inputs']), ('BFA cropland mineral N', 't N', 'ESB 5087 / 7275', ESB['BFA_N_mineral']),
          ('BFA cropland N balance', 't N', 'ESB 5081 / 7275', ESB['BFA_N_surplus']), ('World cropland N balance', 't N', 'ESB 5081 / 7275', ESB['WLD_N_surplus']),
          ('BFA manure N deposited on pasture', 'kg N', 'EMN 1755 / 72380', EMN['BFA_pasture_dep']),
          ('BFA pasture manure N volatilized', 'kg N', 'EMN 1755 / volatilization', EMN['BFA_pasture_vol']), ('BFA pasture manure N leached', 'kg N', 'EMN 1755 / leaching', EMN['BFA_pasture_leach']),
          ('World pasture manure N volatilized', 'kg N', 'EMN 1755 / volatilization', EMN['WLD_pasture_vol']), ('World pasture manure N leached', 'kg N', 'EMN 1755 / leaching', EMN['WLD_pasture_leach']),
          ('BFA mineral P', 't P', 'ESB 5087 / 7280', [ESB00['P_mineral'][Y00.index(y)] for y in YEARS]), ('BFA cropland P balance', 't P', 'ESB 5081 / 7280', ESB['BFA_P_surplus']),
          ('BFA pesticide use', 't', 'RP 1357 / 5157', RP['BFA']), ('World pesticide use', 't', 'RP 1357 / 5157', RP['WLD'])]
rowof = {}
for i, (n, u, src, v) in enumerate(series, 2):
    ws.cell(i, 1, n); ws.cell(i, 2, u); ws.cell(i, 3, src)
    for j, x in enumerate(v): ws.cell(i, 4 + j, float(x)).font = BLUE
    rowof[n] = i
widths(ws, [36, 10, 20] + [11] * len(YEARS))
bc = [L(4 + YEARS.index(y)) for y in [2021, 2022, 2023]]
def avg(name): r = rowof[name]; return f"AVERAGE(Inputs_FAOSTAT!{bc[0]}{r}:{bc[2]}{r})"

wo = wb.create_sheet('Inputs_Other')
hdr(wo, 1, ['Parameter', 'Value', 'Unit', 'Source'])
other = [('pop_BFA_2021_2023', np.mean([WDI_POP['BFA'][y] for y in [2021, 2022, 2023]]), 'persons', 'WDI SP.POP.TOTL'),
         ('pop_WLD_2021_2023', np.mean([WDI_POP['WLD'][y] for y in [2021, 2022, 2023]]), 'persons', 'WDI SP.POP.TOTL'),
         ('water_withdrawal_BFA', WDI['BFA_water_withdrawal_km3'], 'km3/yr', 'AQUASTAT via WDI ER.H2O.FWTL.K3'), ('ag_share_withdrawal_BFA', WDI['BFA_ag_share_withdrawal_pct'], '%', 'ER.H2O.FWAG.ZS'),
         ('water_withdrawal_WLD', WDI['WLD_water_withdrawal_km3'], 'km3/yr', 'ER.H2O.FWTL.K3 (2022)'), ('ag_share_withdrawal_WLD', WDI['WLD_ag_share_withdrawal_pct'], '%', 'ER.H2O.FWAG.ZS (2022)'),
         ('global_irrigation_consumptive', 1200, 'km3/yr', 'te Wierik et al. (2025)'), ('global_bluewater_consumptive_current', 1500, 'km3/yr', 'te Wierik et al. (2025)'),
         ('gdppc_BFA_2024', WDI['BFA_gdppc_2024'], 'USD', 'NY.GDP.PCAP.CD'), ('gdppc_WLD_2024', WDI['WLD_gdppc_2024'], 'USD', 'NY.GDP.PCAP.CD'),
         ('RE_multiplier', RE_MULT, '-', 'World/national cumulative fossil CO2 (1750-2022) per 2022 capita; GCB (Friedlingstein et al. 2023) via OWID'), ('N_inputs_current_global_tw', 233, 'Tg N/yr', 'EAT-Lancet 2025; Schulte-Uebbing et al. (2022)'),
         ('N_surplus_current_global_tw', 119, 'Tg N/yr', 'Schulte-Uebbing et al. (2022)'), ('N2O_current_global_tw', 4.05, 'Tg N2O-N/yr', 'EAT-Lancet 2025 (3.9-4.2)'),
         ('cotton_area_Mha', R['cotton']['area_Mha'], 'Mha', 'FAOSTAT QCL 328, 2021-2023'), ('cotton_N_share', R['cotton']['f_N'], '-', 'Ludemann et al. (2022), 2015-2017'),
         ('cotton_P_share', R['cotton']['f_P'], '-', 'Ludemann et al. (2022), 2015-2017'), ('cotton_climate_Mt', R['cotton']['climate_Mt'], 'Mt CO2eq', 'model.py'),
         ('cotton_N2O_ktN', R['N2O_parts']['cotton_kt'], 'kt N2O-N', 'model.py'),
         ('cotton_pesticide_share_2022', R['cotton']['pest_share_2022'], '-', 'Bottom-up from SOFITEX 2022/23 input tender, scaled to national cotton area (model.py)'),
         ('cotton_N_balance_kt', R['cotton']['N_balance_kt'], 'kt N', 'Mineral N (IFA share) + area share of manure, deposition, seed - N in seed cotton (model.py)'),
         ('World_N_inputs_FAO_Tg', R['world_pressure']['N_inputs'] / 1e3, 'Tg N', 'FAOSTAT ESB 5079 + EMN 72380, 2021-2023'),
         ('World_N2O_FAO_TgN', R['world_pressure']['N2O'] / 1e3, 'Tg N2O-N', 'FAOSTAT GT, 2021-2023'), ('World_mineral_P_Tg', R['world_pressure']['P_application'] / 1e3, 'Tg P', 'FAOSTAT ESB, 2021-2023'),
         ('DES_BFA_2021_2023', R['base']['DES0'], 'kcal/cap/d', 'FAOSTAT FBS')] + \
        [(f'UN_{c}_{t}', UN_POP[c][t], 'persons', 'UN WPP 2024') for c in ['BFA', 'WLD'] for t in [2025, 2050, 2075, 2100]]
O = {}
for i, (k, v, u, s_) in enumerate(other, 2):
    wo.cell(i, 1, k); wo.cell(i, 2, float(v)).font = BLUE; wo.cell(i, 3, u); wo.cell(i, 4, s_); O[k] = f'Inputs_Other!$B${i}'
widths(wo, [38, 16, 12, 60])

DOM = ['climate', 'agland', 'bluewater', 'N_surplus', 'P_application', 'N2O', 'pesticides', 'N_inputs']  # last row: sensitivity only
f = {}
f['climate'] = (f'={avg("BFA agrifood GHG")}/1000-{O["cotton_climate_Mt"]}', f'={avg("World agrifood GHG")}/1000', 'Mt CO2eq/yr', 'Agrifood systems minus cotton')
f['agland'] = (f'={avg("BFA agricultural land")}/1000-{O["cotton_area_Mha"]}', f'={avg("World agricultural land")}/1000', 'Mha', 'Agricultural land minus cotton')
f['bluewater'] = (f'={O["water_withdrawal_BFA"]}*{O["ag_share_withdrawal_BFA"]}/100*{O["global_irrigation_consumptive"]}/({O["water_withdrawal_WLD"]}*{O["ag_share_withdrawal_WLD"]}/100)',
                  f'={O["global_bluewater_consumptive_current"]}', 'km3/yr', 'Ag withdrawal x global consumptive fraction')
f['N_inputs'] = (f'={avg("BFA cropland N inputs")}/1000-{O["cotton_N_share"]}*{avg("BFA cropland mineral N")}/1000+{avg("BFA manure N deposited on pasture")}/1e6',
                 f'={O["World_N_inputs_FAO_Tg"]}*1000', 'kt N/yr', 'Sensitivity: EAT-Lancet input translation (cropland inputs minus cotton mineral N + pasture deposition)')
f['N_surplus'] = (f'={avg("BFA cropland N balance")}/1000-{O["cotton_N_balance_kt"]}+({avg("BFA pasture manure N volatilized")}+{avg("BFA pasture manure N leached")})/1e6',
                  f'={avg("World cropland N balance")}/1000+({avg("World pasture manure N volatilized")}+{avg("World pasture manure N leached")})/1e6', 'kt N/yr',
                  'Eq. 1: cropland N balance minus cotton + N volatilized and leached from manure on pasture')
f['P_application'] = (f'={avg("BFA mineral P")}/1000*(1-{O["cotton_P_share"]})', f'={O["World_mineral_P_Tg"]}*1000', 'kt P/yr', 'Mineral P minus cotton')
f['N2O'] = (f'={avg("BFA agrifood N2O")}*28/44/265-{O["cotton_N2O_ktN"]}', f'={O["World_N2O_FAO_TgN"]}*1000', 'kt N2O-N/yr', 'Agrifood N2O minus cotton')
f['pesticides'] = (f'={avg("BFA pesticide use")}/1000*(1-{O["cotton_pesticide_share_2022"]})', f'={avg("World pesticide use")}/1000', 'kt/yr', 'Pesticides minus cotton share')
wp = wb.create_sheet('Pressures'); hdr(wp, 1, ['Indicator', 'National pressure', 'World pressure', 'Unit', 'Note', 'Python check'])
PRS = {}
for i, d in enumerate(DOM, 2):
    wp.cell(i, 1, d); wp.cell(i, 2, f[d][0]); wp.cell(i, 3, f[d][1]); wp.cell(i, 4, f[d][2]); wp.cell(i, 5, f[d][3]); wp.cell(i, 6, R['pressure'][d])
    PRS[d] = (f'Pressures!$B${i}', f'Pressures!$C${i}')
widths(wp, [14, 18, 18, 14, 60, 14])

wbd = wb.create_sheet('Boundaries')
hdr(wbd, 1, ['Indicator', 'Central', 'Lower', 'Mode', 'Upper', 'Unit', 'Factor to national units', 'Central in national units'])
FAC = {'climate': '1000', 'agland': '100', 'bluewater': '1', 'N_inputs': f'={PRS["N_inputs"][1]}/1000/{O["N_inputs_current_global_tw"]}*1000',
       'N_surplus': f'={PRS["N_surplus"][1]}/1000/{O["N_surplus_current_global_tw"]}*1000', 'P_application': '1000', 'N2O': f'={PRS["N2O"][1]}/1000/{O["N2O_current_global_tw"]}*1000', 'pesticides': '1000'}
B = {}
for i, d in enumerate(DOM, 2):
    fb = FSB[d]; tri_ = fb.get('tri') or tuple(R['N2O_parts']['tri'])
    wbd.cell(i, 1, d)
    for j, v in enumerate([fb['central'], *tri_], 2): wbd.cell(i, j, float(v)).font = BLUE
    wbd.cell(i, 6, fb['unit']); fac = FAC[d]; wbd.cell(i, 7, fac if fac.startswith('=') else float(fac)); wbd.cell(i, 8, f'=B{i}*G{i}')
    B[d] = f'Boundaries!$H${i}'
widths(wbd, [14, 9, 9, 9, 9, 60, 22, 22])

wa = wb.create_sheet('ASR')
hdr(wa, 1, ['Indicator', 'Pop share', 'Share EPC', 'Share AP', 'Share GF', 'Share RE', 'SOS EPC', 'SOS AP', 'SOS GF', 'SOS RE', 'ASR EPC', 'ASR AP', 'ASR GF', 'ASR RE', 'World ratio', 'Python ASR EPC'])
for i, d in enumerate(DOM, 2):
    p, w = PRS[d]
    wa.cell(i, 1, d); wa.cell(i, 2, f'={O["pop_BFA_2021_2023"]}/{O["pop_WLD_2021_2023"]}')
    wa.cell(i, 3, f'=B{i}'); wa.cell(i, 4, f'=B{i}*{O["gdppc_WLD_2024"]}/{O["gdppc_BFA_2024"]}'); wa.cell(i, 5, f'={p}/{w}')
    wa.cell(i, 6, f'=B{i}*{O["RE_multiplier"]}' if d == 'climate' else 'n.a.')
    for k, col in enumerate(['C', 'D', 'E'], 7): wa.cell(i, k, f'={col}{i}*{B[d]}')
    wa.cell(i, 10, f'=F{i}*{B[d]}' if d == 'climate' else 'n.a.')
    for k, col in enumerate(['G', 'H', 'I'], 11): wa.cell(i, k, f'={p}/{col}{i}')
    wa.cell(i, 14, f'={p}/J{i}' if d == 'climate' else 'n.a.'); wa.cell(i, 15, f'={w}/{B[d]}'); wa.cell(i, 16, R['ASR_base'][d]['EPC'])
widths(wa, [14] + [12] * 15)

wt = wb.create_sheet('Trajectories')
hdr(wt, 1, ['Indicator', 'Diet scenario', 'ASR 2025', 'ASR 2050', 'ASR 2075', 'ASR 2100', 'Formula: P/pop0 x popW_t x DES_t/DES0 / B'])
r = 2
for d in DOM:
    for sc in ['const', 'adequate']:
        wt.cell(r, 1, d); wt.cell(r, 2, 'constant 2,738 kcal' if sc == 'const' else 'adequate: 3,000 kcal by 2050')
        for j, t in enumerate([2025, 2050, 2075, 2100], 3):
            des = '1' if sc == 'const' else f'({O["DES_BFA_2021_2023"]}+(3000-{O["DES_BFA_2021_2023"]})*{min(max((t - 2022) / 28, 0), 1)})/{O["DES_BFA_2021_2023"]}'
            wt.cell(r, j, f'={PRS[d][0]}/{O["pop_BFA_2021_2023"]}*{O["UN_WLD_" + str(t)]}*{des}/{B[d]}')
        r += 1
widths(wt, [14, 30, 10, 10, 10, 10, 50])

def vs(name, header, rows, w):
    s = wb.create_sheet(name); hdr(s, 1, header)
    for i, row in enumerate(rows, 2):
        for j, v in enumerate(row, 1): s.cell(i, j, v)
    widths(s, w)
rows = []
for lab, k in [('climate (farm gate + supply chain)', 'climate_nonLUC'), ('agricultural land', 'agland'), ('cropland', 'cropland'), ('agricultural N surplus', 'N_surplus'), ('N2O', 'N2O'), ('pesticides', 'pesticides')]:
    for w_, v in R['trend'][k].items(): rows.append([lab, 'observed ' + w_, v['intensity']['rate_pct'], v['intensity']['se_pct'], v['absolute']['rate_pct']])
for lab, k in [('climate (farm gate + supply chain)', None), ('agricultural land', 'agland'), ('agricultural N surplus', 'N_surplus'), ('N2O', 'N2O'), ('pesticides', 'pesticides')]:
    q = R['required_nonLUC'] if k is None else {s_: R['required'][s_][k] for s_ in R['required']}
    rows.append([lab, 'required', q['const']['2035']['required_intensity_rate_pct'], q['const']['2050']['required_intensity_rate_pct'], q['adequate']['2050']['required_intensity_rate_pct']])
vs('Decoupling', ['Indicator', 'Observed window / required', 'Observed intensity %/yr | required to 2035 (const)', 'Observed SE | required to 2050 (const)', 'Observed absolute %/yr | required to 2050 (adequate)'], rows, [34, 26, 40, 36, 44])
cp = R['climate_paths']
vs('ClimatePaths', ['Year', 'EPC boundary', 'BAU', 'NDC full', 'C1 median', 'C1 most reduction', 'C1 least reduction', 'C3 median', 'C3 most reduction', 'C3 least reduction'],
   [[cp['year'][i], cp['boundary_EPC'][i], cp['BAU'][i], cp['NDC'][i], cp['C1'][i], cp['C1_hi'][i], cp['C1_lo'][i], cp['C3'][i], cp['C3_hi'][i], cp['C3_lo'][i]] for i in range(len(cp['year']))], [8] + [14] * 9)
vs('MonteCarlo', ['Indicator', 'Principle', 'Median ASR', 'P05', 'P95', 'P(ASR>1)', 'Variance share: boundary', 'Variance share: pressure'],
   [[d, p, mc['median'], mc['p05'], mc['p95'], mc['P_exceed'], mc['var_share_boundary'], mc['var_share_pressure']] for d in DOM if d in R['MC'] for p, mc in R['MC'][d].items()], [14, 10, 12, 10, 10, 10, 22, 22])
vs('Sensitivity', ['Case', 'EPC ratio / value'], [[k, v] for k, v in R['sens'].items() if not k.startswith('coproduct_') and k != 'pesticides_diversion30'] +
   [['N local test (te Wierik/Schulte-Uebbing raster): share of agricultural cells exceeding critical surplus', NL['share_exceeded']], ['N local test: median exceedance (kg N/ha/yr)', NL['median']]], [80, 16])

# ---------------- production-pathway scenarios (scen.py) ----------------
SC = json.load(open('scen.json')); M = SC['meta']; GR = SC['grid']
DN = {'current': 'Current diet', 'adequate': 'Adequate, current mix', 'PHD': 'Planetary health diet (PHD)', 'PHDmono': 'PHD-poultry', 'world': 'World-average mix'}
TRN = {'current': 'imports as today', 'self': 'full self-sufficiency'}; YN = {'current': 'current yields', 'Yw50': '50% of Yw', 'Yw80': '80% of Yw'}
grp = [('cereals', 'Cereals'), ('roots', 'Starchy roots'), ('sugar', 'Sugar and sweeteners'), ('pulses', 'Pulses'), ('oil', 'Oilseeds, nuts, and vegetable oils'),
       ('vegetables', 'Vegetables'), ('fruits', 'Fruits'), ('other', 'Spices and stimulants'), ('alcohol', 'Alcoholic beverages'), ('rum', 'Ruminant products'),
       ('mono', 'Pork, poultry, and eggs'), ('fish', 'Fish and seafood')]
rows = [[gl] + [round(M['diets'][k][g], 1) for k in DN] for g, gl in grp]
rows += [['Unallocated items'] + [round(M['resid0'], 1)] * len(DN), ['Total'] + [round(sum(M['diets'][k].values()) + M['resid0'], 1) for k in DN],
         ['Animal-source share (%)'] + [round(100 * M['animal_share'][k], 1) for k in DN], [], ['Parameter', 'Value', 'Source']]
rows += [[f'SSR, {k}', round(v, 3), 'FAOSTAT FBS, 2021-2023'] for k, v in M['ssr0'].items()]
rows += [['SSR, ruminant products (kcal-weighted)', round(M['SSR_R0'], 3), 'FAOSTAT FBS'], ['Vegetable-oil extraction rate (t oil / t oilseed)', round(M['oil_extraction'], 3), 'FAOSTAT FBS']]
rows += [[f'{c_.capitalize()}: actual yield (t/ha)', round(M['Ya'][c_], 2), 'FAOSTAT QCL, 2021-2023'] for c_ in ['maize', 'sorghum', 'millet', 'rice']]
rows += [[f'{c_.capitalize()}: water-limited yield potential Yw (t/ha)', round(M['Yw'][c_], 2), 'Yield Potential and Yield Gap Atlas (2026)'] for c_ in ['maize', 'sorghum', 'millet', 'rice']]
rows += [['Livestock emissions, ruminant (Mt CO2eq/yr)', round(M['E_rum'] / 1e3, 2), 'FAOSTAT GLE'], ['Livestock emissions, monogastric (Mt CO2eq/yr)', round(M['E_mono'] / 1e3, 2), 'FAOSTAT GLE'],
         ['Livestock emissions, draught (Mt CO2eq/yr)', round(M['E_dr'] / 1e3, 2), 'FAOSTAT GLE'], ['Emission intensity per kcal, ruminant / monogastric', round(M['int_rum_per_kcal'] / M['int_mono_per_kcal'], 1), 'FAOSTAT GLE and FBS'],
         ['Land-use-change emissions per ha of cropland expansion (t CO2eq)', round(M['luc_t_per_ha'], 1), 'FAOSTAT GT and RL'], ['Grain N removal (kg N/t)', '15 (12-18)', 'Assumption, tested'],
         ['Recovery of additional fertiliser N', '50% (30-70%)', 'Assumption, tested'], ['Grain P removal, replaced (kg P/t)', 3, 'Assumption'], ['Mineral N on food crops, 2021-2023 (kt N)', round(M['Nmin0'], 1), 'FAOSTAT ESB minus cotton']]
vs('Scenario_inputs', ['Food group (kcal/cap/d, reached in 2050)'] + list(DN.values()), rows, [52] + [24] * len(DN))
rows = []
for k, v in GR.items():
    dk, tk, yk = k.split('|')
    for t in ['2050', '2100']:
        a, g = v[t]['ASR'], v[t]['diag']
        rows.append([DN[dk], TRN[tk], YN[yk], int(t), round(g['cropland_change_Mha'], 2), round(100 * g['agland_share_of_land'], 1), round(g['Nmin_kt'], 1),
                     a['climate'], a['climate_nonLUC'], a['agland'], a['N_surplus'], a['N2O'], a['pesticides'], a['P_application']])
vs('Scenarios', ['Diet', 'Trade', 'Cereal yield', 'Year', 'Cropland change since 2021-2023 (Mha)', 'Agricultural land (% of land area)', 'Mineral N on food crops (kt)',
                 'ASR climate', 'ASR climate without LUC', 'ASR agricultural land', 'ASR N surplus', 'ASR N2O', 'ASR pesticides', 'ASR mineral P'], rows, [28, 22, 16, 7, 18, 18, 18] + [12] * 7)
CASES = {'central': 'Central', 'NUE_0.7': 'Fertiliser N recovery 70%', 'NUE_0.3': 'Fertiliser N recovery 30%', 'Ngrain_12': 'Grain N 12 kg/t', 'Ngrain_18': 'Grain N 18 kg/t',
         'livestock_intensity_-30%': 'Ruminant emission intensity -30%', 'noncereal_yield_gain': 'Other crops gain as much as cereals'}
rows = [[DN[dk], cl] + [SC['sens'][f'{dk}|self|Yw80|{ck}'][x] for x in ['climate', 'agland', 'N_surplus', 'N2O', 'pesticides', 'P_application', 'cropland_change_Mha']]
        for dk in ['current', 'adequate', 'PHD', 'PHDmono'] for ck, cl in CASES.items()]
vs('Scenario_sensitivity', ['Diet (full self-sufficiency, 80% of Yw, 2050)', 'Case', 'ASR climate', 'ASR agricultural land', 'ASR N surplus', 'ASR N2O', 'ASR pesticides', 'ASR mineral P', 'Cropland change (Mha)'],
   rows, [40, 34] + [14] * 7)
wb.save('Workbook.xlsx'); print('saved')
