import json, numpy as np
from data import *
R = json.load(open('results.json')); NL = json.load(open('N_local.json'))
D = ['climate', 'agland', 'bluewater', 'N_surplus', 'P_application', 'N2O', 'pesticides']
NM = {'climate': 'Climate change (GHG)', 'agland': 'Agricultural land', 'bluewater': 'Blue water', 'N_inputs': 'N inputs, EAT–Lancet translation', 'N_surplus': 'Agricultural N surplus',
      'P_application': 'Mineral P fertilizer', 'N2O': 'Stratospheric ozone (N₂O)', 'pesticides': 'Pesticides', 'cropland': 'Cropland (Willett)', 'N_application': 'N application (Willett)'}
U = {'climate': 'Mt CO₂eq yr⁻¹', 'agland': 'Mha', 'bluewater': 'km³ yr⁻¹', 'N_inputs': 'kt N yr⁻¹', 'N_surplus': 'kt N yr⁻¹', 'P_application': 'kt P yr⁻¹',
     'N2O': 'kt N₂O-N yr⁻¹', 'pesticides': 'kt yr⁻¹', 'cropland': 'Mha', 'N_application': 'kt N yr⁻¹'}
def f(x, n=3):
    if x is None or (isinstance(x, float) and np.isnan(x)): return '–'
    return f'{x:.{n}g}' if abs(x) < 1000 else f'{x:,.0f}'
L = []; A = L.append
A('---\ntitle: "Supplementary Material for: Can a fast-growing, food-insecure country feed itself within its fair share of the food-system boundaries? A dynamic assessment to 2100"\n---\n')
A('This Supplementary Material documents the data, derivations, and additional results that support the main text. Tables, figures, and sections prefixed with S refer to this document; equation numbers without a prefix refer to the main text. All values are computed by the Python scripts provided with the article and are reproduced in the Supplementary Workbook. Official data were retrieved from the FAOSTAT and World Bank APIs on 20 October 2026 [@FAO2026; @WorldBank2026].\n')

A('# S1. Study area, scope, and indicator derivations\n')
A('Burkina Faso is a landlocked Sahelian country of 274,200 km² (Fig. S1).\n')
A('![Fig. S1. Location of Burkina Faso in Africa; the star marks the capital, Ouagadougou.](fig/FigS1_map.png)\n')
A('Table S1. Population used in the calculations.\n')
A('| Year | Burkina Faso | World | National share (%) | Source |\n|---|---|---|---|---|')
A(f"| 2021–2023 mean | {R['base']['popB0']/1e6:.2f} million | {R['base']['popW0']/1e9:.3f} billion | {R['base']['share0']*100:.3f} | World Bank [-@WorldBank2026] |")
for t in [2025, 2050, 2075, 2100]:
    A(f"| {t} | {UN_POP['BFA'][t]/1e6:.2f} million | {UN_POP['WLD'][t]/1e9:.3f} billion | {UN_POP['BFA'][t]/UN_POP['WLD'][t]*100:.3f} | United Nations [-@UN2024], medium variant |")
A('')
c = R['cotton']; ex = R['live_export_frac']
s = R['sens']
A('## S1.1. Food-system scope: cotton and livestock trade\n')
A(f"*Cotton exclusion.* Cotton is grown for lint, a textile fibre, and is excluded because the boundaries are defined for food. It occupies {c['area_Mha']:.2f} Mha ({c['f_area']*100:.1f}% of FAOSTAT cropland in 2021–2023), and we remove it from every indicator, using the rule in Table S2. Fertilizer is allocated with crop-level statistics for 2015–2017 [@Ludemann2022], in which cotton received {c['f_N']*100:.1f}% of mineral nitrogen and {c['f_P']*100:.1f}% of mineral P₂O₅. Pesticide use, which FAOSTAT does not report by crop, is allocated with a bottom-up estimate from the cotton input supply (Section S1.9).\n")
cot_P = c['f_P'] * R['P_parts']['mineral_all']
A('Table S2. Cotton pressures removed from each indicator, 2021–2023 mean.\n')
A('| Indicator | Removed for cotton | Rule | Food-system pressure |\n|---|---|---|---|')
A(f"| Climate change | {c['climate_Mt']:.2f} Mt CO₂eq yr⁻¹ | Nitrogen share of synthetic-fertilizer N₂O; area share of crop residues, burning, on-farm energy, and land-use change; pesticide share of pesticide manufacture | {R['pressure']['climate']:.1f} Mt CO₂eq yr⁻¹ |")
A(f"| Agricultural land | {c['area_Mha']:.2f} Mha | Harvested cotton area (FAOSTAT QCL) | {R['pressure']['agland']:.2f} Mha |")
A(f"| Blue water | 0 | Cotton is rain-fed | {R['pressure']['bluewater']:.2f} km³ yr⁻¹ |")
A(f"| Agricultural N surplus | {c['N_balance_kt']:.1f} kt N yr⁻¹ | Nitrogen share of mineral N + area share of manure applied, deposition, and seed − N removed in seed cotton ({N_REMOVAL_SEED_COTTON[1]*1e3:.0f} kg N t⁻¹; range {N_REMOVAL_SEED_COTTON[0]*1e3:.0f}–{N_REMOVAL_SEED_COTTON[2]*1e3:.0f}) | {R['pressure']['N_surplus']:.0f} kt N yr⁻¹ |")
A(f"| Mineral phosphorus | {cot_P:.2f} kt P yr⁻¹ | Phosphorus share of mineral P | {R['pressure']['P_application']:.2f} kt P yr⁻¹ |")
A(f"| N₂O | {R['N2O_parts']['cotton_kt']:.2f} kt N₂O-N yr⁻¹ | Nitrogen share of synthetic-fertilizer N₂O; area share of residue N₂O | {R['pressure']['N2O']:.2f} kt N₂O-N yr⁻¹ |")
A(f"| Pesticides | {c['pest_share_2022']*100:.0f}% of use (5th–95th percentile {c['pest_share_p05_p95'][0]*100:.0f}–{c['pest_share_p05_p95'][1]*100:.0f}%) | Bottom-up estimate from the cotton input tender (Table S4) | {R['pressure']['pesticides']:.2f} kt yr⁻¹ |\n")
A(f"Officially recorded exports of live animals in 2021–2023 (FAOSTAT TCL) amount to {ex['cattle']*100:.2f}% of cattle, {ex['sheep']*100:.2f}% of sheep, and {ex['goats']*100:.2f}% of goats that were exported or slaughtered. Adjusting livestock emissions for recorded exports changes the climate ratio from {R['ASR_base']['climate']['EPC']:.2f} to {R['sens']['livestock_export_adjusted_climate']:.2f}. Unrecorded cross-border trade towards coastal markets is known to be substantial [@Rich2021] but cannot be quantified from official statistics. Imported cereals (20.5% of cereal use) would add pressure under a consumption-based scope; valuing them at the domestic intensity raises the climate ratio to {R['sens']['climate_import_adjusted']:.2f} (an upper bound, because exporters have lower emission intensities).\n")
cp = R['climate_parts']
A('## S1.2. Climate change\n')
A(f"The pressure is the FAOSTAT *Agrifood systems* aggregate (element *Emissions (CO2eq) (AR5)*, FAO Tier 1). It has three stages: the farm gate (enteric fermentation, manure management, manure left on pasture and applied to soils, synthetic fertilizers, crop residues, rice cultivation, burning of crop residues, drained organic soils, and on-farm energy); land-use change (net forest conversion); and pre- and post-production (input manufacture, processing, packaging, transport, retail, household consumption, and agrifood waste disposal) [@Tubiello2021]. In 2021–2023, these stages contributed {cp['farmgate']:.1f}, {cp['luc']:.1f}, and {cp['prepost']:.1f} Mt CO₂eq yr⁻¹, respectively ({R['climate_incl_cotton']:.1f} Mt in total, {R['pressure']['climate']:.1f} Mt for food only). In 2022, the largest sources were net forest conversion (17.1 Mt), enteric fermentation (12.9 Mt), manure left on pasture (6.2 Mt), agrifood waste disposal (2.6 Mt), rice cultivation (1.4 Mt), and food retail (1.2 Mt, mostly refrigerant F-gases). The world total was {R['world_pressure']['climate']/1e3:.2f} Gt CO₂eq yr⁻¹, consistent with the 16–17.7 Gt reported for the food system [@teWierik2025; @Rockstrom2025]. FAOSTAT land-use-change emissions are constant within forest-assessment periods (19.7 Mt CO₂eq yr⁻¹ in 2001–2010, 17.5 Mt in 2011–2015, 17.3 Mt in 2016–2020, and 17.1 Mt from 2021), so they are not used for trend analysis.\n")
lc = R['land_conversion']
A('## S1.3. Land-system change\n')
A(f"The land boundary of te Wierik et al. [-@teWierik2025] requires halting the conversion of intact land; the 2025 EAT–Lancet Commission expresses it as agricultural land below 48 Mkm² and calls for the restoration of 8.5 Mkm² in forest ecoregions [@Rockstrom2025]. In FAOSTAT, forest land declined from {lc['forest_2000']/1e3:.2f} Mha in 2000 to {lc['forest_2023']/1e3:.2f} Mha in 2023 ({lc['forest_change_pct']:.0f}%, {lc['forest_loss_kha_yr']:.0f} kha yr⁻¹), while cropland increased from {lc['cropland_2000']/1e3:.2f} to {lc['cropland_2023']/1e3:.2f} Mha ({lc['cropland_gain_kha_yr']:.0f} kha yr⁻¹). The zero-conversion boundary is therefore transgressed under every sharing principle. Food-only agricultural land in 2021–2023 is {R['pressure']['agland']:.2f} Mha (cropland {R['pressure']['cropland']:.2f} Mha plus permanent meadows and pastures), against a world total of {R['world_pressure']['agland']/100:.1f} Mkm².\n")
wp = R['water_parts']
A('## S1.4. Land-cover mapping\n')
A("Agricultural land was mapped in ArcGIS Pro (v. 3.6.2). Historical maps for 1975, 2000, and 2013 come from the USGS West Africa land-use and land-cover time series [@USGS2016]. The 2025 map was derived from a Sentinel-2 Level-2A classification in Google Earth Engine [@Tahir2025]. Acquisition was restricted to the monsoon growing season (1 May–31 October 2025). Scenes with more than 10% cloud cover were excluded, residual cloud and cirrus were removed with the QA60 band, and cloud-free observations were composited by temporal median. Training samples from ESA WorldCover v100 were aggregated into three classes (cropland and managed pasture; forest and dense vegetation; barren, built-up, and sparsely vegetated land), with spatially balanced stratified sampling of 150 samples per class at a minimum spacing of 1 km. A Random Forest classifier (50 trees) was trained on Sentinel-2 bands and vegetation indices to produce a 30 m map (Fig. S2). The map gives 6.0 Mha of actively cultivated land in 2025, below the FAOSTAT cropland value, which includes temporary fallow; it defines the cropland lower bound in the sensitivity analysis. Fig. S3 summarizes land-cover change.\n")
A('![Fig. S2. Land use and land cover of Burkina Faso in 1975, 2000, 2013, and 2025 (left to right, top to bottom).](fig/FigS3_lulc.png)\n')
A('![Fig. S3. Land-cover change in Burkina Faso, 1975–2025: (a) area and share of each class; (b) trajectories, with cropland and pasture overtaking natural vegetation around 2020.](fig/FigS4_landcover.png)\n')
ni = R['N_inputs_parts']; npt = R['N_parts']; e = R['exploratory']; s = R['sens']
A('## S1.5. Nitrogen\n')
A(f"*Choice of indicator.* te Wierik et al. [-@teWierik2025] set the nitrogen food-system boundary on a single control variable, the agricultural nitrogen surplus (57 Tg N yr⁻¹; current value 119 Tg N yr⁻¹), derived by Schulte-Uebbing et al. [-@SchulteUebbing2022] from regional critical surpluses for ammonia deposition, surface water, and groundwater. The 2025 EAT–Lancet Commission also reports a limit of 134 Tg N yr⁻¹ on agricultural nitrogen inputs, but this is a translation of the same boundary at the current global nitrogen-use efficiency, not an independent constraint [@Rockstrom2025]. Reporting both would count one boundary twice and would make the input result depend on an efficiency that differs widely between farming systems. The surplus is therefore the only nitrogen control variable; the input translation is a sensitivity.\n")
A(f"*National agricultural nitrogen surplus.* The surplus has a cropland and a grassland component. The cropland component is the FAOSTAT Cropland Nutrient Balance, inputs (mineral fertilizer, manure applied to soils, biological fixation, atmospheric deposition, and seed) minus crop and residue removal: {npt['inputs']:.1f} − {npt['outputs']:.1f} = {npt['inputs']-npt['outputs']:.1f} kt N yr⁻¹ in 2021–2023 for all crops. Cotton's own balance, {c['N_balance_kt']:.1f} kt N yr⁻¹ (Table S2), is subtracted, leaving {npt['inputs']-npt['outputs']-c['N_balance_kt']:.1f} kt N yr⁻¹ for food crops. FAOSTAT does not report grass uptake, so the grassland surplus cannot be computed as a balance. In extensive grazing systems, the nitrogen excreted on pasture ({ni['pasture_dep']:.0f} kt N yr⁻¹) is largely recycled from grass eaten on the same land; at steady state, the surplus of this recycled flow equals the nitrogen lost from it. The grassland component is therefore estimated as the nitrogen volatilized ({e['pasture_vol_kt']:.0f} kt) and leached or run off ({e['pasture_leach_kt']:.0f} kt) from manure left on pasture (FAOSTAT Livestock Manure, IPCC Tier 1). This is a lower bound, because denitrification to N₂ and losses of nitrogen from deposition and fixation on rangeland are excluded. The national surplus is {e['N_agri_kt']:.0f} kt N yr⁻¹ ({R['percap']['N_surplus']['pressure']*1e6:.1f} kg N cap⁻¹, against an EPC share of {R['percap']['N_surplus']['EPC_boundary']*1e6:.1f} kg N cap⁻¹). The same construction gives {e['N_agri_W_Tg']:.1f} Tg N yr⁻¹ worldwide, against the 119 Tg N yr⁻¹ of te Wierik et al., so the boundary is expressed in FAOSTAT terms as 57 × {e['N_agri_W_Tg']:.1f}/119 = {R['global_boundary_natunits']['N_surplus']/1e3:.1f} Tg N yr⁻¹.\n")
Ncrop_in = npt['inputs']; Ncrop_out = npt['outputs']; Nmin = npt['mineral']; Nbnf = npt['bnf']
W_crop = R['world_pressure']['N_surplus']/1e3 - (np.mean(EMN['WLD_pasture_vol'][-3:]) + np.mean(EMN['WLD_pasture_leach'][-3:]))/1e9
W_vol = np.mean(EMN['WLD_pasture_vol'][-3:])/1e9; W_lea = np.mean(EMN['WLD_pasture_leach'][-3:])/1e9; W_dep = W_vol/0.2
A('Table S3. Terms of the agricultural nitrogen surplus (Eq. 1), 2021–2023 mean. Burkina Faso in kt N yr⁻¹; world in Tg N yr⁻¹. All terms are FAOSTAT estimates based on IPCC Tier 1 methods (modelled, not measured).\n')
A('| Term | Symbol | FAOSTAT domain, element | Burkina Faso | World | Basis |\n|---|---|---|---|---|---|')
A(f"| Cropland N inputs (total) | $I_{{crop}}$ | ESB, cropland nitrogen inputs | {Ncrop_in:.1f} | – | Modelled budget |")
A(f"| — of which mineral fertilizer | | ESB, synthetic fertilizers | {Nmin:.1f} | – | Reported use |")
A(f"| — of which biological fixation | | ESB, biological fixation | {Nbnf:.1f} | – | Modelled |")
A(f"| — manure applied, deposition, and seed (by difference) | | ESB | {Ncrop_in-Nmin-Nbnf:.1f} | – | Modelled |")
A(f"| Crop and residue removal | $U_{{crop}}$ | ESB, crop removal | {Ncrop_out:.1f} | – | Modelled |")
A(f"| Cropland balance, all crops | $I_{{crop}} - U_{{crop}}$ | ESB, cropland nitrogen balance | {Ncrop_in-Ncrop_out:.1f} | {W_crop:.1f} | Modelled |")
A(f"| — minus cotton's balance | | Table S2 | {-c['N_balance_kt']:.1f} | – | Estimated |")
A(f"| Cropland balance, food crops | | | {Ncrop_in-Ncrop_out-c['N_balance_kt']:.1f} | {W_crop:.1f} | |")
A(f"| Manure N left on pasture (for reference; not added) | | EMN, amount left on pasture | {ni['pasture_dep']:.1f} | {W_dep:.1f} | Tier 1 excretion (world derived as V/0.20) |")
A(f"| Volatilized as NH₃ and NO$_x$ (0.20 of deposited N) | $V_{{past}}$ | EMN, volatilization | {e['pasture_vol_kt']:.1f} | {W_vol:.1f} | Tier 1 fraction |")
A(f"| Leached and run off (0.30 of deposited N) | $L_{{past}}$ | EMN, leaching | {e['pasture_leach_kt']:.1f} | {W_lea:.1f} | Tier 1 fraction |")
A(f"| Agricultural surplus | $NS$ | Eq. 1 | {e['N_agri_kt']:.1f} | {e['N_agri_W_Tg']:.1f} | |")
A(f"| Boundary used for allocation | | 57 × world/119 | {R['SOS_base']['N_surplus']['EPC']:.1f} (EPC share) | {R['global_boundary_natunits']['N_surplus']/1e3:.1f} | |\n")
A("Volatilization and leaching are computed by FAOSTAT as separate fractions of the same deposited nitrogen and do not overlap; direct N₂O (about 0.02 of deposited N) and denitrification to N₂ are not included. Table S3a shows the effect of alternative loss assumptions; for those that are physical properties of the IPCC method, the world value and hence the boundary are recomputed consistently.\n")
crop_=Ncrop_in-Ncrop_out-c['N_balance_kt']; vol_=e['pasture_vol_kt']; lea_=e['pasture_leach_kt']; dep_=ni['pasture_dep']; s0_=R['base']['share0']
def asr_(p, w): return p / (s0_ * 57e3 * w / 119)
alt = [('Central (IPCC 2006 Tier 1 fractions, as in FAOSTAT)', crop_+vol_+lea_, W_crop+W_vol+W_lea),
       ('Leaching fraction 0.24 (IPCC 2019 default), national and world', crop_+vol_+0.8*lea_, W_crop+W_vol+0.8*W_lea),
       ('Volatilization fraction 0.21 (IPCC 2019 default), national and world', crop_+1.05*vol_+lea_, W_crop+1.05*W_vol+W_lea),
       ('No national pasture leaching (IPCC 2019 dry-climate rule)', crop_+vol_, W_crop+W_vol+W_lea),
       ('Add direct N₂O-N from pasture manure (0.02 of deposited N)', crop_+vol_+lea_+0.02*dep_, W_crop+W_vol+W_lea+0.02*W_dep),
       ('Cropland component only', crop_, W_crop)]
A('Table S3a. EPC ratio of the agricultural nitrogen surplus under alternative loss assumptions.\n')
A('| Assumption | National surplus (kt N yr⁻¹) | World surplus (Tg N yr⁻¹) | Boundary used (Tg N yr⁻¹) | EPC ratio |\n|---|---|---|---|---|')
for n_, p_, w_ in alt: A(f"| {n_} | {p_:.1f} | {w_:.1f} | {57*w_/119:.1f} | {asr_(p_, w_):.2f} |")
A('')
A(f"*Uncertainty and sensitivities.* The IPCC (2019) refinement sets the leaching fraction to zero in dry climates [@IPCC2019], and most of Burkina Faso is semi-arid. In the Monte Carlo analysis, pasture leaching is therefore sampled from a triangular distribution between zero and the FAOSTAT value; cropland inputs, removals, and volatilization are lognormal (CV 0.15, 0.10, and 0.30). Without pasture leaching, the EPC ratio is {s['N_surplus_no_pasture_leaching']:.2f}; with the cropland component alone, {s['N_surplus_cropland_only']:.2f}; with the strict 43 Tg N yr⁻¹ boundary, {s['N_surplus_strict43']:.2f}. The input translation (134 Tg N yr⁻¹, {R['pressure']['N_inputs']:.0f} kt N yr⁻¹ nationally, including manure deposited on pasture) gives {s['N_inputs_EAT134']:.2f}.\n")
A(f"*Local test.* te Wierik et al. [-@teWierik2025] published, with their supporting data, a raster of the local exceedance of the critical nitrogen surplus on arable land and intensively managed grassland. The raster is based on all thresholds (deposition, surface water, and groundwater) for 2010 at 0.5° resolution and derives from Schulte-Uebbing et al. [-@SchulteUebbing2022]. Of the {NL['n_cells']} grid cells whose centres lie within Burkina Faso, {NL['n_data']} contain agricultural data. In {round(NL['share_exceeded']*NL['n_data'])} of them ({NL['share_exceeded']*100:.0f}%), the surplus exceeded the local critical surplus. The median exceedance is {NL['median']:.1f} kg N ha⁻¹ yr⁻¹ (5th–95th percentile {NL['p05']:.0f} to +{NL['p95']:.0f}; maximum +{NL['max']:.0f}), against {NL['global_share_exceeded']*100:.0f}% of agricultural cells worldwide (Fig. S4). The percentile range describes the spread of exceedance across the {NL['n_data']} cells, not statistical uncertainty in any one cell. The raster is a model estimate for 2010 and is used as supporting spatial evidence, not as a contemporary national observation. The national boundary polygon is a generalized outline at 1:110 m scale, so cells on the border are approximate.\n")
A('![Fig. S4. Local exceedance of the critical nitrogen surplus on arable land and intensively managed grassland in Burkina Faso (all thresholds, 2010; 0.5° grid), from the supporting data of te Wierik et al. (2025), derived from Schulte-Uebbing et al. (2022). (a) Exceedance by grid cell: red cells lie above and blue cells below the local critical surplus; grey cells have no agricultural data. Dots mark the 41 cells with agricultural data whose centres fall within the national outline used in the analysis; cells outside Burkina Faso are shown faded for context. Country borders: Natural Earth (1:10 m). (b) Exceedance in each of the 41 cells, ranked, with the median (dashed line).](fig/FigS4_N_local.png)\n')
pl = R['exploratory']
A('## S1.6. Phosphorus\n')
A(f"*Mineral phosphorus.* Mineral phosphorus applied to cropland (FAOSTAT Cropland Nutrient Balance) averaged {R['P_parts']['mineral_all']:.2f} kt P yr⁻¹ in 2021–2023, or {R['pressure']['P_application']:.2f} kt for food crops. The boundary of 8 (6–16) Tg P yr⁻¹ [@Willett2019] is retained by the 2025 Commission as the mineral-fertilizer range that limits phosphorus reaching surface waters [@Rockstrom2025]. The world value is {R['world_pressure']['P_application']/1e3:.1f} Tg P yr⁻¹. The cropland phosphorus balance is negative ({pl['P_balance_kt']:.1f} kt P yr⁻¹ in 2021–2023) and has been negative in every year since 2001 (Fig. S5).\n")
A(f"*Exploratory delivery indicator.* The control variable of te Wierik et al. [-@teWierik2025] is phosphorus delivery to surface water (boundary 4.6 Tg P yr⁻¹; current food-system delivery 7.2 Tg P yr⁻¹, of which agriculture contributes 5.36, aquaculture 0.196, and wastewater 1.6). Its national counterpart is estimated with a global delivery coefficient, {pl['kP']:.3f} (agricultural delivery divided by global cropland phosphorus inputs), applied to food-crop phosphorus inputs, which gives {pl['P_delivery_agri_kt']:.2f} kt P yr⁻¹. Wastewater adds {pl['P_ww_kt']:.2f} kt P yr⁻¹: global per-capita wastewater delivery scaled by the ratio of national to world urban population shares. The total is {pl['P_delivery_kt']:.2f} kt P yr⁻¹, and the EPC ratio is {s['P_delivery_tW']:.2f}. A local critical load can be derived by applying the critical concentration of 0.075 mg P L⁻¹ to national internal renewable water resources (12.5 km³ yr⁻¹), correcting for 53% river retention, and taking the food-system share (74%). This gives {pl['P_local_boundary_kt']:.2f} kt P yr⁻¹, which estimated delivery exceeds {s['P_delivery_local_critical']:.1f}-fold. Retention in Sahelian reservoirs and endorheic basins is likely higher than the global mean, which would relax the local limit: at 75% retention the exceedance falls to {pl['P_delivery_kt']/(pl['P_local_boundary_kt']*(1-0.53)/(1-0.75)):.1f}-fold, and it disappears above {1-(1-0.53)*pl['P_local_boundary_kt']/pl['P_delivery_kt']:.0%} retention. The delivery coefficients are global means and carry unquantified uncertainty, so this indicator is exploratory and answers a local water-quality question, not the fair-share question tested by mineral phosphorus.\n")
A('## S1.7. Stratospheric ozone (N₂O)\n')
A(f"Agrifood N₂O emissions (FAOSTAT, CO₂eq from N₂O, AR5) were converted to N₂O-N with a GWP of 265 and a factor of 28/44. Cotton's share of synthetic-fertilizer and crop-residue N₂O ({R['N2O_parts']['cotton_kt']:.2f} kt N₂O-N yr⁻¹) was removed, giving {R['pressure']['N2O']:.2f} kt N₂O-N yr⁻¹. Manure left on pasture produced 78% of agrifood N₂O in 2022. The 2025 Commission sets the food-system boundary at 1.8 Tg N₂O-N yr⁻¹, against current direct agricultural emissions of 3.9–4.2 Tg N₂O-N yr⁻¹ [@Rockstrom2025]. The FAOSTAT world value ({R['world_pressure']['N2O']/1e3:.2f} Tg N₂O-N yr⁻¹) is broader in scope, so the boundary is scaled by the same proportional reduction, to {R['global_boundary_natunits']['N2O']/1e3:.2f} Tg N₂O-N yr⁻¹. The N₂O and climate indicators overlap, and they should not be counted as independent transgressions [@Wolfram2026].\n")
A('## S1.8. Freshwater change\n')
A(f"Blue-water pressure is agricultural water withdrawal ({WDI['BFA_water_withdrawal_km3']} km³ yr⁻¹ total withdrawal × {WDI['BFA_ag_share_withdrawal_pct']:.1f}% agricultural share = {wp['ag_withdrawal_B']:.3f} km³ yr⁻¹) [@AQUASTAT2026; @WorldBank2026] multiplied by a consumptive fraction of {wp['cons_frac']:.2f}. This fraction is the ratio of global irrigation consumptive use (1,200 km³ yr⁻¹; @teWierik2025) to global agricultural withdrawal ({wp['ag_withdrawal_W']:,.0f} km³ yr⁻¹). AQUASTAT reports a single reference value for Burkina Faso, so no trend is computed. The green-water control variable is the share of agricultural land whose monthly root-zone soil moisture lies outside the local pre-industrial 5th–95th percentile envelope [@WangErlandsson2022]. It can be estimated only from gridded hydrological model ensembles, not from national statistics, and it is therefore not assessed.\n")
A('## S1.9. Novel entities (pesticides)\n')
A(f"FAOSTAT reports agricultural use of pesticide active ingredients in Burkina Faso rising from {RP_2000['BFA']/1e3:.2f} kt in 2000 to {RP['BFA'][-1]/1e3:.2f} kt in 2023, against world use of {np.mean(RP['WLD'][-3:])/1e6:.2f} Tg yr⁻¹ in 2021–2023 [@FAO2026; @FAO2022]. In 2022, herbicides made up {RP_CAT['herbicides'][2022]/(RP_CAT['herbicides'][2022]+RP_CAT['insecticides'][2022])*100:.0f}% of national use and insecticides the rest; fungicides are reported as zero. The 2025 Commission sets the food-system boundary at 1 Tg yr⁻¹ to avoid high pollution risk and at 0.2 Tg yr⁻¹ to remain below low risk [@Rockstrom2025; @Tang2021].\n")
A(f"FAOSTAT does not report use by crop, so we estimate cotton's use from the supply side. Almost all inputs for cotton are bought centrally by the cotton companies and distributed on credit. The call for tenders of SOFITEX, the largest company, for the 2022/23 campaign specifies the insecticide treatments, herbicides, and growth regulators ordered for its {SOFITEX['cotton_area_ha']/1e3:.0f} thousand hectares [@SOFITEX2021]. We convert each lot to active ingredient with the label doses of the admissible formulations, then scale by the ratio of the national cotton area in 2022 ({COTTON_AREA[2022]/1e3:.0f} thousand hectares) to the SOFITEX area. Growth regulators are excluded because FAOSTAT does not count them.\n")
A('Table S4. Bottom-up estimate of pesticide use on cotton, 2022/23 campaign.\n')
A('| Input class (SOFITEX lots) | Quantity ordered | Active ingredient per dose, kg (low, mode, high) | Active ingredient, t (mode) |\n|---|---|---|---|')
labels = {'T1': 'Insecticides, first window (diamides, indoxacarb, emamectin, growth inhibitors)', 'T2': 'Insecticides, second window (pyrethroid–organophosphate mixtures and others)', 'T3': 'Insecticides, third window (aphicides: pyrethroid or spinetoram + acetamiprid, and others)'}
tot = 0
for k in ['T1', 'T2', 'T3']:
    q = SOFITEX['insect_doses'][k]; a = AI_PER_DOSE[k]; tot += q * a[1] / 1e3
    A(f"| {labels[k]} | {q:,} ha-doses | {a[0]}, {a[1]}, {a[2]} | {q*a[1]/1e3:,.0f} |")
for lab, q, key, unit in [('Pre-emergence granular herbicides (diuron; fluometuron + prometryn)', SOFITEX['herb_pre_gran_ha'], 'herb_pre_gran', 'ha'), ('Pre-emergence liquid herbicides', SOFITEX['herb_pre_liq_ha'], 'herb_pre_liq', 'ha'), ('Post-emergence herbicides (graminicides)', SOFITEX['herb_post_L'], 'herb_post_per_L', 'L')]:
    a = AI_PER_DOSE[key]; tot += q * a[1] / 1e3
    A(f"| {lab} | {q:,} {unit} | {a[0]}, {a[1]}, {a[2]} | {q*a[1]/1e3:,.0f} |")
A(f"| SOFITEX total | | | {tot:,.0f} |")
A(f"| National cotton (× {COTTON_AREA[2022]/SOFITEX['cotton_area_ha']:.2f}) | | | {c['pest_kt']*1e3:,.0f} |")
A(f"| National use, all crops, 2022 (FAOSTAT) | | | {RP['BFA'][YEARS.index(2022)]:,.0f} |")
A(f"| Cotton share | | | {c['pest_share_2022']*100:.0f}% |\n")
A(f"Cotton thus accounts for about {c['insect_share_nat']*100:.0f}% of national insecticide use and {(c['pest_kt']-c['pest_insect_kt'])/(RP_CAT['herbicides'][2022]/1e3)*100:.0f}% of herbicide use; the remaining herbicide is applied mainly to cereals. The older estimate that cotton takes more than 90% of national pesticides [@Ouedraogo2011] predates the spread of herbicides on cereals. In the Monte Carlo analysis, the active ingredient per dose is sampled from the triangular ranges above and the tender quantities by ±15%, which gives a cotton share of {c['pest_share_p05_p95'][0]*100:.0f}–{c['pest_share_p05_p95'][1]*100:.0f}% (5th–95th percentile). Label doses may overstate the active ingredient actually applied, which would lower cotton's share. Including cotton entirely gives a ratio of {s['pesticides_incl_cotton']:.2f}; food-system use would exceed its share if cotton's share were below {s['pesticides_breakeven_cotton_share']*100:.0f}%.\n")

A('# S2. Official input series\n')
Y = YEARS
A('Table S5. National pressure series, Burkina Faso, 2010 and 2013–2023 (FAOSTAT; including cotton).\n')
A('| Series | ' + ' | '.join(str(y) for y in Y) + ' |'); A('|---' * (len(Y) + 1) + '|')
rows = [('Agrifood GHG (Mt CO₂eq)', np.array(GT['BFA_agrifood']) / 1e3, 1), ('— farm gate', np.array(GT['BFA_farmgate']) / 1e3, 1),
        ('— land-use change', np.array(GT['BFA_luc']) / 1e3, 1), ('— pre/post-production', np.array(GT['BFA_prepost']) / 1e3, 1),
        ('Agrifood N₂O (Mt CO₂eq)', np.array(GT['BFA_agrifood_N2O']) / 1e3, 2),
        ('Agricultural land (Mha)', np.array(RL['BFA_agri']) / 1e3, 2), ('Cropland (Mha)', np.array(RL['BFA_cropland']) / 1e3, 2), ('Forest land (Mha)', np.array(RL['BFA_forest']) / 1e3, 2),
        ('Agricultural N surplus (kt N)', np.array(ESB['BFA_N_surplus']) / 1e3 + (np.array(EMN['BFA_pasture_vol']) + np.array(EMN['BFA_pasture_leach'])) / 1e6, 0), ('Manure N on pasture (kt N)', np.array(EMN['BFA_pasture_dep']) / 1e6, 0),
        ('Cropland N balance (kt N)', np.array(ESB['BFA_N_surplus']) / 1e3, 1), ('Mineral N (kt N)', np.array(ESB['BFA_N_mineral']) / 1e3, 1),
        ('Cropland P balance (kt P)', np.array(ESB['BFA_P_surplus']) / 1e3, 1), ('Pesticide use (kt)', np.array(RP['BFA']) / 1e3, 2)]
for name, v, n in rows: A(f'| {name} | ' + ' | '.join(f'{x:.{n}f}' for x in v) + ' |')
A('\nThe drop in 2020 in livestock emissions and manure nitrogen reflects a FAOSTAT revision of livestock numbers, not a change in herd size; the 2021–2023 base period avoids it.\n')
A('![Fig. S5. National pressure series, 2010 and 2013–2023 (FAOSTAT).](fig/FigS2_pressure_series.png)\n')
A('Table S6. Food-security and diet indicators (FAOSTAT Food Balances and Suite of Food Security Indicators).\n')
A('| Indicator | Burkina Faso | World |\n|---|---|---|')
A(f"| Dietary energy supply, 2021–2023 (kcal cap⁻¹ d⁻¹) | {R['base']['DES0']:.0f} | {np.mean([FBS_DES['WLD'][y] for y in [2021,2022,2023]]):.0f} |")
A(f"| of which animal products (kcal cap⁻¹ d⁻¹) | {np.mean(list(FBS_ANIMAL_KCAL['BFA'].values())):.0f} | {np.mean(list(FBS_ANIMAL_KCAL['WLD'].values())):.0f} |")
A(f"| Protein supply, 2021–2023 (g cap⁻¹ d⁻¹) | {np.mean(list(FBS_PROTEIN['BFA'].values())):.1f} | {np.mean(list(FBS_PROTEIN['WLD'].values())):.1f} |")
A(f"| Prevalence of undernourishment, 2022–2024 (%) | {FS['BFA']['PoU_pct_2022_2024']} | {FS['WLD']['PoU_pct_2022_2024']} |")
A(f"| Moderate or severe food insecurity (FIES), 2022–2024 (%) | {FS['BFA']['FIES_modsev_pct_2022_2024']} | {FS['WLD']['FIES_modsev_pct_2022_2024']} |")
A(f"| Dietary energy supply adequacy, 2022–2024 (%) | {FS['BFA']['DES_adequacy_pct_2022_2024']} | {FS['WLD']['DES_adequacy_pct_2022_2024']} |")
A(f"| Cereal import dependency ratio, 2021–2023 (%) | {FS['BFA']['cereal_import_dep_pct_2021_2023']} | – |\n")

A('# S3. Safe operating space by sharing principle\n')
A('Table S7. Pressure, national safe operating space (SOS), and world ratio by indicator, 2021–2023 (food only). The ASRs are given in Table 4 of the main text.\n')
A('| Indicator (unit) | Pressure | SOS EPC | SOS AP | SOS GF | SOS RE | World ratio |\n|---|---|---|---|---|---|---|')
for d in D + ['cropland', 'N_inputs']:
    so = R['SOS_base'][d]
    A(f"| {NM[d]} ({U[d]}) | {f(R['pressure'][d])} | {f(so['EPC'])} | {f(so['AP'])} | {f(so['GF'])} | {f(so['RE'])} | {R['global_ratio'][d]:.2f} |")
A(f"\nEPC uses the 2021–2023 mean population share ({R['base']['share0']*100:.3f}%; WDI SP.POP.TOTL) and, for projections, the UN WPP 2024 medium variant. AP multiplies the population share by the ratio of world to national GDP per capita in current USD for 2024 ({WDI['WLD_gdppc_2024']:,.0f} / {WDI['BFA_gdppc_2024']:,.0f} = {R['inc_ratio']:.2f}; WDI NY.GDP.PCAP.CD). RE multiplies it by the ratio of world to national cumulative fossil CO₂ (fossil fuels and cement, 1750–2022) per 2022 inhabitant: {GCB_CUM_2022['WLD']/POP_2022_OWID['WLD']:.1f} t and {GCB_CUM_2022['BFA']/POP_2022_OWID['BFA']:.2f} t, a ratio of {R['RE_mult']:.1f} (Global Carbon Budget national data [@Friedlingstein2023], compiled by Our World in Data [@OWID2026]). Land-use-change CO₂ is excluded because national series before 1950 are not consistent. GF uses the ratio of national to world pressure for 2021–2023, built in the same way. Worked example (EPC, nitrogen): {R['base']['share0']:.6f} × {R['global_boundary_natunits']['N_surplus']/1e3:.1f} Tg N = {R['SOS_base']['N_surplus']['EPC']:.0f} kt N; ASR = {R['pressure']['N_surplus']:.0f}/{R['SOS_base']['N_surplus']['EPC']:.0f} = {R['ASR_base']['N_surplus']['EPC']:.2f}. Worked example (RE, climate): {R['base']['share0']:.6f} × {R['RE_mult']:.2f} × 5,000 Mt = {R['SOS_base']['climate']['RE']:.0f} Mt CO₂eq; ASR = {R['pressure']['climate']:.1f}/{R['SOS_base']['climate']['RE']:.0f} = {R['ASR_base']['climate']['RE']:.3f}. The last two rows are sensitivity indicators: the cropland boundary of Willett et al. [-@Willett2019] (13 Mkm²) and the nitrogen-input translation of the 2025 Commission (134 Tg N yr⁻¹, expressed in FAOSTAT terms as {R['global_boundary_natunits']['N_inputs']/1e3:.1f} Tg N yr⁻¹).\n")

A('# S4. Food-demand dynamics and decoupling\n')
A('Table S8. EPC ratio with constant intensity: constant diet, adequate diet, and allocation frozen at the 2021–2023 share.\n')
A('| Indicator | Scenario | 2025 | 2050 | 2075 | 2100 |\n|---|---|---|---|---|---|')
for d in D:
    for lab, key, sc in [('Constant diet', 'EPC', 'const'), ('Adequate diet (3,000 kcal by 2050)', 'EPC', 'adequate'), ('Frozen allocation', 'fixed_alloc', 'const')]:
        tr = R['traj'][sc][d]; A(f"| {NM[d]} | {lab} | " + ' | '.join(f"{tr[str(t)][key]:.2f}" for t in [2025, 2050, 2075, 2100]) + ' |')
A('\nUnder EPC, the ratio with constant intensity changes only with world population and per-capita food supply (Eq. 3). The frozen-allocation case holds the national boundary at its 2021–2023 value while pressure grows with the national population.\n')
A('Table S9. Observed trends in pressure per kcal supplied and in absolute pressure (% yr⁻¹; standard error in parentheses), and required change in intensity.\n')
A('| Indicator | Window | Intensity | Absolute | Required to 2035, constant diet | Required to 2050, constant / adequate diet |\n|---|---|---|---|---|---|')
TR = R['trend']; RQ = R['required']; RN = R['required_nonLUC']
spec = [('Climate (farm gate + supply chain)', 'climate_nonLUC', RN), ('Agricultural land', 'agland', {s_: RQ[s_]['agland'] for s_ in RQ}),
        ('Cropland', 'cropland', None), ('Agricultural N surplus', 'N_surplus', {s_: RQ[s_]['N_surplus'] for s_ in RQ}), ('N₂O', 'N2O', {s_: RQ[s_]['N2O'] for s_ in RQ}), ('Pesticides', 'pesticides', {s_: RQ[s_]['pesticides'] for s_ in RQ})]
for lab, k, rq in spec:
    for w, v in TR[k].items():
        req = '–' if rq is None else f"{rq['const']['2035']['required_intensity_rate_pct']:.2f}"
        req2 = '–' if rq is None else f"{rq['const']['2050']['required_intensity_rate_pct']:.2f} / {rq['adequate']['2050']['required_intensity_rate_pct']:.2f}"
        A(f"| {lab} | {w.replace('_', '–')} | {v['intensity']['rate_pct']:.2f} ({v['intensity']['se_pct']:.2f}) | {v['absolute']['rate_pct']:.2f} | {req} | {req2} |")
A(f"\nTotal food supply (population × DES) grew by {TR['kcal']['2000_2023']['rate_pct']:.2f}% yr⁻¹ over 2000–2023 and {TR['kcal']['2010_2023']['rate_pct']:.2f}% yr⁻¹ over 2010–2023. DES for 2000–2009 is taken from the FAOSTAT food balances compiled with the earlier methodology; values missing in the current series (2011–2014, 2016–2017) are interpolated. The required rates for climate assume zero land-use-change emissions, as the 5 Gt boundary presupposes. Trends are ordinary least-squares slopes of the logarithm on year.\n")

cs = R['climate_summary']; cpth = R['climate_paths']; yy = cpth['year']
A('# S5. Climate pledge and IPCC AR6 pathways\n')
A(f"The food-only BAU trajectory starts at the 2022 value ({cs['base22']:.1f} Mt CO₂eq) and grows at the NDC BAU rate of 2.05% yr⁻¹ [@BurkinaFaso2025]. NDC reductions below BAU are interpolated linearly between 2022 (0%), 2030, 2035, and 2050. The IPCC AR6 C1 and C3 median and 5th–95th percentile reductions relative to 2019 [@IPCC2022] are applied to the 2019 food-only value ({cs['b19']:.1f} Mt CO₂eq) and interpolated linearly between 2019, 2030, 2040, and 2050. The EPC boundary follows the national population share.\n")
A('Table S10. Food-only agrifood emissions (Mt CO₂eq yr⁻¹) and ratio to the EPC boundary (in parentheses).\n')
A('| Year | EPC boundary | BAU | NDC 3.0 (full) | IPCC C3 median [5th–95th] | IPCC C1 median [5th–95th] |\n|---|---|---|---|---|---|')
for t in [2022, 2025, 2030, 2035, 2040, 2045, 2050]:
    i = yy.index(t); b = cpth['boundary_EPC'][i]
    A(f"| {t} | {b:.1f} | {cpth['BAU'][i]:.1f} ({cpth['BAU'][i]/b:.2f}) | {cpth['NDC'][i]:.1f} ({cpth['NDC'][i]/b:.2f}) | {cpth['C3'][i]:.1f} ({cpth['C3'][i]/b:.2f}) [{cpth['C3_hi'][i]:.1f}–{cpth['C3_lo'][i]:.1f}] | {cpth['C1'][i]:.1f} ({cpth['C1'][i]/b:.2f}) [{cpth['C1_hi'][i]:.1f}–{cpth['C1_lo'][i]:.1f}] |")
fy = cs['first_year_within']
A(f"\nUnconditional NDC in 2030: {cs['NDC_uncond_2030_ratio']:.2f} × boundary. First year within the boundary: full NDC {fy['NDC']}; C1 median {fy['C1']}; C3 median {fy['C3']}; most ambitious C1 {fy['C1_hi']}; most ambitious C3 {fy['C3_hi']}. Cumulative emissions above the boundary in 2022–2050: BAU {cs['cum_excess_BAU']:,.0f} Mt; NDC {cs['cum_excess_NDC']:,.0f} Mt; C1 median {cs['cum_excess_C1']:,.0f} Mt.\n")
A(f"*Transfer sensitivity.* The NDC sets no separate target for agrifood emissions, so the economy-wide percentages are transferred proportionally. If agrifood emissions are cut by half these percentages, the ratio is {cs['NDC_x0.5_2030_ratio']:.2f} in 2030 and {cs['NDC_x0.5_2050_ratio']:.2f} in 2050, and the share is not reached by 2050. If they are cut by 1.5 times these percentages (capped at 100%), the ratio is {cs['NDC_x1.5_2030_ratio']:.2f} in 2030 and the share is reached in {cs['NDC_x1.5_first_within']}. The benchmark therefore illustrates the consequence of proportional implementation; it does not assess the sectoral feasibility of the pledge.\n")

SRCF = {'climate': 'Residual 2050 agricultural emissions of the integrated assessment models behind the boundary [@teWierik2025]',
        'agland': 'Lower bound subtracts 8.5 Mkm² of forest-ecoregion restoration [@Rockstrom2025]',
        'bluewater': 'Planetary freshwater boundary scaled to agriculture [@Gerten2013]',
        'N_surplus': 'Lower bound without redistribution of the allowable surplus between regions [@SchulteUebbing2022]',
        'P_application': 'Fertilizer range of the 2019 and 2025 Commissions [@Willett2019; @Rockstrom2025]',
        'N2O': 'Range of current direct agricultural emissions, 3.9–4.2 Tg N₂O-N yr⁻¹ [@Rockstrom2025]',
        'pesticides': 'Lower bound of 0.2 Tg yr⁻¹ for low pollution risk [@Rockstrom2025; @Tang2021]'}
A('# S6. Monte Carlo analysis by sharing principle\n')
A('Four uncertainty classes are distinguished: (i) national data and (ii) global boundary values, both sampled here; (iii) structural choices, explored as alternative specifications (Section S7); and (iv) the sharing principle, kept as separate scenarios and never sampled. The intervals below therefore cover (i) and (ii) only.\n')
A('Table S11. Sampling distributions and their rationale. All inputs are sampled independently, because no published covariances exist.\n')
A('| Quantity | Class | Distribution | Rationale and source |\n|---|---|---|---|')
for d in D:
    tr_ = FSB[d]['tri'] if 'tri' in FSB[d] else R['N2O_parts']['tri']
    A(f"| Global FSB, {NM[d][0].lower() + NM[d][1:]} | (ii) | Triangular {tuple(round(x, 3) for x in tr_)} | {SRCF[d]} |")
A('| Farm-gate and pre/post-production emissions | (i) | Lognormal, CV 0.30 | IPCC Tier 1 uncertainty for enteric and manure emissions, ±20–50% [@IPCC2019] |')
A('| Land-use-change emissions | (i) | Lognormal, CV 0.50 | Forest-area change interpolated within assessment periods; expert judgement |')
A('| Cotton share of emissions | (i) | × triangular (0.5, 1.0, 1.5) | Fertilizer shares date from 2015–2017; expert judgement |')
A('| Agricultural land | (i) | Triangular (−15%, FAOSTAT, +5%) | Difference between FAOSTAT cropland and the Sentinel-2 cultivated area (Section S1.4) |')
A(f"| Agricultural withdrawal; consumptive fraction | (i) | Lognormal CV 0.25; triangular (0.30, {wp['cons_frac']:.2f}, 1.0) | Single AQUASTAT reference value; consumptive fractions of irrigation systems |")
A('| Cropland N inputs; removals | (i) | Lognormal CV 0.15; 0.10 | Uncertainty of FAOSTAT nutrient budgets; removals are better constrained by yield statistics |')
A('| Pasture volatilization | (i) | Lognormal CV 0.30 | IPCC Tier 1 range for the volatilization fraction [@IPCC2019] |')
A('| Pasture leaching | (i) | Value × triangular (0, 1, 1) | IPCC 2019 sets leaching to zero in dry climates; most of the country is semi-arid [@IPCC2019] |')
A('| Mineral P; N₂O; pesticides | (i) | Lognormal CV 0.15; 0.40; 0.30 | Fertilizer statistics; Tier 1 N₂O emission factors span a factor of about three; FAOSTAT imputation of pesticide use |')
A('| Cotton share of pesticide use | (i) | Active ingredient per dose triangular (Table S4); tender quantities × uniform (0.85, 1.15) | Label doses of admissible formulations; tender quantities are indicative within ±15% [@SOFITEX2021] |')
A('| Cotton N removal in seed cotton | (i) | Triangular (18, 22, 26 kg N t⁻¹) | Typical agronomic range |')
CV = json.load(open('conv.json'))
A(f"\nN = {R['MC_settings']['N']:,} draws per principle (seed 20261020). Principles are not sampled. Variance shares and exceedance probabilities are conditional on these distributions, several of which are expert judgements. Convergence: rerunning with seeds 1 and 2, and with 100,000 draws, changes medians by at most {CV['max_rel_diff_median']*100:.1f}%, 5th and 95th percentiles by at most {CV['max_rel_diff_p05']*100:.1f}% and {CV['max_rel_diff_p95']*100:.1f}%, and exceedance probabilities by at most {CV['max_abs_diff_P_exceed']:.3f}.\n")
A('Table S12. Monte Carlo ASR by indicator and principle, 2021–2023: median [5th–95th percentile]; exceedance probability P; share of the variance of log ASR due to the global boundary value.\n')
A('| Indicator | EPC | AP | GF | RE |\n|---|---|---|---|---|')
for d in D:
    cells = []
    for p in ['EPC', 'AP', 'GF', 'RE']:
        mc = R['MC'][d].get(p)
        if mc is None: cells.append('–'); continue
        lo = f"{mc['p05']:.3g}" if mc['p05'] > 0 else '<0'
        cells.append(f"{mc['median']:.3g} [{lo}–{mc['p95']:.3g}]; P = {mc['P_exceed']:.2f}; boundary {mc['var_share_boundary']*100:.0f}%")
    A(f"| {NM[d]} | " + ' | '.join(cells) + ' |')
A('\nUnder GF, the national share is proportional to the national pressure, so pressure-data uncertainty cancels and only the boundary value varies. For pesticides, the Monte Carlo median exceeds the central ratio because the boundary distribution is skewed towards the precautionary 0.2 Tg yr⁻¹.\n')

A('# S7. Structural sensitivity\n')
A('Structural alternatives (uncertainty class iii) are reported separately from the Monte Carlo intervals and are tested one at a time.\n')
A('Table S13. EPC ratio under alternative specifications.\n')
A('| Case | Central EPC ratio | Alternative EPC ratio | Verdict changes? |\n|---|---|---|---|')
cases = [('Climate: include cotton', 'climate', s['climate_incl_cotton']), ('Climate: exclude land-use change', 'climate', s['climate_no_luc']),
         ('Climate: farm gate only', 'climate', s['climate_farmgate_only']), ('Climate: add imported cereals at domestic intensity', 'climate', s['climate_import_adjusted']),
         ('Climate: remove recorded live-animal exports', 'climate', s['livestock_export_adjusted_climate']),
         ('Agricultural land: include cotton', 'agland', s['agland_incl_cotton']), ('Agricultural land: restoration target (39.5 Mkm²)', 'agland', s['agland_restoration_39_5']),
         ('Land: Willett cropland boundary (13 Mkm²)', 'agland', s['cropland_willett13']), ('Land: Sentinel-2 cultivated area, Willett boundary', 'agland', s['cropland_sentinel']),
         ('Blue water: withdrawal counted as use', 'bluewater', s['bluewater_withdrawal']), ('Blue water: Willett boundary (2,500 km³)', 'bluewater', s['bluewater_willett2500']),
         ('N surplus: cropland component only', 'N_surplus', s['N_surplus_cropland_only']), ('N surplus: no pasture leaching (IPCC dry climate)', 'N_surplus', s['N_surplus_no_pasture_leaching']),
         ('N surplus: strict 43 Tg N boundary', 'N_surplus', s['N_surplus_strict43']), ('N: EAT–Lancet input translation (134 Tg N)', 'N_surplus', s['N_inputs_EAT134']),
         ('N: input translation, cropland only', 'N_surplus', s['N_inputs_cropland_only']), ('N: Willett N application (90 Tg N)', 'N_surplus', s['N_application_willett90']),
         ('Mineral P: include cotton', 'P_application', s['P_application_incl_cotton']), ('P: delivery to surface water (exploratory)', 'P_application', s['P_delivery_tW']),
         ('P: delivery against local critical load', 'P_application', s['P_delivery_local_critical']), ('N₂O: include cotton', 'N2O', s['N2O_incl_cotton']),
         ('N surplus: include cotton', 'N_surplus', s['N_surplus_incl_cotton']), ('Pesticides: include cotton', 'pesticides', s['pesticides_incl_cotton']),
         ('Pesticides: cotton share at its 5th percentile', 'pesticides', s['pesticides_cotton_share_low']), 
         ('Pesticides: 0.2 Tg boundary', 'pesticides', s['pesticides_strict02'])]
for n, d, v in cases:
    c0 = R['ASR_base'][d]['EPC']; A(f"| {n} | {c0:.2f} | {v:.2f} | {'Yes' if (c0 > 1) != (v > 1) else 'No'} |")
A('\nFor the land rows that use the Willett cropland boundary, the central ratio shown is that of agricultural land; for the nitrogen input and application rows, it is that of the agricultural nitrogen surplus.\n')

# ---------------- S8. Food-security scenarios ----------------
SC = json.load(open('scen.json')); M = SC['meta']; GR = SC['grid']
DN = {'current': 'Current diet', 'adequate': 'Adequate, current mix', 'PHD': 'Planetary health diet (PHD)', 'PHDmono': 'PHD-poultry', 'world': 'World-average mix'}
A('# S8. Food-security scenarios: diet, trade, and yield gaps\n')
A('The scenarios of Section 2.6 combine five diets, two trade regimes, and three cereal-yield levels. They are computed by scen.py from the inputs below; with the current diet, current trade, and current yields in 2021–2023, they reproduce the ratios of Table 4 of the main text.\n')
A('Table S14. Scenario inputs. (a) Food supply by food group, kcal cap⁻¹ d⁻¹, reached in 2050 and held to 2100. (b) Self-sufficiency ratios, yields, and coefficients.\n')
grp = [('cereals', 'Cereals'), ('roots', 'Starchy roots'), ('sugar', 'Sugar and sweeteners'), ('pulses', 'Pulses'), ('oil', 'Oilseeds, nuts, and vegetable oils'),
       ('vegetables', 'Vegetables'), ('fruits', 'Fruits'), ('other', 'Spices and stimulants'), ('alcohol', 'Alcoholic beverages'), ('rum', 'Ruminant products (meat, milk, offal, fats)'),
       ('mono', 'Pork, poultry, and eggs'), ('fish', 'Fish and seafood')]
A('| Food group | ' + ' | '.join(DN[k] for k in DN) + ' |\n|---|' + '---|' * len(DN))
for g, gl in grp: A(f'| {gl} | ' + ' | '.join(f"{M['diets'][k][g]:.0f}" for k in DN) + ' |')
A('| Unallocated items | ' + ' | '.join(f"{M['resid0']:.0f}" for k in DN) + ' |')
A('| Total | ' + ' | '.join(f"{sum(M['diets'][k].values()) + M['resid0']:,.0f}" for k in DN) + ' |')
A('| Animal-source share (%) | ' + ' | '.join(f"{100 * M['animal_share'][k]:.1f}" for k in DN) + ' |')
A('\nSources: FAOSTAT food balances, Burkina Faso and World, 2021–2023 [@FAO2026]; PHD food-group targets of Table 1 in Rockström et al. [-@Rockstrom2025], scaled from about 2,400 kcal of intake to 3,000 kcal of supply. PHD-poultry exchanges the 145 kcal of dairy for poultry and eggs, as Table 1 of the Commission allows. Red meat in the PHD is split between ruminant and pig meat in the national proportion.\n')
A('| Parameter | Value | Source |\n|---|---|---|')
for g, gl in [('cereals', 'Cereals'), ('roots', 'Starchy roots'), ('sugar', 'Sugar'), ('pulses', 'Pulses'), ('oil', 'Oilseeds and nuts (seed equivalent)'), ('vegetables', 'Vegetables'), ('fruits', 'Fruits')]:
    A(f"| SSR, {gl.lower()} | {M['ssr0'][g]:.2f} | FAOSTAT FBS, 2021–2023 |")
A(f"| SSR, ruminant products (kcal-weighted) | {M['SSR_R0']:.2f} | FAOSTAT FBS |")
A(f"| Vegetable-oil extraction rate (t oil per t oilseed processed) | {M['oil_extraction']:.2f} | FAOSTAT FBS |")
for c_ in ['maize', 'sorghum', 'millet', 'rice']:
    A(f"| {c_.capitalize()}: actual yield / Yw (t ha⁻¹) | {M['Ya'][c_]:.2f} / {M['Yw'][c_]:.2f} ({100 * M['ratio_Ya_Yw'][c_]:.0f}%) | FAOSTAT QCL; Yield Potential and Yield Gap Atlas [-@YPYGA2026] |")
A(f"| Livestock emissions, ruminant / monogastric / draught (Mt CO₂eq yr⁻¹) | {M['E_rum']/1e3:.2f} / {M['E_mono']/1e3:.2f} / {M['E_dr']/1e3:.2f} | FAOSTAT GLE, 2021–2023 |")
A(f"| Emission intensity, ruminant vs monogastric products (per kcal produced) | {M['int_rum_per_kcal']/M['int_mono_per_kcal']:.0f} : 1 | FAOSTAT GLE and FBS |")
A(f"| Share of manure N on pasture from ruminants / poultry | {100*M['n_rum']:.1f}% / {100*M['n_mono']:.1f}% | FAOSTAT GLE |")
A(f"| Land-use-change emissions per hectare of cropland expansion | {M['luc_t_per_ha']:.0f} t CO₂eq | FAOSTAT GT and RL |")
A('| Grain N removal | 15 (12–18) kg N t⁻¹ | Assumption, tested |')
A('| Recovery of additional fertilizer N | 50% (30–70%) | Assumption, tested |')
A('| Grain P removal, replaced | 3 kg P t⁻¹ | Assumption |')
A(f"| Mineral N on food crops, 2021–2023 | {M['Nmin0']:.1f} kt N | FAOSTAT ESB minus cotton |")
A('')
A('Table S15. Full scenario results under EPC: (a) 2050; (b) 2100. ΔCropland, cropland change since 2021–2023 (Mha); Ag. land, agricultural land as a share of the national land area (%); Min. N, mineral N on food crops (kt); the remaining columns are EPC ratios (Clim., climate; no LUC, climate without land-use change; Land, agricultural land; N surp., nitrogen surplus; Pest., pesticides; P, mineral phosphorus).\n')
TRN = {'current': 'imports as today', 'self': 'self-sufficient'}; YN = {'current': 'current yields', 'Yw50': '50% Yw', 'Yw80': '80% Yw'}
DS = {'current': 'Current', 'adequate': 'Adequate', 'PHD': 'PHD', 'PHDmono': 'PHD-poultry', 'world': 'World mix'}
for lab, t in [('(a)', '2050'), ('(b)', '2100')]:
    A(f'{lab} {t}\n')
    A('| Scenario | ΔCropland | Ag. land | Min. N | Clim. | no LUC | Land | N surp. | N₂O | Pest. | P |\n|' + '-' * 30 + '|' + '|'.join(['-' * 11] * 10) + '|')
    for k, v in GR.items():
        dk, tk, yk = k.split('|'); a, g = v[t]['ASR'], v[t]['diag']
        A(f"| {DS[dk]}; {TRN[tk]}; {YN[yk]} | {g['cropland_change_Mha']:+.1f} | {100*g['agland_share_of_land']:.0f} | {g['Nmin_kt']:.0f} | {a['climate']:.2f} | {a['climate_nonLUC']:.2f} | {a['agland']:.2f} | {a['N_surplus']:.2f} | {a['N2O']:.2f} | {a['pesticides']:.2f} | {a['P_application']:.2f} |")
    A('')
A('Cropland change in 2100 is cumulative since 2021–2023. Land-use-change emissions in 2100 follow the rate of cropland expansion between 2050 and 2100. Agricultural land includes cotton.\n')
A('Table S16. One-at-a-time tests of the agronomic assumptions, self-sufficiency with cereal yields at 80% of Yw, 2050: EPC ratios (abbreviations as in Table S15) and cropland change since 2021–2023 (Mha).\n')
A('| Diet | Case | Clim. | Land | N surp. | N₂O | Pest. | P | ΔCropland |\n|' + '-' * 16 + '|' + '-' * 26 + '|' + '|'.join(['-' * 11] * 7) + '|')
CASES = {'central': 'Central', 'NUE_0.7': 'Fertilizer N recovery 70%', 'NUE_0.3': 'Fertilizer N recovery 30%', 'Ngrain_12': 'Grain N 12 kg t⁻¹',
         'Ngrain_18': 'Grain N 18 kg t⁻¹', 'livestock_intensity_-30%': 'Ruminant emission intensity −30%', 'noncereal_yield_gain': 'Other crops gain as much as cereals'}
for dk in ['current', 'adequate', 'PHD', 'PHDmono']:
    for ck, cl in CASES.items():
        v = SC['sens'][f'{dk}|self|Yw80|{ck}']
        A(f"| {DN[dk] if ck == 'central' else ''} | {cl} | {v['climate']:.2f} | {v['agland']:.2f} | {v['N_surplus']:.2f} | {v['N2O']:.2f} | {v['pesticides']:.2f} | {v['P_application']:.2f} | {v['cropland_change_Mha']:+.2f} |")
A('')
A('# References\n\n::: {#refs}\n:::\n')
open('supplementary_material.md', 'w').write('\n'.join(L))
print('ok', len('\n'.join(L).split()))
