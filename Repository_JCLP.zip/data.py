"""Official input data, retrieved 20 Oct 2026 from the FAOSTAT API (faostatservices.fao.org)
and the World Bank WDI API. Area codes: Burkina Faso = 233, World = 5000.
Units are noted per series. Years listed explicitly.
"""

YEARS = [2010, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023]

# ---------- FAOSTAT GT (Emissions totals), Emissions (CO2eq) (AR5), kt, source FAO TIER 1 ----------
GT = {
    # Burkina Faso
    'BFA_agrifood':   [43140.7, 42147.8, 42577.7, 42977.5, 44195.5, 44595.9, 44955.0, 45768.6, 41915.3, 44583.8, 44785.1, 45902.4],
    'BFA_farmgate':   [20759.0, 21719.9, 22069.6, 22305.6, 23463.2, 23682.4, 23909.4, 24363.7, 20372.9, 23077.0, 23140.1, 24301.6],
    'BFA_luc':        [19737.5, 17451.3, 17451.3, 17451.3, 17323.1, 17323.1, 17323.1, 17323.1, 17323.1, 17147.2, 17147.2, 17147.2],
    'BFA_prepost':    [2644.21, 2976.53, 3056.73, 3220.59, 3409.19, 3590.37, 3722.45, 4081.78, 4219.22, 4359.62, 4497.82, 4453.65],
    'BFA_livestock':  [17559.1, 18759.2, 19208.3, 19725.6, 20240.9, 20698.1, 21164.2, 21657.8, 17312.5, 19819.1, 20158.6, 20499.3],
    'BFA_crops':      [1575.10, 1679.66, 1657.76, 1651.67, 1978.27, 1872.90, 1903.94, 1860.33, 2160.26, 2251.42, 2173.52, 2334.37],
    'BFA_afolu':      [41162.8, 40087.6, 40433.3, 40668.8, 41881.4, 42096.3, 42319.1, 42794.1, 38799.8, 41672.1, 41735.0, 42895.3],
    'BFA_agrifood_CH4': [15500.8, 16253.7, 16567.1, 16765.3, 17523.7, 17749.8, 17912.4, 18392.7, 15760.2, 17823.8, 17800.5, 18518.9],
    'BFA_agrifood_N2O': [7415.29, 7720.14, 7781.26, 7849.61, 8278.24, 8298.73, 8397.58, 8456.23, 7125.43, 7788.92, 7914.13, 8385.26],
    # World
    'WLD_agrifood':   [15120400, 15515700, 16004300, 16047700, 15399800, 15484800, 15689400, 15996600, 15741600, 16053000, 16152500, 16535100],
    'WLD_farmgate':   [7253480, 7433470, 7500870, 7509600, 7584830, 7707200, 7701700, 7731740, 7834440, 7928670, 7966440, 8096970],
    'WLD_luc':        [3486660, 3355270, 3706110, 3745220, 2949840, 2905080, 3066980, 3332320, 2930570, 2970260, 2938610, 3190130],
    'WLD_prepost':    [4380250, 4726980, 4797330, 4792880, 4865170, 4872470, 4920770, 4932570, 4976600, 5154080, 5247430, 5247970],
}
# Burkina Faso 2022 detail (kt CO2eq AR5): enteric fermentation 12,945.1; manure left on pasture 6,155.9;
# rice 1,384.9; manure management 796.9; savanna fires 783.5; net forest conversion 17,147.2;
# agrifood waste disposal 2,574.9; food retail 1,155.2; food transport 369.3.

# ---------- FAOSTAT RL (Land use), area, 1000 ha ----------
RL = {
    'BFA_cropland':    [6591.58, 7163.48, 7320.69, 7489.04, 7628.28, 7778.51, 8007.28, 8138.79, 8270.60, 8408.90, 8587.01, 8596.34],
    'BFA_agri':        [15435, 15966.7, 16109.8, 16278, 16398.8, 16538.7, 16705.7, 16761.8, 16882.8, 16975.9, 17119.7, 17129],
    'BFA_pasture':     [8843.38, 8803.18, 8789.08, 8788.95, 8770.5, 8760.18, 8698.41, 8622.96, 8612.2, 8567, 8532.69, 8532.69],
    'BFA_forest':      [5034.87, 4675.29, 4555.43, 4435.57, 4315.71, 4195.85, 4075.99, 3956.13, 3836.27, 3716.41, 3596.55, 3476.69],
    'WLD_cropland':    [1526560, 1545790, 1551910, 1559720, 1562550, 1568210, 1572510, 1571260, 1577190, 1582150, 1581220, 1584740],
    'WLD_agri':        [4699310, 4701110, 4701930, 4680210, 4674370, 4704090, 4690730, 4689820, 4685300, 4696340, 4691200, 4686700],
    'WLD_forest':      [4201000, 4189260, 4185350, 4181430, 4178190, 4174960, 4171720, 4168480, 4165240, 4160230, 4155230, 4150230],
}
RL_2000 = {'BFA_cropland': 5211.43, 'BFA_agri': 14582.4, 'BFA_forest': 6377.97, 'BFA_land': 27360}

# ---------- FAOSTAT ESB (Cropland nutrient balance), t ----------
# item 5079 = total inputs, 5081 = balance (surplus); element 7275 = N, 7280 = P
ESB = {
    'BFA_N_surplus':  [24076.3, 17868.9, 8709.2, 29212.0, 54937.5, 47909.7, 35642.1, 3339.7, 24392.3, 35855.5, 24581.4, 44911.0],
    'BFA_P_surplus':  [-13530.4, -10710.1, -12140.2, -8611.2, -6583.7, -6962.2, -9307.7, -16333.3, -15579.0, -15922.7, -15862.9, -12543.9],
    'BFA_P_inputs':   [16064.9, 23584.3, 22915.9, 23875.1, 27666.6, 25612.0, 24884.0, 21043.0, 23503.4, 18191.0, 22968.6, 26626.0],
    'BFA_N_inputs':   [172342.1, 188411.5, 183534.7, 193173.2, 228251.7, 210325.1, 204772.5, 189505.4, 223323.2, 206543.9, 222321.4, 245814.7],
    'BFA_N_mineral':  [41122, 50680, 48800, 51086, 67638, 58292, 56655, 30052, 53983, 46912, 54354.5, 66969],
    'WLD_N_surplus':  [84651640, 85536959, 83411993, 83455307, 83599587, 82961283, 82843355, 81695338, 87423508, 84279836, 83145265, 85325524],
    'WLD_P_surplus':  [9840039, 8895357, 8707859, 8534595, 8172640, 8382046, 8225312, 7873284, 9399350, 8176963, 6839099, 6796087],
    'WLD_P_inputs':   [24527403, 25167889, 25410639, 25314070, 25363606, 26186049, 25789415, 25708368, 27422076, 26601536, 25258202, 25624391],
}

# ---------- FAOSTAT EMN (Livestock manure), item 1755 All Animals, N content, kg ----------
EMN = {
    'BFA_pasture_dep':   [657164000, 703678000, 721673000, 742908000, 760843000, 779150000, 798131000, 817954000, 667826000, 733787000, 745361000, 756780000],
    'BFA_pasture_vol':   [131433000, 140736000, 144335000, 148582000, 152169000, 155830000, 159626000, 163591000, 133565000, 146757000, 149072000, 151356000],
    'BFA_pasture_leach': [197149000, 211104000, 216502000, 222872000, 228253000, 233745000, 239439000, 245386000, 200348000, 220136000, 223608000, 227034000],
    'WLD_pasture_vol':   [16054900000, 16658100000, 16804400000, 17037800000, 17291000000, 17506700000, 17652000000, 17976600000, 18290800000, 18487000000, 18753400000, 18997300000],
    'WLD_pasture_leach': [24082300000, 24987200000, 25206600000, 25556600000, 25936500000, 26260000000, 26478000000, 26965000000, 27436300000, 27730600000, 28130000000, 28496000000],
}

# ---------- FAOSTAT RP (Pesticides use), item 1357 total, agricultural use, t ----------
RP = {
    'BFA': [1043, 1560, 1781, 2046, 2646, 2938, 3123, 2793, 2849, 3038, 3498, 4019],
    'WLD': [3032859, 3267624, 3281572, 3321011, 3441183, 3356535, 3421829, 3501888, 3533434, 3800607, 3822598, 3725946],
}
RP_2000 = {'BFA': 750, 'WLD': 2176167}

# ---------- FAOSTAT FBS (Food balances), food supply kcal/cap/day ----------
# Available years; 2013-2014, 2016-2017 interpolated linearly in the model. Series break in 2019 (animal products).
FBS_DES = {'BFA': {2010: 2595.29, 2015: 2645.45, 2018: 2648.69, 2019: 2628.08, 2020: 2683.58, 2021: 2664.25, 2022: 2758.83, 2023: 2790.88},
           'WLD': {2010: 2825.19, 2015: 2888.55, 2018: 2926.08, 2019: 2941.79, 2020: 2952.62, 2021: 2974.94, 2022: 2997.70, 2023: 3016.00}}
FBS_ANIMAL_KCAL = {'BFA': {2021: 236.28, 2022: 218.12, 2023: 216.95}, 'WLD': {2021: 521.26, 2022: 529.79, 2023: 536.18}}
FBS_PROTEIN = {'BFA': {2021: 89.25, 2022: 94.96, 2023: 92.56}, 'WLD': {2021: 90.91, 2022: 91.82, 2023: 92.47}}

# ---------- FAOSTAT FS (Suite of food security indicators) ----------
FS = {
    'BFA': {'PoU_pct_2022_2024': 12.2, 'PoU_pct_2017_2019': 15.1,
            'FIES_modsev_pct_2022_2024': 41.4, 'FIES_modsev_pct_2017_2019': 39.1,
            'DES_adequacy_pct_2022_2024': 123, 'cereal_import_dep_pct_2021_2023': 20.5},
    'WLD': {'PoU_pct_2022_2024': 8.4, 'FIES_modsev_pct_2022_2024': 27.4, 'DES_adequacy_pct_2022_2024': 126},
}

# ---------- World Bank WDI ----------
WDI_POP = {  # SP.POP.TOTL
    'BFA': {2010: 16.176e6, 2013: 17.695e6, 2014: 18.229e6, 2015: 18.777e6, 2016: 19.335e6, 2017: 19.894e6, 2018: 20.438e6,
            2019: 20.962e6, 2020: 21.479e6, 2021: 21.995e6, 2022: 22.509e6, 2023: 23.026e6, 2024: 23.549e6},
    'WLD': {2010: 7.0009e9, 2013: 7.2654e9, 2014: 7.3535e9, 2015: 7.4411e9, 2016: 7.5282e9, 2017: 7.6138e9, 2018: 7.6962e9,
            2019: 7.7772e9, 2020: 7.8539e9, 2021: 7.9196e9, 2022: 7.9886e9, 2023: 8.0629e9, 2024: 8.1409e9},
}
WDI = {
    'BFA_water_withdrawal_km3': 0.818,      # ER.H2O.FWTL.K3 (AQUASTAT; latest reported value)
    'BFA_ag_share_withdrawal_pct': 51.43,   # ER.H2O.FWAG.ZS
    'BFA_internal_renewable_km3': 12.5,     # ER.H2O.INTR.K3
    'BFA_water_stress_pct': 7.82,           # ER.H2O.FWST.ZS (SDG 6.4.2)
    'WLD_water_withdrawal_km3': 3853.1,     # 2022
    'WLD_ag_share_withdrawal_pct': 71.015,  # 2022
    'BFA_gdppc_2024': 982.49, 'WLD_gdppc_2024': 13717.0,   # NY.GDP.PCAP.CD
    'BFA_urban_pct_2022': 27.279, 'WLD_urban_pct_2022': 57.072,  # SP.URB.TOTL.IN.ZS
    'BFA_cereal_yield_kg_2022_2024': [1204.1, 1221.1, 1197.9],
}

# ---------- UN WPP 2024, medium variant (as in the original manuscript) ----------
UN_POP = {'BFA': {2025: 24.075e6, 2050: 37.304e6, 2075: 46.764e6, 2100: 49.846e6},
          'WLD': {2025: 8161.973e6, 2050: 9664.379e6, 2075: 10250.493e6, 2100: 10180.161e6}}

# ---------- Food-system boundaries (te Wierik et al., 2025) ----------
# value = central; (lower, mode, upper) used for triangular sampling
FSB = {
    'climate':   {'central': 5.0,  'tri': (4.7, 5.0, 5.3),  'unit': 'Gt CO2eq/yr', 'current_global_tw': 16.0},
    'cropland':  {'central': 13.0, 'tri': (11.0, 13.0, 15.0), 'unit': 'Mkm2'},       # Willett et al. 2019 cropland boundary (land-use quantity)
    'bluewater': {'central': 2000, 'tri': (780, 2000, 3190), 'unit': 'km3/yr', 'current_global_tw': 1500},
    'nitrogen':  {'central': 57.0, 'tri': (43.0, 57.0, 57.0), 'unit': 'Tg N/yr surplus', 'current_global_tw': 119.0},
    'phosphorus':{'central': 4.6,  'tri': (3.1, 4.6, 6.1), 'unit': 'Tg P/yr delivered to surface water', 'current_global_tw': 7.16},
    'pesticides':{'central': 1.0,  'tri': (0.3, 1.0, 1.0), 'unit': 'Tg active substance/yr', 'current_global_tw': 3.6},
}
# te Wierik et al. (2025) global P delivery to surface water by source (Tg P/yr): agriculture 5.36, aquaculture 0.196, wastewater 1.6
TW_P = {'agri': 5.36, 'aqua': 0.196, 'wastewater': 1.6}
P_CRIT_CONC = 0.075   # mg P/L, critical concentration (te Wierik SI 5b)
P_RIVER_RETENTION = 0.53

# Responsibility multiplier: world / national cumulative per-capita fossil CO2 (fossil fuels and cement, 1750-2022),
# Global Carbon Budget national emissions (Friedlingstein et al., 2023) as compiled by Our World in Data
# (grapher 'cumulative-co-emissions', retrieved 21 Oct 2026), divided by 2022 population (OWID/UN WPP).
GCB_CUM_2022 = {'BFA': 82973650.0, 'WLD': 1772431200000.0}   # t CO2, cumulative 1750-2022
POP_2022_OWID = {'BFA': 22509038, 'WLD': 8021407196}
RE_MULT = (GCB_CUM_2022['WLD'] / POP_2022_OWID['WLD']) / (GCB_CUM_2022['BFA'] / POP_2022_OWID['BFA'])

# NDC 3.0 (Burkina Faso, 2025)
NDC = {'red_2030': 0.3087, 'red_2035': 0.5523, 'red_2050': 0.7555, 'uncond_2030': 0.2237, 'bau_growth': 0.020461}
IPCC = {'C1': {2030: 0.43, 2040: 0.69, 2050: 0.84}, 'C3': {2030: 0.21, 2040: 0.46, 2050: 0.64},
        'C1_lo': {2030: 0.34, 2040: 0.58, 2050: 0.73}, 'C1_hi': {2030: 0.60, 2040: 0.90, 2050: 0.98},
        'C3_lo': {2030: 0.01, 2040: 0.34, 2050: 0.53}, 'C3_hi': {2030: 0.42, 2040: 0.63, 2050: 0.77}}

# ======================= Additions (retrieved 20 Oct 2026, second pass) =======================
Y00 = list(range(2000, 2024))
# FAOSTAT GT annual 2000-2023, Burkina Faso, kt CO2eq (AR5)
GT00 = {
    'farmgate': [14502, 13599.7, 14242.4, 17564.3, 18142, 18705.2, 18390.4, 18783.9, 19278.3, 19836, 20759, 20995.2, 21070.3, 21719.9, 22069.6, 22305.6, 23463.2, 23682.4, 23909.4, 24363.7, 20372.9, 23077, 23140.1, 24301.6],
    'luc': [28650.4, 19737.5, 19737.5, 19737.5, 19737.5, 19737.5, 19737.5, 19737.5, 19737.5, 19737.6, 19737.5, 17451.4, 17451.3, 17451.3, 17451.3, 17451.3, 17323.1, 17323.1, 17323.1, 17323.1, 17323.1, 17147.2, 17147.2, 17147.2],
    'prepost': [2039.71, 2125.43, 2201.21, 2291.36, 2370.55, 2472.85, 2552.74, 2624.53, 2526.77, 2573.04, 2644.21, 2714.33, 2869.88, 2976.53, 3056.73, 3220.59, 3409.19, 3590.37, 3722.45, 4081.78, 4219.22, 4359.62, 4497.82, 4453.65],
    'synth_fert': [54.4045, 5.1145, 11.1035, 146.889, 160.458, 195.517, 165.519, 130.115, 168.752, 156.668, 226.893, 163.903, 262.217, 279.628, 269.267, 281.88, 373.2, 321.63, 312.594, 165.81, 278.462, 235.188, 299.106, 358.863],
    'crop_residues': [176.914, 230.603, 231.107, 262.748, 218.731, 253.578, 248.252, 237.069, 314.767, 267.862, 333.397, 276.66, 336.259, 337.69, 303.531, 289.089, 322.823, 300.483, 363.712, 352.662, 360.851, 347.336, 376.3, 368.138],
    'burning_residues': [25.0442, 34.8019, 38.0755, 43.7385, 38.6239, 44.6576, 44.5275, 46.8092, 61.7095, 60.1483, 81.6447, 73.3461, 87.0671, 93.4911, 78.3711, 84.8903, 94.9474, 98.8827, 104.6, 105.035, 113.302, 126.483, 113.246, 126.07],
    'onfarm_energy': [8.3967, 12.219, 12.6742, 12.3056, 13.4413, 11.1736, 12.7867, 12.9228, 12.6304, 15.2, 15.8369, 19.7154, 23.8744, 24.3165, 28.294, 28.7761, 32.4462, 36.7534, 40.9521, 20.479, 23.8078, 24.1973, 24.3935, 25.5676],
    'pest_manuf': [10.187, 8.3126, 8.0852, 4.4615, 8.3613, 6.6445, 13.1129, 9.9943, 34.056, 9.0035, 9.2728, 8.231, 13.2001, 9.2393, 2.3026, 28.4892, 47.5069, 48.7683, 48.8709, 25.8682, 58.5843, 40.3598, 117.775, 22.3604],
}
RL00_cropland = [5211.43, 5340.79, 5468.82, 5579.38, 5739.72, 5881, 6018.78, 6151.27, 6289.93, 6431.51, 6591.58, 6794.94, 6898.1, 7163.48, 7320.69, 7489.04, 7628.28, 7778.51, 8007.28, 8138.79, 8270.6, 8408.9, 8587.01, 8596.34]
RP00 = [750, 558, 762, 1060, 1387, 1581, 1809, 1759, 1528, 1166, 1043, 1059, 1255, 1560, 1781, 2046, 2646, 2938, 3123, 2793, 2849, 3038, 3498, 4019]
# FAOSTAT ESB annual 2000-2023, Burkina Faso, t
ESB00 = {
    'N_mineral': [9860, 926, 2010, 26620, 29081, 35435, 30000, 23580, 30584, 28392, 41122, 29705, 47525, 50680, 48800, 51086, 67638, 58292, 56655, 30052, 53983, 46912, 54354.5, 66969],
    'N_bnf': [23490.1, 34803.2, 35932.6, 40541.9, 32654.5, 29509.6, 30364.8, 36790.2, 41833.3, 44286.9, 44995.7, 40678.3, 44127.2, 47086.6, 42246.1, 46494.9, 62275.1, 52317.9, 45907.6, 55209.6, 80021.9, 72518.2, 79079.0, 89231.6],
    'P_mineral': [6584.908, 201.868, 0, 5849.812, 6319.384, 9656.092, 7848, 5822.344, 5868.56, 5555.512, 3368.536, 6659.464, 7296.46, 10062.88, 9321.244, 9821.336, 13251.784, 10996.792, 9964.344, 5953.144, 12283.428, 7893.78, 12400.494, 15919.886],
}
ESB_N_outputs_BFA_2021_2023 = [170688.4123, 197740.0096, 200903.6756]   # item 5080, t N
# World ESB 2021-2023, t
ESB_WLD = {'N_mineral': [103639455.11, 102155592.845, 105788207.185], 'N_bnf': [40463544.3743, 40403729.012, 41266301.1159],
           'P_mineral': [19764635.3395, 18359632.8474, 18694755.8195]}
# FAOSTAT FBSH (old methodology) DES, kcal/cap/d, 2000-2009 (series break with FBS in 2010)
FBSH_DES = {2000: 2318, 2001: 2332, 2002: 2411, 2003: 2492, 2004: 2505, 2005: 2463, 2006: 2559, 2007: 2546, 2008: 2588, 2009: 2639}
# WDI population 2000-2012 (SP.POP.TOTL)
WDI_POP['BFA'].update({2000: 11925546, 2001: 12295001, 2002: 12680897, 2003: 13082532, 2004: 13500533, 2005: 13932123, 2006: 14373707,
                       2007: 14816307, 2008: 15258093, 2009: 15710066, 2011: 16.662e6, 2012: 17.172e6})
# Cotton (non-food fibre): FAOSTAT QCL seed cotton area harvested, ha
COTTON_AREA = {2021: 611325, 2022: 692036, 2023: 612380}
# IFA fertilizer use by crop, Burkina Faso, 2015-2017 (t nutrient): cotton vs all crops
IFA_COTTON = {'N_cotton': 31636 + 38064 + 41050, 'N_total': 65396 + 72885 + 82091, 'P2O5_cotton': 19555 + 23271 + 24390, 'P2O5_total': 38741 + 43861 + 48078}
# Official live-animal trade (FAOSTAT TCL, export quantity, head) and slaughter (QCL), 2021-2023
LIVE_EXPORT = {'cattle': [2151, 2517, 3501], 'sheep': [11604, 26137, 55874], 'goats': [2828, 2249, 5582]}
SLAUGHTER = {'cattle': [1271085, 1273489, 1240000], 'sheep': [2980260, 3018239, 3056701], 'goats': [3301753, 3307816, 3313874]}
# Willett et al. (2019) boundaries used for N and P application, and blue water alternative
FSB.update({
    'N_surplus':     {'central': 57.0, 'tri': (43.0, 57.0, 57.0), 'unit': 'Tg N/yr agricultural surplus (te Wierik et al., 2025)', 'current_global_tw': 119.0},
    'N_application': {'central': 90.0, 'tri': (65.0, 90.0, 140.0), 'unit': 'Tg N/yr industrial + agricultural fixation (Willett et al., 2019)'},
    'P_application': {'central': 8.0,  'tri': (6.0, 8.0, 16.0), 'unit': 'Tg P/yr applied (Willett et al., 2019)'},
})
CEREAL_SHARE_DES_2021_2023 = (1600.12 + 1607.36 + 1591.6) / 3   # FBS item 2905, kcal/cap/d

# ======================= Third pass: EAT-Lancet 2025 Table 2 (te Wierik et al. 2025) operational indicators =======================
ESB_WLD_N_inputs = [187525205.162, 186364631.1654, 191014022.0951]          # ESB 5079/7275, t, 2021-2023
EMN_WLD_pasture_dep = [92435200000, 93766800000, 94986500000]               # EMN 72380, kg N, 2021-2023
GT_N2O = {'BFA': [7788.92, 7914.13, 8385.26], 'WLD': [2341260, 2323150, 2381800]}   # agrifood CO2eq from N2O (AR5), kt, 2021-2023
GWP_N2O_AR5 = 265
EMN_BFA_pasture_dep_2000_2005 = {2000: 428261000, 2005: 580555000}
FSB.update({
    'agland':   {'central': 48.0, 'tri': (39.5, 48.0, 48.0), 'unit': 'Mkm2 agricultural land (EAT-Lancet 2025; te Wierik 2025)'},
    'N_inputs': {'central': 134.0, 'tri': (134.0, 134.0, 140.0), 'unit': 'Tg N/yr agricultural inputs on cropland and grassland (EAT-Lancet 2025)', 'current_global_tw': 233.0},
    'N2O':      {'central': 1.8, 'unit': 'Tg N2O-N/yr (EAT-Lancet 2025)', 'current_global_tw': (3.9, 4.05, 4.2)},
})
FSB['pesticides']['tri'] = (0.2, 1.0, 1.0)   # EAT-Lancet 2025 Table 2: 0.2 Tg (low risk) to 1 Tg (avoid high risk)

# ---------------- cotton: production, pesticide inputs, and links to food (added 21 Oct 2026) ----------------
# FAOSTAT QCL (retrieved 21 Oct 2026): seed cotton (328), cotton lint (767), cottonseed (329), cottonseed oil (331), t
COTTON_QCL = {'seed_cotton': {2021: 680767, 2022: 668633.1, 2023: 723171.92}, 'lint': {2021: 234397.72, 2022: 270208.48, 2023: 214864.58},
              'cottonseed': {2021: 422000, 2022: 415000, 2023: 448000}, 'cottonseed_oil': {2021: 8000, 2022: 8000, 2023: 8000}}
# FAOSTAT FBS 2575 cottonseed oil, food supply (kcal/cap/d)
FBS_COTTONSEED_OIL_KCAL = {2021: 4.99, 2022: 4.04, 2023: 6.89}
# FAOSTAT RP agricultural use by category (t active ingredients); fungicides reported as 0
RP_CAT = {'insecticides': {2021: 670, 2022: 772, 2023: 887}, 'herbicides': {2021: 2367, 2022: 2726, 2023: 3132}}
# SOFITEX call for tenders No. 21 08 002, cotton campaign 2022/2023 (SOFITEX, 2021): quantities ordered for its cotton area
SOFITEX = {'cotton_area_ha': 478000,                      # area covered by pre-emergence granular herbicide = SOFITEX cotton area
           'insect_doses': {'T1': 890000, 'T2': 965000, 'T3': 858000},   # 1 dose = treatment of 1 ha
           'herb_pre_gran_ha': 478000, 'herb_pre_liq_ha': 15000, 'herb_post_L': 77000}
# active ingredient per dose (kg a.i. per ha-treatment), triangular (low, mode, high), from label doses of the admissible formulations
AI_PER_DOSE = {'T1': (0.01, 0.04, 0.10),      # diamides, indoxacarb, emamectin, IGRs
               'T2': (0.03, 0.20, 0.34),      # pyrethroid + organophosphate mixtures; indoxacarb, chlorantraniliprole
               'T3': (0.03, 0.05, 0.10),      # pyrethroid or spinetoram + acetamiprid; spirotetramat + imidacloprid
               'herb_pre_gran': (0.80, 0.90, 1.50),   # diuron 800-900 g/kg at 1 kg/ha; fluometuron + prometryn 1.5 kg a.i./ha
               'herb_pre_liq': (0.80, 1.20, 1.60), 'herb_post_per_L': (0.04, 0.10, 0.125)}
N_REMOVAL_SEED_COTTON = (0.018, 0.022, 0.026)   # kg N per kg seed cotton removed at harvest (typical agronomic range)

# ======================= Scenario inputs (retrieved 21 Oct 2026) =======================
# Yield Potential and Yield Gap Atlas (YPYGA, yieldpotential.org/atlas), Burkina Faso, national level, t/ha:
# Ya = actual farm yield, Yw = water-limited (rain-fed) yield potential, Yp = irrigated yield potential; area in ha; period.
GYGA = {'maize':   {'Ya': 1.69, 'Yw': 7.51, 'area': 961427,  'period': '2001-2020'},
        'sorghum': {'Ya': 0.94, 'Yw': 5.36, 'area': 1766148, 'period': '2005-2019'},
        'millet':  {'Ya': 0.77, 'Yw': 3.35, 'area': 1274940, 'period': '2005-2019'},
        'rice_rf': {'Ya': 1.42, 'Yw': 5.39, 'area': 112781,  'period': '2000-2019'},
        'rice_irr':{'Ya': 4.57, 'Yp': 8.41, 'area': 9290,    'period': '2000-2019'}}
# FAOSTAT QCL, Burkina Faso, 2021-2023 means: area harvested (ha) and production (t)
QCL_AREA = {'maize': 1176120, 'sorghum': 1859876, 'millet': 994233, 'rice': 210606, 'fonio': 16146,
            'pulses': 1462459, 'oilcrops_food': 674843 + 390668 + 117842 + 105565, 'treenuts': 219923,
            'fruits': 244741, 'vegetables': 154314, 'roots': 33107, 'sugarcane': 5045, 'spices': 91589 + 3486}
QCL_PROD = {'maize': 1886382, 'sorghum': 1809871, 'millet': 824709, 'rice': 464750, 'fonio': 10329}
# FAOSTAT FBS (2010-), Burkina Faso, 2021-2023 means. Quantities in kt: prod, imp, exp, ds (domestic supply), feed, food.
# kcal = food supply, kcal/cap/d. Cottonseed and cottonseed oil removed from oilcrops and vegetable oils (non-food crop).
FBS_GROUPS = {
    'cereals':   {'prod': 4996.0, 'imp': 1315.667, 'exp': 30.0, 'ds': 6435.333, 'feed': 795.0, 'food': 4794.667, 'kcal': 1599.693},
    'wheat':     {'prod': 0.0, 'imp': 345.0, 'ds': 326.0, 'feed': 11.667, 'food': 294.667, 'kcal': 93.44},
    'rice':      {'prod': 464.667, 'imp': 915.667, 'ds': 1307.333, 'feed': 124.667, 'food': 1110.667, 'kcal': 300.753},
    'barley':    {'prod': 0.0, 'imp': 35.0, 'ds': 30.333, 'feed': 0.0, 'food': 9.333, 'kcal': 3.967},
    'roots':     {'prod': 226.0, 'imp': 149.0, 'ds': 364.0, 'feed': 4.0, 'food': 198.333, 'kcal': 22.833},
    'sugar':     {'prod': 45.333, 'imp': 226.0, 'ds': 200.333, 'feed': 0.0, 'food': 185.0, 'kcal': 61.483},
    'pulses':    {'prod': 744.333, 'imp': 5.0, 'ds': 748.0, 'feed': 2.333, 'food': 699.667, 'kcal': 275.62},
    'oilcrops':  {'prod': 1427.333 - 368.333, 'ds': 894.0 - 96.667, 'feed': 236.667 - 47.0, 'kcal': 233.833},
    'treenuts':  {'prod': 279.667, 'ds': 169.667, 'feed': 0.0, 'kcal': 13.643},
    'vegoils':   {'prod': 36.0 - 8.0, 'ds': 68.333 - 4.667, 'kcal': 87.393 - 5.307},
    'vegetables':{'prod': 1394.0, 'ds': 1428.333, 'feed': 0.0, 'kcal': 42.187},
    'fruits':    {'prod': 1412.667, 'ds': 1429.0, 'feed': 0.0, 'kcal': 70.72},
    'spices':    {'prod': 79.0, 'ds': 80.0, 'kcal': 29.037},
    'stimulants':{'prod': 0.0, 'ds': 12.333, 'kcal': 1.883},
    'alcohol':   {'prod': 1951.0, 'ds': 1917.0, 'kcal': 71.273},
    # terrestrial animal products: production and domestic supply, kt; kcal/cap/d
    'meat':      {'prod': 537.0, 'ds': 537.0, 'kcal': 126.487},
    'offals':    {'prod': 49.0, 'ds': 49.0, 'kcal': 6.967},
    'animalfats':{'prod': 27.0, 'ds': 29.0, 'kcal': 23.707},
    'eggs':      {'prod': 68.0, 'ds': 68.0, 'kcal': 3.79},
    'milk':      {'prod': 435.0, 'ds': 582.667, 'kcal': 42.1},
    'fish':      {'prod': 31.0, 'imp': 222.0, 'ds': 252.0, 'kcal': 20.733},
}
FBS_OIL_EXTRACTION = (36.0 - 8.0) / (135.667 - 44.0)   # food vegetable-oil output per t of non-cotton oilcrops processed (FBS)
# FAOSTAT FBS, World, 2021-2023 means, food supply kcal/cap/d by group
FBS_WLD_KCAL = {'cereals': 1275.803, 'roots': 159.537, 'sugar': 232.213 + 4.93, 'pulses': 68.0, 'oil': 15.993 + 74.95 + 318.123,
                'vegetables': 108.617, 'fruits': 118.09, 'other': 9.57 + 14.327, 'alcohol': 63.413,
                'animal_terr': 529.077 - 35.883 - 3.053, 'fish': 35.883 + 3.053, 'total': 2996.213}
# EAT-Lancet 2025 planetary health diet, Table 1 (Rockstrom et al., 2025), kcal/day at ~2400 kcal
PHD_KCAL = {'cereals': 735, 'roots': 50, 'vegetables': 95, 'fruits': 145, 'oil': 275 + 355 + 55, 'pulses': 275, 'sugar': 115,
            'animal_terr': 145 + 60 + 20 + 45, 'fish': 25}
# FAOSTAT GT detail, Burkina Faso, kt CO2eq (AR5), 2021-2023 means unless noted
GT_DETAIL = {'livestock': (19819.1 + 20158.6 + 20499.3) / 3, 'crops': (2251.42 + 2173.52 + 2334.37) / 3,
             'manure_pasture_2022': 6155.9, 'n2o_total_2022': 7914.13}
# FAOSTAT GLE (Emissions from livestock), Burkina Faso, 2021-2023 means: CH4 and N2O (kt) and N left on pasture (kg) by animal
GLE = {'cattle_dairy': (78.577, 3.544, 86591066.6), 'cattle_nondairy': (264.617, 12.334, 317449962.9), 'sheep': (58.690, 3.088, 133609177.9),
       'goats': (56.368, 3.676, 160372285.5), 'swine': (4.363, 1.099, 0.0), 'poultry': (0.652, 0.533, 11802404.2),
       'asses': (17.528, 0.775, 33817460.8), 'horses': (0.318, 0.014, 622749.7), 'camels': (1.406, 0.024, 1044381.6)}
# FAOSTAT FBS animal-product detail, kcal/cap/d (2021-2023): Burkina Faso and World
FBS_ANIMAL_DETAIL = {'BFA': {'bovine': 32.41, 'mutton_goat': 10.443, 'pig': 56.657, 'poultry': 25.367, 'other_meat': 1.61, 'offals': 6.967,
                             'animalfats': 23.707, 'eggs': 3.79, 'milk': 42.1},
                     'WLD': {'bovine': 40.553, 'mutton_goat': 11.057, 'pig': 87.573, 'poultry': 67.357, 'other_meat': 2.947, 'offals': 9.027,
                             'animalfats': 64.95, 'eggs': 37.343, 'milk': 169.333}}
