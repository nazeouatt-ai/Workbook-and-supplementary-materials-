"""Fig. S4 - local exceedance of the critical nitrogen surplus in Burkina Faso.

Inputs
  exc_nsur_crit_mi_all_ph.asc  0.5 deg raster of the exceedance of the critical N surplus on arable land and
                               intensively managed grassland (all thresholds, 2010), supporting data of
                               te Wierik et al. (2025), 'Data for Figure 4'. Not redistributed here.
  bfa_poly.json                national outline used to select grid cells (cell centre inside the outline);
                               this is the selection behind the statistics in N_local.json.
  wa_10m.json                  Natural Earth 1:10m country boundaries (public domain), display only.
Usage: python fig_s4_nitrogen.py path/to/exc_nsur_crit_mi_all_ph.asc
"""
import sys, json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.colors import BoundaryNorm, ListedColormap
from matplotlib.patches import Rectangle, Patch
from matplotlib.lines import Line2D

plt.rcParams.update({'font.family': 'Liberation Sans', 'font.size': 8, 'mathtext.fontset': 'custom',
                     'mathtext.rm': 'Liberation Sans', 'mathtext.default': 'regular', 'axes.linewidth': 0.6,
                     'axes.edgecolor': '#4A4F55', 'xtick.color': '#4A4F55', 'ytick.color': '#4A4F55'})
INK, INK2, NODATA = '#1A1A1A', '#4A4F55', '#E6E7EA'
asc = sys.argv[1] if len(sys.argv) > 1 else 'exc_nsur_crit_mi_all_ph.asc'

# ---------------- data ----------------
a = np.loadtxt(asc, skiprows=6); a[a == -9999] = np.nan               # 360 x 720, row 0 = 90 N
LON0, LON1, LAT0, LAT1 = -7.0, 4.0, 8.0, 16.5
outline = Path(np.array(json.load(open('bfa_poly.json'))))
wa = json.load(open('wa_10m.json'))
cells = []                                                             # (lon_w, lat_s, value, counted)
for i in range(int((90 - LAT1) / 0.5), int((90 - LAT0) / 0.5)):
    for j in range(int((LON0 + 180) / 0.5), int((LON1 + 180) / 0.5)):
        lat_s, lon_w = 90 - 0.5 * (i + 1), -180 + 0.5 * j
        cells.append((lon_w, lat_s, a[i, j], outline.contains_point((lon_w + 0.25, lat_s + 0.25))))
inside = [c for c in cells if c[3]]
v = np.array([c[2] for c in inside if np.isfinite(c[2])])
n_cells, n_data, n_exc = len(inside), len(v), int((v > 0).sum())
med = float(np.median(v))
glob = a[np.isfinite(a)]; glob_share = float((glob > 0).mean())
print(f'cells {n_cells}, with data {n_data}, exceeded {n_exc} ({n_exc / n_data:.0%}), median {med:.1f}, '
      f'p5 {np.percentile(v, 5):.1f}, p95 {np.percentile(v, 95):.1f}, world share {glob_share:.0%}')

# ---------------- colour scale: 10 kg N bins, open-ended ----------------
bounds = np.arange(-40, 41, 10)
cols = ['#2B5C8A', '#4F81B0', '#86AACD', '#C3D5E7', '#F2D2BE', '#E5A07D', '#CF6A48', '#A63A26']
cmap = ListedColormap(cols); cmap.set_under('#1D3F63'); cmap.set_over('#74200F')
norm = BoundaryNorm(bounds, cmap.N)

fig = plt.figure(figsize=(7.2, 3.9))
ax = fig.add_axes([0.06, 0.17, 0.56, 0.81]); cax = fig.add_axes([0.10, 0.045, 0.48, 0.024])
bx = fig.add_axes([0.72, 0.24, 0.26, 0.66])

# ---------------- (a) map ----------------
for lon_w, lat_s, val, counted in cells:
    fc = NODATA if not np.isfinite(val) else cmap(norm(val))
    ax.add_patch(Rectangle((lon_w, lat_s), 0.5, 0.5, fc=fc, ec='white', lw=0.35, alpha=1.0 if counted else 0.35, zorder=1))
for iso, c in wa.items():
    for r in c['rings']:
        r = np.array(r)
        ax.plot(r[:, 0], r[:, 1], color=INK if iso == 'BFA' else INK2, lw=1.1 if iso == 'BFA' else 0.45, zorder=3,
                solid_joinstyle='round')
for lon_w, lat_s, val, counted in inside:                              # mark cells counted in the statistics
    if np.isfinite(val): ax.plot(lon_w + 0.25, lat_s + 0.25, 'o', ms=1.6, mfc=INK, mec='none', zorder=4)
for name, (x, y) in {'MALI': (-2.6, 16.05), 'NIGER': (2.7, 15.2), 'GHANA': (-1.6, 8.5), "CÔTE D'IVOIRE": (-5.2, 8.45),
                     'TOGO': (1.0, 8.35), 'BENIN': (2.5, 9.6)}.items():
    ax.text(x, y, name, fontsize=7, color=INK2, ha='center', va='center', zorder=5,
            bbox=dict(fc='white', ec='none', alpha=0.75, pad=0.6))
ax.text(-1.2, 11.25, 'BURKINA FASO', fontsize=8, fontweight='bold', color=INK, ha='center', zorder=5,
        bbox=dict(fc='white', ec='none', alpha=0.75, pad=0.8))
for name, (x, y), dx in [('Ouagadougou', (-1.527, 12.372), 0.12), ('Bobo-Dioulasso', (-4.29, 11.18), 0.12)]:
    ax.plot(x, y, marker='*' if name.startswith('Ouaga') else 's', ms=6 if name.startswith('Ouaga') else 3.5,
            mfc='white', mec=INK, mew=0.7, zorder=6)
    ax.text(x + dx, y - 0.22, name, fontsize=7, color=INK, va='top', zorder=6,
            bbox=dict(fc='white', ec='none', alpha=0.75, pad=0.5))
ax.set_xlim(LON0, LON1); ax.set_ylim(LAT0, LAT1); ax.set_aspect(1 / np.cos(np.deg2rad(12.25)))
ax.set_xticks(range(-6, 5, 2)); ax.set_yticks(range(8, 17, 2))
ax.set_xticklabels([f'{abs(x)}°{"W" if x < 0 else ("E" if x > 0 else "")}' for x in range(-6, 5, 2)])
ax.set_yticklabels([f'{y}°N' for y in range(8, 17, 2)])
ax.tick_params(labelsize=8, length=2.5, width=0.6)
ax.text(-0.01, 1.0, 'a', transform=ax.transAxes, fontsize=10, fontweight='bold', ha='right', va='bottom')
cb = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax, orientation='horizontal', extend='both',
                  ticks=bounds, extendfrac=0.06)
cb.outline.set_linewidth(0.5); cb.ax.tick_params(labelsize=8, length=2, width=0.5, pad=1.5)
cax.set_xlabel('Exceedance of the critical N surplus (kg N ha$^{-1}$ yr$^{-1}$)', fontsize=8, labelpad=2)
cax.xaxis.set_label_position('bottom')
cax.text(-0.075, 0.5, 'Below', transform=cax.transAxes, fontsize=7, color=cols[0], ha='right', va='center')
cax.text(1.075, 0.5, 'Above', transform=cax.transAxes, fontsize=7, color=cols[-1], ha='left', va='center')
ax.legend(handles=[Patch(fc=NODATA, ec='none', label='No agricultural data'),
                   Line2D([], [], ls='none', marker='o', ms=2.5, mfc=INK, mec='none', label=f'Cell counted (n = {n_data})')],
          loc='upper left', fontsize=7, frameon=True, framealpha=0.9, edgecolor='none', borderpad=0.4, handlelength=1.2)

# ---------------- (b) distribution of the counted cells ----------------
vs = np.sort(v)
y = np.arange(len(vs))
bx.barh(y, vs, height=0.78, color=[cmap(norm(x)) for x in vs], ec='none')
bx.axvline(0, color=INK, lw=0.7)
bx.axvline(med, color=INK, lw=0.8, ls=(0, (3, 2)))
bx.text(med, len(vs) + 0.3, f'median {med:+.1f}', fontsize=7, color=INK, ha='center', va='bottom')
bx.set_ylim(-0.8, len(vs) + 0.2); bx.set_yticks([])
for s in ('top', 'right', 'left'): bx.spines[s].set_visible(False)
bx.set_xlim(-45, 40); bx.set_xticks(range(-40, 41, 20)); bx.tick_params(labelsize=8, length=2.5, width=0.6)
bx.set_xlabel('kg N ha$^{-1}$ yr$^{-1}$', fontsize=8)
bx.set_ylabel(f'Agricultural grid cells in Burkina Faso (n = {n_data})', fontsize=8)
bx.text(-43, n_data - 2, f'{n_exc} of {n_data} cells ({n_exc / n_data:.0%})\nabove the critical\nsurplus',
        fontsize=7, color=cols[-1], ha='left', va='top')
bx.text(9, 1, f'{n_data - n_exc} cells ({(n_data - n_exc) / n_data:.0%})\nbelow', fontsize=7, color=cols[0], ha='left', va='bottom')
bx.text(-43, n_data - 10, f'World: {glob_share:.0%} of\nagricultural cells\nabove', fontsize=7, color=INK2, ha='left', va='top')
bx.text(-0.06, 1.0, 'b', transform=bx.transAxes, fontsize=10, fontweight='bold', ha='right', va='bottom')

for ext in ('png', 'tif'):
    fig.savefig(f'FigS4_N_local.{ext}', dpi=600, facecolor='white', bbox_inches='tight', pad_inches=0.04,
                **({'pil_kwargs': {'compression': 'tiff_lzw'}} if ext == 'tif' else {}))
