"""Diet x trade x yield scenarios for Burkina Faso's food system, 2050 and 2100.

Demand: UN WPP 2024 population x food supply by food group (FAOSTAT FBS), for four diets.
Supply: domestic production = self-sufficiency ratio (SSR) x domestic supply; current SSR or full self-sufficiency.
Yields: cereals at current FAOSTAT yields, or closing to 50% / 80% of the GYGA water-limited potential by 2050.
Pressures: baseline (2021-2023, cotton excluded) pressures from model.py, split into livestock-, crop- and
demand-driven parts, each scaled with its driver. Writes scen.json.
"""
import json, itertools
import numpy as np
from data import *

R = json.load(open('results.json'))
P0 = R['pressure']; B = R['global_boundary_natunits']
f_N, f_area, c_pest = R['cotton']['f_N'], R['cotton']['f_area'], R['cotton']['pest_share_2022']
popB0, popW0, DES0 = R['base']['popB0'], R['base']['popW0'], R['base']['DES0']
T0 = 2022
POP = {2022: (popB0, popW0), 2050: (UN_POP['BFA'][2050], UN_POP['WLD'][2050]), 2100: (UN_POP['BFA'][2100], UN_POP['WLD'][2100])}

G = FBS_GROUPS
# ---------------- diets: food supply, kcal/cap/d ----------------
oil_kcal0 = G['oilcrops']['kcal'] + G['treenuts']['kcal'] + G['vegoils']['kcal']
anim_kcal0 = sum(G[k]['kcal'] for k in ['meat', 'offals', 'animalfats', 'eggs', 'milk'])
RUM = ['bovine', 'mutton_goat', 'other_meat', 'offals', 'animalfats', 'milk']; MONO = ['pig', 'poultry', 'eggs']
AD = FBS_ANIMAL_DETAIL
rum0 = sum(AD['BFA'][k] for k in RUM); mono0 = sum(AD['BFA'][k] for k in MONO)
assert abs(rum0 + mono0 - anim_kcal0) < 0.05
D0 = {'cereals': G['cereals']['kcal'], 'roots': G['roots']['kcal'], 'sugar': G['sugar']['kcal'], 'pulses': G['pulses']['kcal'],
      'oil': oil_kcal0, 'vegetables': G['vegetables']['kcal'], 'fruits': G['fruits']['kcal'],
      'other': G['spices']['kcal'] + G['stimulants']['kcal'], 'alcohol': G['alcohol']['kcal'],
      'rum': rum0, 'mono': mono0, 'fish': G['fish']['kcal']}
resid0 = DES0 - sum(D0.values())            # small unallocated remainder (miscellaneous items), held constant per capita
TARGET = 3000.0
def scale_to(d, total, fixed=()):
    fx = sum(d[k] for k in fixed); s = (total - resid0 - fx) / (sum(d.values()) - fx)
    return {k: (v if k in fixed else v * s) for k, v in d.items()}
D1 = scale_to(D0, TARGET)
red_rum = (AD['BFA']['bovine'] + AD['BFA']['mutton_goat']) / (AD['BFA']['bovine'] + AD['BFA']['mutton_goat'] + AD['BFA']['pig'])
phd = {k: 0.0 for k in D0}; phd.update({k: v for k, v in PHD_KCAL.items() if k != 'animal_terr'}); phd['other'] = D0['other']
phd['rum'] = 145 + 45 * red_rum; phd['mono'] = 60 + 20 + 45 * (1 - red_rum)     # milk + red meat; poultry + eggs + red meat
D2 = scale_to(phd, TARGET, fixed=('other',))
# PHD variant allowed by Table 1 of Rockstrom et al. (2025): dairy servings exchanged for poultry and eggs (same ASF energy)
phd_m = dict(phd); phd_m['mono'] = phd['mono'] + 145; phd_m['rum'] = phd['rum'] - 145
D2m = scale_to(phd_m, TARGET, fixed=('other',))
wld = {k: FBS_WLD_KCAL[k] for k in D0 if k in FBS_WLD_KCAL}
wld['rum'] = sum(AD['WLD'][k] for k in RUM); wld['mono'] = sum(AD['WLD'][k] for k in MONO)
D3 = scale_to(wld, TARGET)
DIETS = {'current': D0, 'adequate': D1, 'PHD': D2, 'PHDmono': D2m, 'world': D3}
DIET_LABEL = {'current': 'Current diet (2,738 kcal)', 'adequate': 'Adequate, current mix (3,000 kcal)',
              'PHD': 'Planetary health diet (3,000 kcal)', 'PHDmono': 'Planetary health diet, poultry and eggs for dairy (3,000 kcal)', 'world': 'World-average mix (3,000 kcal)'}
def diet_at(name, t):
    w = min(max((t - T0) / (2050 - T0), 0), 1)
    return {k: D0[k] + (DIETS[name][k] - D0[k]) * w for k in D0}

# ---------------- supply side: domestic supply split into food-driven and feed-driven parts (kt) ----------------
oil_ds = G['oilcrops']['ds'] + G['treenuts']['ds'] + (G['vegoils']['ds'] - G['vegoils']['prod']) / FBS_OIL_EXTRACTION   # seed equivalent
oil_prod = G['oilcrops']['prod'] + G['treenuts']['prod']
SUP = {  # ds0, feed0, prod0, harvested area (kha), demand driver(s)
    'cereals':    dict(ds=G['cereals']['ds'], feed=G['cereals']['feed'], prod=G['cereals']['prod'], drivers=('cereals', 'alcohol')),
    'roots':      dict(ds=G['roots']['ds'], feed=G['roots']['feed'], prod=G['roots']['prod'], area=QCL_AREA['roots'] / 1e3, drivers=('roots',)),
    'sugar':      dict(ds=G['sugar']['ds'], feed=0.0, prod=G['sugar']['prod'], area=QCL_AREA['sugarcane'] / 1e3, drivers=('sugar',)),
    'pulses':     dict(ds=G['pulses']['ds'], feed=G['pulses']['feed'], prod=G['pulses']['prod'], area=QCL_AREA['pulses'] / 1e3, drivers=('pulses',)),
    'oil':        dict(ds=oil_ds, feed=G['oilcrops']['feed'], prod=oil_prod, area=(QCL_AREA['oilcrops_food'] + QCL_AREA['treenuts']) / 1e3, drivers=('oil',)),
    'vegetables': dict(ds=G['vegetables']['ds'], feed=0.0, prod=G['vegetables']['prod'], area=QCL_AREA['vegetables'] / 1e3, drivers=('vegetables',)),
    'fruits':     dict(ds=G['fruits']['ds'], feed=0.0, prod=G['fruits']['prod'], area=QCL_AREA['fruits'] / 1e3, drivers=('fruits',)),
    'spices':     dict(ds=G['spices']['ds'], feed=0.0, prod=G['spices']['prod'], area=QCL_AREA['spices'] / 1e3, drivers=('other',)),
}
for g, s in SUP.items(): s['ssr0'] = s['prod'] / s['ds']
CER = ['maize', 'sorghum', 'millet', 'rice', 'fonio']
cer_area0 = {c: QCL_AREA[c] / 1e3 for c in CER}
cer_prod0 = {c: QCL_PROD[c] / 1e3 for c in CER}
Ya = {c: cer_prod0[c] / cer_area0[c] for c in CER}                       # FAOSTAT 2021-2023, t/ha
rice_Yw = (GYGA['rice_rf']['Yw'] * GYGA['rice_rf']['area'] + GYGA['rice_irr']['Yp'] * GYGA['rice_irr']['area']) / (GYGA['rice_rf']['area'] + GYGA['rice_irr']['area'])
Yw = {'maize': GYGA['maize']['Yw'], 'sorghum': GYGA['sorghum']['Yw'], 'millet': GYGA['millet']['Yw'], 'rice': rice_Yw, 'fonio': None}
SUP['cereals']['area'] = sum(cer_area0.values())
H0 = sum(s['area'] for s in SUP.values())
rice_share_ds = G['rice']['ds'] / G['cereals']['ds']
# terrestrial animal products: kcal-weighted self-sufficiency
anim_items = ['meat', 'offals', 'animalfats', 'eggs', 'milk']
SSR_A0 = sum(G[k]['kcal'] * G[k]['prod'] / G[k]['ds'] for k in anim_items) / anim_kcal0
rum_prod0 = sum(AD['BFA'][k] for k in RUM) - AD['BFA']['milk'] * (1 - G['milk']['prod'] / G['milk']['ds']) - AD['BFA']['animalfats'] * (1 - G['animalfats']['prod'] / G['animalfats']['ds'])
SSR_R0 = rum_prod0 / rum0; SSR_M0 = 1.0
# livestock emissions by system (kt CO2eq, AR5) and shares of manure N left on pasture
co2e = {a: v[0] * 28 + v[1] * GWP_N2O_AR5 for a, v in GLE.items()}
E_rum = sum(co2e[a] for a in ['cattle_dairy', 'cattle_nondairy', 'sheep', 'goats']); E_mono = co2e['swine'] + co2e['poultry']
E_dr = co2e['asses'] + co2e['horses'] + co2e['camels']
Npt = sum(v[2] for v in GLE.values())
n_rum = sum(GLE[a][2] for a in ['cattle_dairy', 'cattle_nondairy', 'sheep', 'goats']) / Npt; n_mono = GLE['poultry'][2] / Npt; n_dr = 1 - n_rum - n_mono
FIELD = ['cereals', 'pulses', 'oil']       # field crops: driver of residue emissions and pesticide use

# ---------------- baseline pressure components (food system, cotton excluded), 2021-2023 ----------------
def m3(v): return float(np.mean(v[-3:]))
synth = m3(GT00['synth_fert']); resid = m3(GT00['crop_residues']); burn = m3(GT00['burning_residues'])
energy = m3(GT00['onfarm_energy']); pestm = m3(GT00['pest_manuf'])
crops_tot = GT_DETAIL['crops']; rice_ch4 = crops_tot - synth - resid - burn
farmgate = m3(GT['BFA_farmgate']); livestock = GT_DETAIL['livestock']
fires = farmgate - livestock - crops_tot - f_area * energy
C = {'livestock': livestock, 'fert': synth * (1 - f_N), 'rice': rice_ch4, 'resburn': (resid + burn) * (1 - f_area), 'fires': fires,
     'prepost': m3(GT['BFA_prepost']) - c_pest * pestm, 'luc': m3(GT['BFA_luc']) * (1 - f_area)}
C = {k: v / 1e3 for k, v in C.items()}           # Mt CO2eq
assert abs(sum(C.values()) - P0['climate']) < 1e-3, (sum(C.values()), P0['climate'])
luc_per_kha = m3(GT['BFA_luc']) / 1e3 / R['land_conversion']['cropland_gain_kha_yr']     # Mt CO2eq per kha of annual cropland expansion
toN = 1e3 / GWP_N2O_AR5 * 28 / 44                  # Mt CO2eq (N2O) -> kt N2O-N
n2o_all = np.mean(GT_N2O['BFA']) / 1e3 * toN
NO = {'livestock': n2o_all * GT_DETAIL['manure_pasture_2022'] / GT_DETAIL['n2o_total_2022'], 'fert': C['fert'] * toN, 'resid': resid * (1 - f_area) / 1e3 * toN}
NO['other'] = P0['N2O'] - sum(NO.values())
Nmin0 = np.mean(ESB['BFA_N_mineral'][-3:]) / 1e3 * (1 - f_N)             # kt N, mineral N on food crops
Nbal0 = R['N_parts']['inputs'] - R['N_parts']['outputs'] - R['cotton']['N_balance_kt']   # food cropland N balance, kt
Npast0 = R['exploratory']['pasture_N_loss_kt']
assert abs(Nbal0 + Npast0 - P0['N_surplus']) < 1e-6
Pmin0 = P0['P_application']; pest0 = P0['pesticides']
crop0, past0 = P0['cropland'], P0['agland'] - P0['cropland']             # Mha

# agronomic assumptions for yield-gap closure (central, low, high)
N_GRAIN = (0.015, 0.012, 0.018)      # t N per t grain removed
NUE_M = (0.5, 0.7, 0.3)              # recovery of additional fertilizer N (central, favourable, unfavourable)
P_GRAIN = 0.003                      # t P per t grain, replaced to avoid further soil P mining

def run(diet, trade, yf, t, n_grain=N_GRAIN[0], nue=NUE_M[0], live_int=1.0, ref=None, nc_gain=False):
    """Pressures in year t. yf: None (current yields) or fraction of Yw reached by 2050."""
    pB, pW = POP[t]; d = diet_at(diet, t)
    # livestock activity index (domestic terrestrial animal production)
    sR = 1.0 if trade == 'self' else SSR_R0
    XR = pB * d['rum'] * sR / (popB0 * rum0 * SSR_R0); XM = pB * d['mono'] / (popB0 * mono0)
    # activity indices weighted by emissions (climate), by pasture-N (N surplus, N2O); draught animals held constant
    XL_c = (E_rum * XR * live_int + E_mono * XM + E_dr) / (E_rum + E_mono + E_dr)
    XL_n = n_rum * XR * live_int + n_mono * XM + n_dr
    XL = XL_c
    prod, area = {}, {}
    for g, s in SUP.items():
        k0 = sum(D0[x] for x in s['drivers']); k1 = sum(d[x] for x in s['drivers'])
        ds = (s['ds'] - s['feed']) * pB * k1 / (popB0 * k0) + s['feed'] * (XM if g == 'cereals' else XR)
        ssr = max(s['ssr0'], 1.0) if trade == 'self' else s['ssr0']
        prod[g] = ssr * ds
        if g != 'cereals': area[g] = prod[g] * s['area'] / s['prod']
        else: ds_cer = ds
    # cereals by crop
    if trade == 'self':
        cp = {'rice': ds_cer * rice_share_ds}
        rest = prod['cereals'] - cp['rice']; base_rest = sum(cer_prod0[c] for c in CER if c != 'rice')
        cp.update({c: rest * cer_prod0[c] / base_rest for c in CER if c != 'rice'})
    else:
        cp = {c: prod['cereals'] * cer_prod0[c] / SUP['cereals']['prod'] for c in CER}
    w = min(max((t - T0) / (2050 - T0), 0), 1)
    Y = {c: (Ya[c] if (yf is None or Yw[c] is None) else Ya[c] + (max(Ya[c], yf * Yw[c]) - Ya[c]) * w) for c in CER}
    ca = {c: cp[c] / Y[c] for c in CER}
    if nc_gain:   # sensitivity: non-cereal yields rise by the same relative amount as cereal yields
        gain = sum(Y[c] / Ya[c] * cp[c] for c in CER) / sum(cp.values())
        area = {g: a / gain for g, a in area.items()}
    area['cereals'] = sum(ca.values())
    H = sum(area.values()); cropland = crop0 * H / H0; agland = cropland + past0
    dY_prod = sum((Y[c] - Ya[c]) * ca[c] for c in CER)                     # kt grain above baseline yield
    dN = n_grain * dY_prod / nue                                            # kt N extra mineral fertilizer
    Nmin = Nmin0 * H / H0 + dN
    XC = sum(prod[g] for g in FIELD) / sum(SUP[g]['prod'] for g in FIELD)
    XD = pB * sum(d.values()) / (popB0 * (DES0 - resid0))
    # land-use change: emissions from cropland expansion since the reference year (no credit for abandonment)
    c_ref, t_ref = (crop0, T0) if ref is None else ref
    expand = (R['land_conversion']['cropland_gain_kha_yr'] * (1 - f_area) if t == t_ref     # base year: observed 2000-2023 rate
              else max(0.0, (cropland - c_ref) * 1e3 / (t - t_ref)))              # kha per year
    luc = luc_per_kha * expand
    clim_nonluc = (C['livestock'] * XL_c + C['fert'] * Nmin / Nmin0 + C['rice'] * ca['rice'] / cer_area0['rice']
                   + C['resburn'] * XC + C['fires'] + C['prepost'] * XD)
    pres = {'climate': clim_nonluc + luc, 'climate_nonLUC': clim_nonluc, 'agland': agland, 'cropland': cropland,
            'N_surplus': Nbal0 * H / H0 + dN * (1 - nue) + Npast0 * XL_n,
            'N2O': NO['livestock'] * XL_n + NO['fert'] * Nmin / Nmin0 + NO['resid'] * XC + NO['other'] * XD,
            'P_application': Pmin0 * H / H0 + P_GRAIN * dY_prod, 'pesticides': pest0 * XC}
    share = pB / pW
    asr = {k: pres[k] / (share * B['climate' if k == 'climate_nonLUC' else k]) for k in pres if k != 'cropland'}
    diag = {'XL': XL, 'XL_n': XL_n, 'X_rum': XR, 'X_mono': XM, 'XC': XC, 'Nmin_kt': Nmin, 'Nmin_multiple': Nmin / Nmin0, 'cropland_change_Mha': cropland - crop0,
            'expansion_kha_yr': expand, 'cereal_prod_kt': sum(cp.values()), 'cereal_ds_kt': ds_cer,
            'cereal_SSR': sum(cp.values()) / ds_cer, 'cereal_area_Mha': area['cereals'] / 1e3, 'agland_share_of_land': (agland + R['cotton']['area_Mha']) / (RL_2000['BFA_land'] / 1e3), 'yields': Y, 'luc_Mt': luc}
    return pres, asr, diag

OUT = {'meta': {'H0_kha': H0, 'SSR_A0': SSR_A0, 'SSR_R0': SSR_R0, 'E_rum': E_rum, 'E_mono': E_mono, 'E_dr': E_dr, 'n_rum': n_rum, 'n_mono': n_mono,
                'int_rum_per_kcal': E_rum / rum_prod0, 'int_mono_per_kcal': E_mono / mono0, 'ssr0': {g: s['ssr0'] for g, s in SUP.items()}, 'Ya': Ya, 'Yw': Yw,
                'ratio_Ya_Yw': {c: Ya[c] / Yw[c] for c in CER if Yw[c]}, 'diets': DIETS, 'resid0': resid0,
                'animal_share': {k: (v['rum'] + v['mono'] + v['fish']) / (sum(v.values()) + resid0) for k, v in DIETS.items()},
                'components_climate': C, 'components_N2O': NO, 'Nmin0': Nmin0, 'Nbal0': Nbal0, 'Npast0': Npast0,
                'luc_t_per_ha': luc_per_kha * 1e3, 'oil_extraction': FBS_OIL_EXTRACTION}, 'grid': {}}
YIELDS = {'current': None, 'Yw50': 0.5, 'Yw80': 0.8}
for diet, trade, yk in itertools.product(DIETS, ['current', 'self'], YIELDS):
    key = f'{diet}|{trade}|{yk}'
    p50, a50, d50 = run(diet, trade, YIELDS[yk], 2050)
    p100, a100, d100 = run(diet, trade, YIELDS[yk], 2100, ref=(p50['cropland'], 2050))
    OUT['grid'][key] = {'2050': {'pressure': p50, 'ASR': a50, 'diag': d50}, '2100': {'pressure': p100, 'ASR': a100, 'diag': d100}}

# production potential vs actual: cereal output on today's cereal area at each yield level, against cereal demand
pot = {}
for lvl, f in [('current', None), ('Yw50', 0.5), ('Yw80', 0.8), ('Yw100', 1.0)]:
    pot[lvl] = sum(cer_area0[c] * (Ya[c] if (f is None or Yw[c] is None) else max(Ya[c], f * Yw[c])) for c in CER)
OUT['potential'] = {'cereal_output_on_current_area_kt': pot, 'cereal_ds_base_kt': G['cereals']['ds'],
                    'demand': {d: {t: run(d, 'self', None, t)[2]['cereal_ds_kt'] for t in [2050, 2100]} for d in DIETS}}
# sensitivities on the central yield-gap scenario (PHD, self-sufficient, 80% Yw)
sens = {}
for lab, kw in [('central', {}), ('NUE_0.7', {'nue': 0.7}), ('NUE_0.3', {'nue': 0.3}), ('Ngrain_12', {'n_grain': 0.012}),
                ('Ngrain_18', {'n_grain': 0.018}), ('livestock_intensity_-30%', {'live_int': 0.7}), ('noncereal_yield_gain', {'nc_gain': True})]:
    for key in ['PHD|self|Yw80', 'PHDmono|self|Yw80', 'adequate|self|Yw80', 'current|self|Yw80']:
        dname, tr, yk = key.split('|')
        r_ = run(dname, tr, YIELDS[yk], 2050, **kw); sens[f'{key}|{lab}'] = dict(r_[1], cropland_change_Mha=r_[2]['cropland_change_Mha'], Nmin_multiple=r_[2]['Nmin_multiple'])
OUT['sens'] = sens
json.dump(OUT, open('scen.json', 'w'), indent=1, default=float)

if __name__ == '__main__':
    M = OUT['meta']
    print('H0 kha', round(H0), 'SSR_A0', round(SSR_A0, 3), 'Ya/Yw', {k: round(v, 3) for k, v in M['ratio_Ya_Yw'].items()})
    print('animal share', {k: round(v, 3) for k, v in M['animal_share'].items()})
    print('diet kcal', {k: {g: round(x) for g, x in v.items()} for k, v in DIETS.items()})
    print('LUC t/ha', round(M['luc_t_per_ha'], 1), 'NO', {k: round(v, 2) for k, v in NO.items()})
    print('potential', {k: round(v) for k, v in pot.items()}, 'demand', OUT['potential']['demand'])
    ind = ['climate', 'climate_nonLUC', 'agland', 'N_surplus', 'N2O', 'pesticides', 'P_application']
    print('key'.ljust(26), *[i[:8].rjust(8) for i in ind], 'dCrop', 'Nx', 'XL', 'cerSSR')
    for k, v in OUT['grid'].items():
        for t in ['2050', '2100']:
            a, dg = v[t]['ASR'], v[t]['diag']
            print(f'{k}|{t}'.ljust(26), *[f'{a[i]:8.2f}' for i in ind], f"{dg['cropland_change_Mha']:5.2f}", f"{dg['Nmin_multiple']:4.1f}", f"{dg['XL']:4.2f}", f"{dg['cereal_SSR']:4.2f}")
    for k, v in sens.items(): print(k, {i: round(float(v[i]), 2) for i in ['climate', 'agland', 'N_surplus', 'N2O', 'pesticides', 'P_application', 'cropland_change_Mha']})
