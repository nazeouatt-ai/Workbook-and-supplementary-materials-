"""Fig. 7: production potential, cropland requirement and fair-share ratios across diet x trade x yield scenarios."""
import json, numpy as np, matplotlib
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap
from data import *

S = json.load(open('scen.json'))
NAVY, TEAL, GOLD, BRICK, SAGE, PLUM, SLATE = '#1B3A5C', '#2E7D8C', '#C9962B', '#A83C2A', '#5E8C4A', '#6B4E7A', '#5B6770'
INK, INK2 = '#1A1A1A', '#4A4F55'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2, 'axes.linewidth': 0.6,
                     'axes.titlesize': 8, 'axes.titleweight': 'bold', 'legend.frameon': False})
DI = ['current', 'adequate', 'PHD', 'PHDmono', 'world']
DL = {'current': 'Current diet', 'adequate': 'Adequate, current mix', 'PHD': 'Planetary health diet', 'PHDmono': 'PHD, poultry and eggs for dairy',
      'world': 'World-average mix'}
DC = {'current': SLATE, 'adequate': NAVY, 'PHD': BRICK, 'PHDmono': GOLD, 'world': PLUM}
DS = {'current': 'Current', 'adequate': 'Adequate', 'PHD': 'PHD', 'PHDmono': 'PHD-poultry', 'world': 'World mix'}
YK = ['current', 'Yw50', 'Yw80']; YL = {'current': 'Current yields', 'Yw50': '50% of Yw', 'Yw80': '80% of Yw'}
def panel(ax, s, x=-0.08, y=1.03): ax.text(x, y, s, transform=ax.transAxes, fontsize=10, fontweight='bold', color=INK, va='bottom', ha='right')

fig = plt.figure(figsize=(7.2, 9.4))
gsT = fig.add_gridspec(1, 2, left=0.08, right=0.97, top=0.97, bottom=0.715, width_ratios=[1, 1.1], wspace=0.30)
gsB = fig.add_gridspec(1, 1, left=0.27, right=0.97, top=0.625, bottom=0.02)

# (a) cereal production potential on today's cereal area vs cereal demand (self-sufficiency, domestic use incl. feed)
ax = fig.add_subplot(gsT[0, 0]); panel(ax, 'a')
pot = S['potential']['cereal_output_on_current_area_kt']
lv = ['current', 'Yw50', 'Yw80', 'Yw100']; lvl = ['Current\nyields', '50% of\nYw', '80% of\nYw', '100% of\nYw']
ax.bar(range(4), [pot[k] / 1e3 for k in lv], width=0.62, color=['#B9C2CB', '#8FB3C0', TEAL, NAVY], zorder=2)
for i, k in enumerate(lv): ax.text(i, pot[k] / 1e3 + 0.35, f'{pot[k] / 1e3:.1f}', ha='center', va='bottom', fontsize=6.6, color=INK)
ax.axhline(S['potential']['cereal_ds_base_kt'] / 1e3, color=INK2, lw=0.8, ls=':', zorder=3)
ax.text(-0.5, S['potential']['cereal_ds_base_kt'] / 1e3 + 0.25, 'Cereal use, 2021–2023', ha='left', va='bottom', fontsize=6, color=INK2)
for k, d in enumerate(DI):
    for t, xx, mk in [(2050, 4.0, 'o'), (2100, 4.72, 's')]:
        v = S['potential']['demand'][d][str(t)] / 1e3
        ax.plot(xx + (k - 2) * 0.07, v, mk, color=DC[d], ms=3.4, mec='white', mew=0.3, zorder=4)
ax.text(4.0, 0.6, '2050', ha='center', fontsize=5.8, color=INK2); ax.text(4.72, 0.6, '2100', ha='center', fontsize=5.8, color=INK2)
ax.axvline(3.62, color='#D5D7DA', lw=0.6)
ax.set_xticks(range(4)); ax.set_xticklabels(lvl, fontsize=6.6); ax.set_xlim(-0.55, 5.1)
ax.set_ylabel('Cereals (Mt yr⁻¹)'); ax.set_ylim(0, 25.5)
ax.set_title('Cereal output on today\'s cereal area\nand cereal demand (self-sufficiency)', loc='left', fontsize=7.6)
ax.legend(handles=[Line2D([], [], marker='o', ls='none', color=DC[d], ms=3.6, label=DS[d]) for d in DI], loc='upper left', fontsize=6.0,
          title='Demand by diet', title_fontsize=6.2, handletextpad=0.2, borderaxespad=0.2)

# (b) cropland change relative to 2021-2023 under self-sufficiency
ax = fig.add_subplot(gsT[0, 1]); panel(ax, 'b')
w = 0.26; x0 = np.arange(len(DI))
for j, yk in enumerate(YK):
    for t, alpha in [('2050', 1.0), ('2100', 0.45)]:
        v = [S['grid'][f'{d}|self|{yk}'][t]['diag']['cropland_change_Mha'] for d in DI]
        ax.bar(x0 + (j - 1) * w, v, width=w * 0.9, color=[TEAL, GOLD, BRICK][j], alpha=alpha, zorder=2 if t == '2050' else 1, lw=0)
avail = (RL_2000['BFA_land'] - np.mean(RL['BFA_agri'][-3:])) / 1e3
ax.axhline(0, color=INK, lw=0.8); ax.axhline(avail, color=INK2, lw=0.8, ls='--')
ax.set_xticks(x0); ax.set_xticklabels([DS[d].replace('-', '-\n').replace(' ', '\n') for d in DI], fontsize=6.6)
ax.set_ylabel('Cropland change since 2021–2023 (Mha)'); ax.set_ylim(-1.5, 23)
ax.set_title('Cropland needed under self-sufficiency', loc='left', fontsize=7.6)
h = [Patch(color=c, label=YL[k]) for c, k in zip([TEAL, GOLD, BRICK], YK)]
h += [Patch(color=SLATE, label='2050'), Patch(color=SLATE, alpha=0.45, label='2100'),
      Line2D([], [], color=INK2, lw=0.8, ls='--', label=f'All non-agricultural land ({avail:.1f} Mha)')]
ax.legend(handles=h, loc='upper left', fontsize=6.1, ncol=2, handlelength=1.2, columnspacing=0.8)

# (c) heat map of 2050 EPC ratios
ax = fig.add_subplot(gsB[0, 0]); panel(ax, 'c', x=-0.36, y=1.03)
IND = [('climate', 'Climate'), ('climate_nonLUC', 'Climate,\nno land-use change'), ('agland', 'Agricultural\nland'), ('N_surplus', 'Nitrogen\nsurplus'),
       ('N2O', 'N₂O'), ('pesticides', 'Pesticides'), ('P_application', 'Mineral P')]
rows = [(d, tr, yk) for d in DI for tr in ['current', 'self'] for yk in YK]
M = np.array([[S['grid'][f'{d}|{tr}|{yk}']['2050']['ASR'][k] for k, _ in IND] for d, tr, yk in rows])
cmap = LinearSegmentedColormap.from_list('div', ['#1B3A5C', '#4F7CA8', '#A9C1D9', '#F4F2EE', '#E3B49A', '#C2654A', '#8E2A1E'])
norm = plt.Normalize(-1.0, 1.0)
ax.imshow(np.clip(np.log10(M), -1, 1), cmap=cmap, norm=norm, aspect='auto')
for i in range(len(rows)):
    for j in range(len(IND)):
        v = M[i, j]; lg = np.log10(v)
        ax.text(j, i, f'{v:.2f}', ha='center', va='center', fontsize=6.3, color='white' if abs(lg) > 0.55 else INK, fontweight='bold' if v > 1 else 'normal')
        if v > 1: ax.add_patch(Rectangle((j - 0.46, i - 0.42), 0.92, 0.84, fc='none', ec=INK, lw=0.7))
ax.set_xticks(range(len(IND))); ax.set_xticklabels([l for _, l in IND], fontsize=6.6); ax.xaxis.tick_top()
ax.set_yticks(range(len(rows))); ax.set_yticklabels([f"{'Imports as today' if tr == 'current' else 'Self-sufficient'} · {YL[yk]}" for d, tr, yk in rows], fontsize=6.1)
ax.set_xticks(np.arange(-0.5, len(IND), 1), minor=True); ax.set_yticks(np.arange(-0.5, len(rows), 1), minor=True)
ax.grid(which='minor', color='white', lw=1.4); ax.tick_params(which='both', length=0)
for sp in ax.spines.values(): sp.set_visible(False)
for b in range(1, len(DI)): ax.axhline(b * 6 - 0.5, color=INK, lw=1.0)
for b, d in enumerate(DI):
    ax.text(-3.55, b * 6 + 2.5, {'current': 'Current diet', 'adequate': 'Adequate,\ncurrent mix', 'PHD': 'Planetary\nhealth diet (PHD)', 'PHDmono': 'PHD-poultry\n(poultry and eggs\nfor dairy)', 'world': 'World-average\nmix'}[d],
            ha='center', va='center', fontsize=6.8, fontweight='bold', color=DC[d], rotation=0, transform=ax.transData, clip_on=False)
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm); cb = plt.colorbar(sm, ax=ax, fraction=0.025, pad=0.015)
cb.set_ticks(np.log10([0.1, 0.3, 1, 3, 10])); cb.set_ticklabels(['0.1', '0.3', '1', '3', '10'])
cb.set_label('Absolute sustainability ratio, EPC, 2050 (log scale)', fontsize=6.6); cb.ax.tick_params(labelsize=6.2); cb.outline.set_visible(False)
cb.ax.axhline(0, color=INK, lw=0.8)
fig.savefig('fig/Fig6_scenarios.png', bbox_inches='tight', dpi=600, facecolor='white')
fig.savefig('fig/Fig6_scenarios.tif', bbox_inches='tight', dpi=600, facecolor='white', pil_kwargs={'compression': 'tiff_lzw'})
fig.savefig('fig/Fig6_scenarios.pdf', bbox_inches='tight', facecolor='white')
print('ok')
